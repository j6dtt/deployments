from flask import Flask, render_template, jsonify, request, send_file, redirect, url_for
from flask_socketio import SocketIO, emit
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from auth import get_user, verify_password
import json
import asyncio
import websockets
import ssl
import threading
from datetime import datetime
import math
import os
import logging
import configparser

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Load configuration from config.ini
config = configparser.ConfigParser()
config_file = os.path.join(os.path.dirname(__file__), 'config.ini')

if not os.path.exists(config_file):
    logging.error(f"Configuration file not found: {config_file}")
    logging.error("Please create config.ini from config.ini.example")
    raise FileNotFoundError(f"Missing required file: {config_file}")

config.read(config_file)
logging.info(f"Loaded configuration from {config_file}")

app = Flask(__name__)
app.config['SECRET_KEY'] = config.get('app', 'secret_key', fallback='spoofer-viz-secret-key')
# Use eventlet for production, threading for development
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='eventlet')

# Initialize Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Allow disabling login for air-gapped/trusted environments
if config.getboolean('app', 'login_disabled', fallback=False):
    login_manager.login_view = None
    app.config['LOGIN_DISABLED'] = True
    logging.info("Login DISABLED - auto-login as admin enabled")


@login_manager.user_loader
def load_user(username):
    """Load user by username for Flask-Login"""
    return get_user(username)


@app.before_request
def auto_login():
    """Auto-login as admin when LOGIN_DISABLED is True"""
    if app.config.get('LOGIN_DISABLED') and not current_user.is_authenticated:
        from auth import User
        login_user(User('admin', 'admin', ['*']))

# Initialize database
import db_manager
if not os.path.exists('/app/event_data.db'):
    logging.info("Initializing database...")
    db_manager.init_database()
    logging.info("Database created at /app/event_data.db")
else:
    # Check database integrity on startup
    db_manager.check_db_integrity()

# Global data store - use dict for event ID lookup
events = {}  # Key: event ID, Value: event data
event_order = []  # Maintains chronological order
sensors = {}  # Key: sensor ID, Value: sensor info
event_batches = []  # Store all batches for persistence
event_readings_count = {}  # Track total readings per event ID

# ============================================================================
# WSS SENSOR CONFIGURATION
# ============================================================================
# WSS servers are now configured in config.ini
# To add/modify sensors, edit config.ini:
#
# [wss_servers]
# server_1 = wss://192.168.1.100:5001,North-Sensor
# server_2 = wss://192.168.1.101:5002,South-Sensor
#
# The system will automatically:
#   - Connect to all sensors concurrently
#   - Track connection status independently
#   - Color-code events by sensor (up to 6 different colors)
#   - Display sensor information when multiple sensors are configured
#
# See SENSORS_CONFIG.md for detailed documentation
# ============================================================================

# Load WSS servers from config.ini
WSS_SERVERS = []
if config.has_section('wss_servers'):
    for key in config['wss_servers']:
        if key.startswith('server_'):
            value = config.get('wss_servers', key)
            # Parse format: uri,name
            parts = value.split(',')
            if len(parts) == 2:
                uri = parts[0].strip()
                name = parts[1].strip()
                WSS_SERVERS.append({"uri": uri, "name": name})
                logging.info(f"Loaded WSS server: {name} ({uri})")
            else:
                logging.warning(f"Invalid WSS server format in config.ini: {key} = {value}")

if not WSS_SERVERS:
    logging.error("No WSS servers configured in config.ini")
    logging.error("Please add servers to [wss_servers] section")
    raise ValueError("No WSS servers configured")

logging.info(f"Configured {len(WSS_SERVERS)} WSS server(s)")
wss_connections_status = {}  # Track connection status per server

# Dashboard retention: how many days of events to show in history table
DASHBOARD_RETENTION_DAYS = config.getint('retention', 'dashboard_days', fallback=7)
DASHBOARD_RETENTION_HOURS = DASHBOARD_RETENTION_DAYS * 24
logging.info(f"Dashboard retention: {DASHBOARD_RETENTION_DAYS} days ({DASHBOARD_RETENTION_HOURS} hours)")


def calculate_destination_point(lat, lon, bearing, distance_km):
    """
    Calculate destination point given start point, bearing and distance

    Args:
        lat: Start latitude in degrees
        lon: Start longitude in degrees
        bearing: Bearing in degrees (0-360, where 0 is North)
        distance_km: Distance in kilometers

    Returns:
        Tuple of (lat, lon) for destination point
    """
    # Earth's radius in kilometers
    R = 6371.0

    # Convert to radians
    lat_rad = math.radians(lat)
    lon_rad = math.radians(lon)
    bearing_rad = math.radians(bearing)

    # Calculate destination point
    dest_lat_rad = math.asin(
        math.sin(lat_rad) * math.cos(distance_km / R) +
        math.cos(lat_rad) * math.sin(distance_km / R) * math.cos(bearing_rad)
    )

    dest_lon_rad = lon_rad + math.atan2(
        math.sin(bearing_rad) * math.sin(distance_km / R) * math.cos(lat_rad),
        math.cos(distance_km / R) - math.sin(lat_rad) * math.sin(dest_lat_rad)
    )

    # Convert back to degrees
    dest_lat = math.degrees(dest_lat_rad)
    dest_lon = math.degrees(dest_lon_rad)

    return dest_lat, dest_lon


async def connect_wss_server(server_config):
    """Connect to a single WebSocket server and process events"""
    global wss_connections_status

    uri = server_config['uri']
    name = server_config['name']

    # Create SSL context that doesn't verify certificates
    ssl_context = ssl.create_default_context()
    ssl_context.check_hostname = False
    ssl_context.verify_mode = ssl.CERT_NONE

    while True:
        try:
            async with websockets.connect(uri, ssl=ssl_context) as websocket:
                logging.info(f"[WSS] {name} connected to {uri}")
                wss_connections_status[name] = True
                socketio.emit('wss_status', {
                    'servers': wss_connections_status,
                    'connected': all(wss_connections_status.values())
                })

                while True:
                    raw_message = await websocket.recv()
                    message_data = json.loads(raw_message)
                    logging.info(f"[WSS] {name} received message: {type(message_data).__name__} with {len(message_data) if isinstance(message_data, list) else 1} event(s)")

                    # Handle both single event (dict) and multiple events (list)
                    if isinstance(message_data, list):
                        # Process each event in the list
                        batch_events = []
                        for event in message_data:
                            processed_event = process_event(event)
                            if processed_event:
                                batch_events.append(processed_event)

                        # Store and emit entire batch to clients
                        if batch_events:
                            # Add timestamp to batch
                            batch_data = {
                                'events': batch_events,
                                'timestamp': batch_events[0].get('obTime') if batch_events else None
                            }
                            # Store in database
                            try:
                                batch_id = db_manager.insert_batch(batch_data)
                                logging.info(f"[DB] Stored batch {batch_id} with {len(batch_events)} events from {name}")
                            except Exception as e:
                                logging.error(f"[DB] Failed to store batch in database: {e}")
                                import traceback
                                logging.error(f"[DB] Traceback: {traceback.format_exc()}")
                            # Also keep in memory for backwards compatibility during transition
                            event_batches.append(batch_data)
                            socketio.emit('new_batch', batch_data)
                            logging.info(f"[WSS] {name} emitted batch with {len(batch_events)} events to clients")
                    elif isinstance(message_data, dict):
                        # Process single event and emit as batch of one
                        processed_event = process_event(message_data)
                        if processed_event:
                            batch_data = {
                                'events': [processed_event],
                                'timestamp': processed_event.get('obTime')
                            }
                            # Store in database
                            try:
                                batch_id = db_manager.insert_batch(batch_data)
                                logging.info(f"[DB] Stored batch {batch_id} with 1 event from {name}")
                            except Exception as e:
                                logging.error(f"[DB] Failed to store batch in database: {e}")
                                import traceback
                                logging.error(f"[DB] Traceback: {traceback.format_exc()}")
                            # Also keep in memory for backwards compatibility during transition
                            event_batches.append(batch_data)
                            socketio.emit('new_batch', batch_data)
                            logging.info(f"[WSS] {name} emitted single event to clients")
                    else:
                        logging.warning(f"[WSS] {name} unexpected message format: {type(message_data)}")

        except websockets.exceptions.ConnectionClosedOK:
            logging.warning(f"[WSS] {name} connection closed by server")
            wss_connections_status[name] = False
            socketio.emit('wss_status', {
                'servers': wss_connections_status,
                'connected': all(wss_connections_status.values())
            })
            await asyncio.sleep(3)
        except Exception as e:
            logging.error(f"[WSS] {name} error: {e}")
            wss_connections_status[name] = False
            socketio.emit('wss_status', {
                'servers': wss_connections_status,
                'connected': all(wss_connections_status.values())
            })
            await asyncio.sleep(5)


async def connect_all_wss_servers():
    """Connect to all configured WSS servers concurrently"""
    tasks = []
    for server in WSS_SERVERS:
        task = asyncio.create_task(connect_wss_server(server))
        tasks.append(task)

    # Run all connections concurrently
    await asyncio.gather(*tasks)


def process_event(event_data):
    """Process incoming event from WSS stream"""
    global events, event_order, sensors, event_readings_count

    # Filter out keepalive messages
    if event_data.get('type') == 'keepalive':
        return None

    event_id = event_data.get('id')
    sensor_id = event_data.get('idSensor')

    # Skip events without required fields
    if not event_id or not sensor_id:
        logging.warning(f"Skipping event with missing id or idSensor: {event_data}")
        return None

    # Determine event type from ID (SPOOFER/ or JAMMER/)
    event_type = 'unknown'
    if event_id:
        if 'SPOOFER' in event_id.upper():
            event_type = 'spoofer'
        elif 'JAMMER' in event_id.upper():
            event_type = 'jammer'

    # Add event type to data
    event_data['eventType'] = event_type

    # Store event by ID (keep latest)
    if event_id:
        events[event_id] = event_data
        if event_id not in event_order:
            event_order.append(event_id)

        # Track total readings count per event ID
        if event_id not in event_readings_count:
            event_readings_count[event_id] = 0
        event_readings_count[event_id] += 1

    # Extract and store sensor information (always update to capture coordinate changes)
    if sensor_id:
        sensor_info = {
            'id': sensor_id,
            'lat': event_data.get('senlat'),
            'lon': event_data.get('senlon'),
            'alt': event_data.get('senalt')
        }

        # Check if this is a new sensor or if coordinates changed
        is_new_or_updated = False
        if sensor_id not in sensors:
            is_new_or_updated = True
        else:
            # Check if coordinates changed
            existing = sensors[sensor_id]
            if (existing.get('lat') != sensor_info['lat'] or
                existing.get('lon') != sensor_info['lon']):
                is_new_or_updated = True
                logging.info(f"[Sensor] Updated coordinates for {sensor_id}")

        sensors[sensor_id] = sensor_info

        # Store/update in database
        try:
            db_manager.insert_sensor(sensor_info)
        except Exception as e:
            logging.error(f"Failed to store sensor in database: {e}")

        # Broadcast new or updated sensor to clients
        if is_new_or_updated:
            socketio.emit('new_sensor', sensor_info)
            logging.info(f"[Sensor] Detected sensor: {sensor_id} at ({sensor_info['lat']:.6f}, {sensor_info['lon']:.6f})")

    #logging.info(f"[Event] Processed: {event_type.upper()} - {event_id} from sensor {sensor_id}")

    return event_data


def start_wss_thread():
    """Start WSS connections in background thread"""
    def run_async_loop():
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(connect_all_wss_servers())

    thread = threading.Thread(target=run_async_loop, daemon=True)
    thread.start()
    logging.info(f"[WSS] Background thread started for {len(WSS_SERVERS)} servers")


# Removed create_map function - using client-side Leaflet.js instead


@app.route('/login', methods=['GET', 'POST'])
def login():
    """Login page"""
    if current_user.is_authenticated:
        return redirect('/')
    error = None
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user = verify_password(username, password)
        if user:
            login_user(user)
            logging.info(f"User '{username}' logged in successfully")
            return redirect('/')
        error = 'Invalid username or password'
        logging.warning(f"Failed login attempt for user '{username}'")
    return render_template('login.html', error=error)


@app.route('/logout')
@login_required
def logout():
    """Logout and redirect to login page"""
    username = current_user.username
    logout_user()
    logging.info(f"User '{username}' logged out")
    return redirect('/login')


@app.route('/')
@login_required
def index():
    """Main page - requires login"""
    # Pass configuration to template
    timeout_minutes = config.getint('app', 'timeout_minutes', fallback=3)
    timeout_ms = timeout_minutes * 60 * 1000
    timeout_check_seconds = config.getint('app', 'timeout_check_seconds', fallback=30)
    timeout_check_ms = timeout_check_seconds * 1000
    return render_template('index.html',
                           timeout_ms=timeout_ms,
                           timeout_check_ms=timeout_check_ms,
                           username=current_user.username,
                           is_admin=current_user.is_admin(),
                           dashboard_days=DASHBOARD_RETENTION_DAYS)


@app.route('/analytics')
@login_required
def analytics():
    """Analytics dashboard page - requires login"""
    return render_template('analytics.html',
                           username=current_user.username,
                           is_admin=current_user.is_admin())


@app.route('/api/analytics')
@login_required
def get_analytics():
    """Get analytics data for dashboard"""
    days = request.args.get('days', 7, type=int)
    days = min(max(days, 1), 30)  # Clamp to 1-30 days
    sensor_filter = request.args.get('sensor', None)

    # Validate sensor access
    if sensor_filter and sensor_filter != 'all':
        if not current_user.is_admin() and not current_user.can_access_sensor(sensor_filter):
            return jsonify({'error': 'Access denied to sensor'}), 403

    try:
        data = db_manager.get_analytics_data(days, sensor_filter if sensor_filter != 'all' else None)

        # Filter by user permissions if not admin and no specific sensor selected
        if not current_user.is_admin() and not sensor_filter:
            allowed_sensors = current_user.sensors
            if '*' not in allowed_sensors:
                # Filter events_by_sensor
                data['events_by_sensor'] = [
                    s for s in data['events_by_sensor']
                    if s['sensor_id'] in allowed_sensors
                ]
                # Recalculate totals
                total_spoofers = sum(s['spoofers'] for s in data['events_by_sensor'])
                total_jammers = sum(s['jammers'] for s in data['events_by_sensor'])
                data['totals'] = {
                    'total_events': total_spoofers + total_jammers,
                    'spoofers': total_spoofers,
                    'jammers': total_jammers,
                    'sensors_active': len(data['events_by_sensor'])
                }

        return jsonify(data)
    except Exception as e:
        logging.error(f"Failed to get analytics data: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/tiles/<int:z>/<int:x>/<int:y>.png')
def serve_tile(z, x, y):
    """Serve map tiles from local cache for offline operation"""
    tile_path = os.path.join('map_tiles', str(z), str(x), f'{y}.png')

    if os.path.exists(tile_path):
        return send_file(tile_path, mimetype='image/png')
    else:
        # Return 404 if tile doesn't exist
        return '', 404


@app.route('/api/sensors')
@login_required
def get_sensors():
    """Get all sensors from database, filtered by user permissions"""
    try:
        db_sensors = db_manager.get_all_sensors()
        # Filter sensors by user permissions
        if not current_user.is_admin():
            db_sensors = [s for s in db_sensors if current_user.can_access_sensor(s['id'])]
        return jsonify({
            'count': len(db_sensors),
            'sensors': db_sensors
        })
    except Exception as e:
        logging.error(f"Failed to load sensors from database: {e}")
        # Fallback to in-memory, still filtered
        filtered_sensors = list(sensors.values())
        if not current_user.is_admin():
            filtered_sensors = [s for s in filtered_sensors if current_user.can_access_sensor(s['id'])]
        return jsonify({
            'count': len(filtered_sensors),
            'sensors': filtered_sensors
        })


@app.route('/api/events')
def get_events():
    """Get recent events from database"""
    limit = request.args.get('limit', 1000, type=int)

    try:
        events_list = db_manager.get_events(limit=limit)
        return jsonify({
            'count': len(events_list),
            'events': events_list
        })
    except Exception as e:
        logging.error(f"Failed to load events from database: {e}")
        # Fallback to in-memory
        events_list = [events[event_id] for event_id in event_order if event_id in events]
        return jsonify({
            'count': len(events_list),
            'events': events_list
        })


@app.route('/api/events/<event_id>')
def get_event(event_id):
    """Get specific event by ID"""
    if event_id in events:
        return jsonify(events[event_id])
    return jsonify({'error': 'Event not found'}), 404


@app.route('/api/stats')
def get_stats():
    """Get statistics about events from database"""
    try:
        db_stats = db_manager.get_stats()
        db_sensors = db_manager.get_all_sensors()

        # Combine database stats with WSS status
        stats = {
            'total_events': sum(s.get('count', 0) for s in db_stats.values()),
            'spoofer_count': db_stats.get('spoofer', {}).get('count', 0),
            'jammer_count': db_stats.get('jammer', {}).get('count', 0),
            'avg_spoofer_power': db_stats.get('spoofer', {}).get('avg_power'),
            'avg_jammer_power': db_stats.get('jammer', {}).get('avg_power'),
            'sensors': db_sensors,
            'wss_servers': wss_connections_status
        }

        return jsonify(stats)

    except Exception as e:
        logging.error(f"Failed to load stats from database: {e}")
        # Fallback to in-memory calculation
        if not events:
            return jsonify({
                'total_events': 0,
                'spoofer_count': 0,
                'jammer_count': 0,
                'sensors': list(sensors.values()),
                'wss_servers': wss_connections_status
            })

        spoofer_count = sum(1 for e in events.values() if e.get('eventType') == 'spoofer')
        jammer_count = sum(1 for e in events.values() if e.get('eventType') == 'jammer')

        return jsonify({
            'total_events': len(events),
            'spoofer_count': spoofer_count,
            'jammer_count': jammer_count,
            'sensors': list(sensors.values()),
            'wss_servers': wss_connections_status
        })


@app.route('/api/history')
def get_history():
    """Get ended events within dashboard retention period for history table"""
    # For now, return empty array - will be populated from database in future
    # This endpoint will be used when we implement event end_time tracking in database
    return jsonify({
        'count': 0,
        'events': []
    })


@socketio.on('connect')
def handle_connect():
    """Handle WebSocket connection"""
    # Auto-login for SocketIO when login is disabled
    if app.config.get('LOGIN_DISABLED') and not current_user.is_authenticated:
        from auth import User
        login_user(User('admin', 'admin', ['*']))

    # Check if user is authenticated
    if not current_user.is_authenticated:
        logging.warning('Unauthenticated WebSocket connection rejected')
        return False  # Reject connection

    username = current_user.username
    is_admin = current_user.is_admin()
    logging.info(f'Client connected: {username} (admin={is_admin})')

    emit('connection_response', {
        'status': 'connected',
        'wss_servers': wss_connections_status
    })

    # Send existing sensors to new client (from database), filtered by permissions
    try:
        db_sensors = db_manager.get_all_sensors()
        if not is_admin:
            db_sensors = [s for s in db_sensors if current_user.can_access_sensor(s['id'])]
        emit('initial_sensors', {'sensors': db_sensors})
    except Exception as e:
        logging.error(f"Failed to load sensors from database: {e}")
        # Fallback to in-memory, still filtered
        filtered_sensors = list(sensors.values())
        if not is_admin:
            filtered_sensors = [s for s in filtered_sensors if current_user.can_access_sensor(s['id'])]
        emit('initial_sensors', {'sensors': filtered_sensors})

    # Get user's allowed sensor IDs for filtering batches
    allowed_sensors = None
    if not is_admin:
        allowed_sensors = set(current_user.sensors)
        if '*' in allowed_sensors:
            allowed_sensors = None  # All sensors allowed

    # Send batches within retention period to restore state (from database)
    try:
        db_batches = db_manager.get_batches_since(hours=DASHBOARD_RETENTION_HOURS)
        db_readings_count = db_manager.get_readings_count_since(hours=DASHBOARD_RETENTION_HOURS)

        # Filter batches by allowed sensors
        if allowed_sensors is not None:
            filtered_batches = []
            for batch in db_batches:
                filtered_events = [e for e in batch.get('events', [])
                                   if e.get('idSensor') in allowed_sensors]
                if filtered_events:
                    filtered_batches.append({
                        'events': filtered_events,
                        'timestamp': batch.get('timestamp')
                    })
            db_batches = filtered_batches
            # Also filter readings count
            db_readings_count = {k: v for k, v in db_readings_count.items()
                                 if any(sensor in k for sensor in allowed_sensors)}

        if db_batches:
            emit('initial_batches', {
                'batches': db_batches,
                'readings_count': db_readings_count
            })
            logging.info(f'Sent {len(db_batches)} batches from database to {username}')
    except Exception as e:
        logging.error(f"Failed to load batches from database: {e}")
        # Fallback to in-memory
        if event_batches:
            filtered_mem_batches = event_batches
            if allowed_sensors is not None:
                filtered_mem_batches = []
                for batch in event_batches:
                    filtered_events = [e for e in batch.get('events', [])
                                       if e.get('idSensor') in allowed_sensors]
                    if filtered_events:
                        filtered_mem_batches.append({
                            'events': filtered_events,
                            'timestamp': batch.get('timestamp')
                        })
            emit('initial_batches', {
                'batches': filtered_mem_batches,
                'readings_count': event_readings_count
            })
            logging.info(f'Sent {len(filtered_mem_batches)} batches from memory to {username}')


@socketio.on('disconnect')
def handle_disconnect():
    """Handle WebSocket disconnection"""
    logging.info('Client disconnected')


@socketio.on('request_events')
def handle_request_events(data):
    """Send events to client"""
    limit = data.get('limit', 100)
    events_list = [events[event_id] for event_id in event_order if event_id in events]

    # Send most recent events
    events_slice = events_list[-limit:] if len(events_list) > limit else events_list

    emit('events_data', {
        'events': events_slice,
        'total': len(events)
    })


# Start WSS connection when module is loaded (works for both dev and production)
start_wss_thread()

# Start archival scheduler (runs daily at midnight)
try:
    from apscheduler.schedulers.background import BackgroundScheduler
    import archiver

    scheduler = BackgroundScheduler()
    # Schedule archival to run daily at midnight (UTC)
    scheduler.add_job(
        archiver.archive_old_events,
        'cron',
        hour=0,
        minute=0,
        id='daily_archival',
        name='Archive events older than 30 days'
    )
    scheduler.start()
    logging.info("Archival scheduler started (runs daily at midnight UTC)")
except Exception as e:
    logging.error(f"Failed to start archival scheduler: {e}")
    logging.warning("Archival will not run automatically - use manual execution")

if __name__ == '__main__':
    # Development mode only - use production server (gunicorn) for deployment
    import sys
    logging.info("=" * 60)
    logging.info("DEVELOPMENT MODE")
    logging.info("=" * 60)
    logging.info("Starting development server on http://localhost:8080")
    logging.info("For production, use: ./start_production.sh")
    logging.info("=" * 60)

    socketio.run(app, debug=True, host='0.0.0.0', port=8080, allow_unsafe_werkzeug=True, use_reloader=False)
