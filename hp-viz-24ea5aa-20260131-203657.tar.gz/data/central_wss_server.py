#!/usr/bin/env python3
"""
Central WebSocket Secure Server for UHU Visualization
Receives sensor data from upstream processes (CEF via TCP) and relays to dashboard (JSON via WSS)
"""

import asyncio
import websockets
import json
import logging
import socketserver
import threading
import ssl
import time
import ast
from queue import Queue, Empty
from typing import Set
from datetime import datetime

# Import configuration
from central_wss_config import *

# -----------------------------------------------------------------------------
# Logging
# -----------------------------------------------------------------------------
logging.basicConfig(
    level=getattr(logging, LOG_LEVEL),
    format="%(asctime)s - %(levelname)s - %(message)s"
)

# -----------------------------------------------------------------------------
# Global State
# -----------------------------------------------------------------------------
event_queue = Queue(maxsize=MAX_QUEUE_SIZE)
dashboard_clients: Set[websockets.WebSocketServerProtocol] = set()
dashboard_clients_lock = asyncio.Lock()

# Statistics
stats = {
    'cef_messages_received': 0,
    'events_processed': 0,
    'batches_sent': 0,
    'dashboard_clients_count': 0
}

# -----------------------------------------------------------------------------
# CEF Parsing and Transformation
# -----------------------------------------------------------------------------

def parse_cef(message: str):
    """
    Yield dicts of extended fields from CEF lines.
    Lines: CEF:...|...|...|...|...|...|...|k1=v1;k2=v2;...
    Returns all key-value pairs from the extended fields section.

    Based on ws_server.py reference implementation.
    """
    for line in message.splitlines():
        line = line.strip()
        if not line.startswith("CEF:"):
            continue

        parts = line.split("|")
        if len(parts) < 8:
            logging.warning("Skipping malformed CEF (no extended fields): %s", line[:100])
            continue

        extended = parts[7]
        fields = {}

        for kv in extended.split(";"):
            kv = kv.strip()
            if not kv:
                continue
            if "=" in kv:
                k, v = kv.split("=", 1)
                fields[k.strip()] = v.strip()

        if fields:
            yield fields


def detect_event_type(event_id: str) -> str:
    """Detect jammer vs spoofer from event ID"""
    if not event_id:
        return "unknown"

    event_id_upper = event_id.upper()
    if "JAMMER" in event_id_upper:
        return "jammer"
    elif "SPOOFER" in event_id_upper:
        return "spoofer"
    return "unknown"


def transform_cef_to_event(cef_fields: dict) -> dict:
    """
    Transform CEF extended fields to dashboard event format.

    CEF field names already match dashboard JSON exactly!
    Just need to:
    1. Parse Python list strings (e.g., "[1575420000.0]" → [1575420000.0])
    2. Convert numeric strings to proper types
    3. Pass through string fields as-is

    Args:
        cef_fields: Dict of CEF extended fields (k=v pairs)

    Returns:
        Dict in dashboard's expected JSON format
    """
    event = {}

    # List fields that come as Python list strings in CEF
    list_fields = [
        'frequency', 'power', 'signalIds',
        'constellationXPoints', 'constellationYPoints'
    ]

    # Numeric fields that need type conversion
    float_fields = [
        'azimuth', 'azimuthUnc', 'elevation', 'range',
        'senlat', 'senlon', 'senalt'
    ]

    for key, value in cef_fields.items():
        if key in list_fields:
            # Parse Python list string: "[1575420000.0]" → [1575420000.0]
            try:
                event[key] = ast.literal_eval(value)
                # Ensure it's a list
                if not isinstance(event[key], list):
                    event[key] = [event[key]]
            except Exception as e:
                logging.warning(f"Failed to parse list field '{key}': {value} - {e}")
                # Fallback to single-item list
                event[key] = [value] if value else []
        elif key in float_fields:
            # Convert to float
            try:
                event[key] = float(value)
            except Exception as e:
                logging.warning(f"Failed to parse float field '{key}': {value} - {e}")
                event[key] = 0.0
        else:
            # Pass through as-is (strings like id, obTime, idSensor, etc.)
            event[key] = value

    # Auto-add eventType if not present
    if 'eventType' not in event and 'id' in event:
        event['eventType'] = detect_event_type(event['id'])

    return event


# -----------------------------------------------------------------------------
# TCP CEF Server
# -----------------------------------------------------------------------------

class CEFHandler(socketserver.BaseRequestHandler):
    """
    Receives CEF over TCP from upstream sensor processes.
    Parses CEF extended fields and transforms to dashboard JSON format.
    Queues events for WebSocket relay to dashboard clients.
    """

    def handle(self):
        data = b""
        try:
            while True:
                chunk = self.request.recv(TCP_BUFFER_SIZE)
                if not chunk:
                    break
                data += chunk
        except Exception as e:
            logging.error("Error receiving data: %s", e)
            return

        try:
            message = data.decode("utf-8", errors="ignore")
            stats['cef_messages_received'] += 1

            event_count = 0
            for cef_fields in parse_cef(message):
                # Transform CEF to JSON event format
                event = transform_cef_to_event(cef_fields)

                # Debug: Log the transformed event
                logging.debug(f"Transformed event: {json.dumps(event, indent=2)}")

                # Queue for WebSocket relay
                try:
                    event_queue.put_nowait(event)
                    event_count += 1
                    stats['events_processed'] += 1
                except Exception as e:
                    logging.warning(f"Event queue full, dropping event: {e}")

            if event_count > 0:
                logging.info(f"Received and queued {event_count} events from CEF message")
            else:
                logging.warning("Received CEF message but parsed 0 events")

        except Exception as e:
            logging.error(f"Unexpected error processing CEF: {e}")


def start_tcp_server(host=TCP_HOST, port=TCP_PORT):
    """Start TCP server for CEF input"""
    with socketserver.TCPServer((host, port), CEFHandler) as server:
        logging.info(f"TCP Server listening on {host}:{port}")
        server.serve_forever()


# -----------------------------------------------------------------------------
# Event Batching and Processing
# -----------------------------------------------------------------------------

def create_batch(events: list):
    """
    Create batch format expected by dashboard.

    Dashboard expects events as a list, not wrapped in a batch object.

    Args:
        events: List of event dicts

    Returns:
        List of events (dashboard will create its own batch wrapper)
    """
    # Dashboard expects just the events array
    # It will handle batching internally
    return events


async def process_events():
    """
    Read events from queue and create batches for dashboard broadcast.
    Runs continuously in background.
    """
    logging.info("Event processor started")

    while True:
        events = []

        # Drain queue with timeout
        try:
            # Wait for first event with timeout
            event = await asyncio.get_event_loop().run_in_executor(
                None, event_queue.get, True, BATCH_INTERVAL_SECONDS
            )
            events.append(event)

            # Drain remaining events up to MAX_BATCH_SIZE (non-blocking)
            while len(events) < MAX_BATCH_SIZE:
                try:
                    event = event_queue.get_nowait()
                    events.append(event)
                except Empty:
                    break

        except Empty:
            # Timeout, no events received
            pass

        # If we have events, create batch and broadcast
        if events:
            batch = create_batch(events)  # Returns list of events
            logging.debug(f"Events to send: {json.dumps(batch, indent=2)}")
            await broadcast_to_dashboards(batch)
            stats['batches_sent'] += 1
            logging.info(f"Sent {len(events)} events to {len(dashboard_clients)} clients")


# -----------------------------------------------------------------------------
# WebSocket Server for Dashboard Clients
# -----------------------------------------------------------------------------

async def broadcast_to_dashboards(batch_data):
    """
    Send batch to all connected dashboard clients.

    Args:
        batch_data: List of event dicts (dashboard expects array format)
    """
    if not dashboard_clients:
        logging.debug("No dashboard clients connected, skipping broadcast")
        return

    message = json.dumps(batch_data, separators=(',', ':'))
    disconnected = []

    async with dashboard_clients_lock:
        for client in dashboard_clients:
            try:
                await client.send(message)
            except websockets.exceptions.ConnectionClosed:
                logging.info(f"Dashboard client disconnected: {client.remote_address}")
                disconnected.append(client)
            except Exception as e:
                logging.warning(f"Error sending to dashboard client: {e}")
                disconnected.append(client)

        # Clean up disconnected clients
        for client in disconnected:
            dashboard_clients.discard(client)
            stats['dashboard_clients_count'] = len(dashboard_clients)


async def dashboard_handler(websocket):
    """
    Handle dashboard client WebSocket connections.
    Keeps connection alive and manages client tracking.
    """
    peer = websocket.remote_address
    logging.info(f"Dashboard client connected: {peer}")

    async with dashboard_clients_lock:
        dashboard_clients.add(websocket)
        stats['dashboard_clients_count'] = len(dashboard_clients)

    try:
        # Send keepalive messages periodically
        while True:
            try:
                # Wait for client disconnect or send keepalive
                await asyncio.wait_for(websocket.wait_closed(), timeout=KEEPALIVE_INTERVAL_SECONDS)
                break  # Client disconnected
            except asyncio.TimeoutError:
                # Send keepalive
                try:
                    await websocket.send('{"type":"keepalive"}')
                except Exception as e:
                    logging.info(f"Keepalive failed, client {peer} disconnected: {e}")
                    break

    except websockets.exceptions.ConnectionClosed:
        logging.info(f"Dashboard client disconnected: {peer}")
    except Exception as e:
        logging.warning(f"Dashboard client error: {e}")
    finally:
        async with dashboard_clients_lock:
            dashboard_clients.discard(websocket)
            stats['dashboard_clients_count'] = len(dashboard_clients)
        logging.info(f"Dashboard client cleanup done for {peer}")


async def start_websocket_server(host=WSS_HOST, port=WSS_PORT):
    """Start WebSocket Secure server for dashboard clients"""
    # Setup SSL context
    ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ssl_context.load_cert_chain(certfile=CERT_FILE, keyfile=KEY_FILE)
    ssl_context.check_hostname = False
    ssl_context.verify_mode = ssl.CERT_NONE

    server = await websockets.serve(
        dashboard_handler,
        host,
        port,
        ssl=ssl_context,
        ping_interval=None,  # We handle keepalive manually
        max_queue=None
    )

    logging.info(f"WebSocket Server listening on wss://{host}:{port}")
    await server.wait_closed()


# -----------------------------------------------------------------------------
# Statistics Reporting
# -----------------------------------------------------------------------------

async def report_stats():
    """Periodically log statistics"""
    while True:
        await asyncio.sleep(60)  # Report every minute
        logging.info(
            f"Stats - CEF messages: {stats['cef_messages_received']}, "
            f"Events: {stats['events_processed']}, "
            f"Batches: {stats['batches_sent']}, "
            f"Clients: {stats['dashboard_clients_count']}, "
            f"Queue: {event_queue.qsize()}/{MAX_QUEUE_SIZE}"
        )


# -----------------------------------------------------------------------------
# Main Entry Point
# -----------------------------------------------------------------------------

def run_tcp_server():
    """Run TCP server in dedicated thread"""
    t = threading.Thread(
        target=start_tcp_server,
        kwargs={"host": TCP_HOST, "port": TCP_PORT},
        daemon=True
    )
    t.start()
    logging.info("TCP server thread started")


async def main():
    """Main async event loop"""
    logging.info("=" * 70)
    logging.info("Central WSS Server for UHU Visualization")
    logging.info("=" * 70)
    logging.info(f"TCP Input: {TCP_HOST}:{TCP_PORT}")
    logging.info(f"WSS Output: wss://{WSS_HOST}:{WSS_PORT}")
    logging.info(f"Queue Size: {MAX_QUEUE_SIZE}")
    logging.info(f"Batch Interval: {BATCH_INTERVAL_SECONDS}s")
    logging.info("=" * 70)

    # Start TCP server in background thread
    run_tcp_server()

    # Start event processor
    asyncio.create_task(process_events())

    # Start statistics reporter
    asyncio.create_task(report_stats())

    # Start WebSocket server for dashboards (blocks until server closes)
    await start_websocket_server()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logging.info("Shutting down gracefully...")
        exit(0)
