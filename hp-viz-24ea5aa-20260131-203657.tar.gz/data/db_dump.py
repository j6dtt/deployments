#!/usr/bin/env python3
"""
Database Dump & Restore Tool for GNSS Interference Visualization

Usage:
    # Dump database to JSON files in dump/ directory
    python db_dump.py dump

    # Restore database from dump/ directory (creates new db)
    python db_dump.py restore

    # Dump to custom directory
    python db_dump.py dump --dir /path/to/dump

    # Restore from custom directory
    python db_dump.py restore --dir /path/to/dump

    # Show dump statistics
    python db_dump.py info --dir dump
"""

import sqlite3
import json
import os
import sys
import time
import argparse
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(SCRIPT_DIR, 'event_data.db')
DEFAULT_DUMP_DIR = os.path.join(SCRIPT_DIR, 'dump')
DB_VERSION = 1

TABLES = ['event_batches', 'events', 'sensors', 'event_metadata', 'schema_version']


def dump_database(db_path, dump_dir):
    """Dump all tables from SQLite database to JSON files."""
    if not os.path.exists(db_path):
        logging.error(f"Database not found: {db_path}")
        sys.exit(1)

    os.makedirs(dump_dir, exist_ok=True)

    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    total_rows = 0
    manifest = {
        'dump_time': time.time(),
        'dump_time_utc': time.strftime('%Y-%m-%d %H:%M:%S UTC', time.gmtime()),
        'db_path': db_path,
        'tables': {}
    }

    for table in TABLES:
        try:
            cursor.execute(f'SELECT COUNT(*) FROM {table}')
            count = cursor.fetchone()[0]
        except sqlite3.OperationalError:
            logging.warning(f"Table '{table}' does not exist, skipping")
            continue

        cursor.execute(f'SELECT * FROM {table}')
        rows = [dict(row) for row in cursor.fetchall()]

        file_path = os.path.join(dump_dir, f'{table}.json')
        with open(file_path, 'w') as f:
            json.dump(rows, f, indent=2)

        manifest['tables'][table] = count
        total_rows += count
        logging.info(f"  {table}: {count} rows")

    # Write manifest
    manifest['total_rows'] = total_rows
    with open(os.path.join(dump_dir, 'manifest.json'), 'w') as f:
        json.dump(manifest, f, indent=2)

    conn.close()
    logging.info(f"Dump complete: {total_rows} total rows -> {dump_dir}/")


def restore_database(db_path, dump_dir):
    """Restore database from JSON dump files."""
    manifest_path = os.path.join(dump_dir, 'manifest.json')
    if not os.path.exists(manifest_path):
        logging.error(f"Manifest not found: {manifest_path}")
        logging.error("Is this a valid dump directory?")
        sys.exit(1)

    with open(manifest_path, 'r') as f:
        manifest = json.load(f)

    logging.info(f"Restoring from dump created: {manifest.get('dump_time_utc', 'unknown')}")

    if os.path.exists(db_path):
        backup_path = db_path + '.backup'
        os.rename(db_path, backup_path)
        logging.info(f"Existing database backed up to: {backup_path}")

    # Create fresh database with schema
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute('PRAGMA journal_mode=WAL')
    cursor.execute('PRAGMA synchronous=NORMAL')

    # Create tables
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS event_batches (
            batch_id INTEGER PRIMARY KEY AUTOINCREMENT,
            batch_timestamp REAL NOT NULL,
            batch_data TEXT NOT NULL,
            created_at REAL NOT NULL
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS events (
            event_id TEXT PRIMARY KEY,
            sensor_id TEXT NOT NULL,
            event_type TEXT NOT NULL CHECK(event_type IN ('spoofer', 'jammer', 'unknown')),
            batch_timestamp REAL NOT NULL,
            event_data TEXT NOT NULL,
            ob_time TEXT NOT NULL,
            created_at REAL NOT NULL
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS sensors (
            sensor_id TEXT PRIMARY KEY,
            sensor_data TEXT NOT NULL,
            first_seen REAL NOT NULL,
            last_seen REAL NOT NULL
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS event_metadata (
            event_id TEXT PRIMARY KEY,
            total_readings INTEGER DEFAULT 0,
            first_seen REAL NOT NULL,
            last_seen REAL NOT NULL,
            FOREIGN KEY (event_id) REFERENCES events(event_id) ON DELETE CASCADE
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS schema_version (
            version INTEGER PRIMARY KEY,
            applied_at REAL NOT NULL
        )
    ''')

    # Create indexes
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_batches_timestamp ON event_batches(batch_timestamp)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_batches_created_at ON event_batches(created_at)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_events_batch_ts ON events(batch_timestamp)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_events_created_at ON events(created_at)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_events_sensor ON events(sensor_id)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_events_type ON events(event_type)')

    conn.commit()

    # Column mappings for each table (order matters for INSERT)
    table_columns = {
        'event_batches': ['batch_id', 'batch_timestamp', 'batch_data', 'created_at'],
        'events': ['event_id', 'sensor_id', 'event_type', 'batch_timestamp', 'event_data', 'ob_time', 'created_at'],
        'sensors': ['sensor_id', 'sensor_data', 'first_seen', 'last_seen'],
        'event_metadata': ['event_id', 'total_readings', 'first_seen', 'last_seen'],
        'schema_version': ['version', 'applied_at'],
    }

    total_rows = 0

    # Restore order: schema_version, sensors, event_batches, events, event_metadata
    restore_order = ['schema_version', 'sensors', 'event_batches', 'events', 'event_metadata']

    for table in restore_order:
        file_path = os.path.join(dump_dir, f'{table}.json')
        if not os.path.exists(file_path):
            logging.warning(f"Dump file not found: {file_path}, skipping")
            continue

        with open(file_path, 'r') as f:
            rows = json.load(f)

        if not rows:
            logging.info(f"  {table}: 0 rows (empty)")
            continue

        columns = table_columns[table]
        placeholders = ', '.join(['?'] * len(columns))
        col_names = ', '.join(columns)

        for row in rows:
            values = [row.get(col) for col in columns]
            try:
                cursor.execute(f'INSERT OR REPLACE INTO {col_names.split(",")[0].strip().split(" ")[0] and table} ({col_names}) VALUES ({placeholders})', values)
            except sqlite3.IntegrityError as e:
                logging.warning(f"  Skipped row in {table}: {e}")

        conn.commit()
        total_rows += len(rows)
        logging.info(f"  {table}: {len(rows)} rows restored")

    conn.close()
    logging.info(f"Restore complete: {total_rows} total rows -> {db_path}")


def show_info(dump_dir):
    """Show dump statistics."""
    manifest_path = os.path.join(dump_dir, 'manifest.json')
    if not os.path.exists(manifest_path):
        logging.error(f"No dump found at: {dump_dir}")
        sys.exit(1)

    with open(manifest_path, 'r') as f:
        manifest = json.load(f)

    print(f"\nDump Info:")
    print(f"  Created:  {manifest.get('dump_time_utc', 'unknown')}")
    print(f"  Source:   {manifest.get('db_path', 'unknown')}")
    print(f"  Total:    {manifest.get('total_rows', 0)} rows")
    print(f"\nTables:")
    for table, count in manifest.get('tables', {}).items():
        print(f"  {table:20s} {count:>8,} rows")
    print()


def main():
    parser = argparse.ArgumentParser(description='Database Dump & Restore Tool')
    parser.add_argument('command', choices=['dump', 'restore', 'info'],
                        help='dump: export db to JSON, restore: create db from JSON, info: show dump stats')
    parser.add_argument('--dir', default=DEFAULT_DUMP_DIR,
                        help=f'Dump directory (default: {DEFAULT_DUMP_DIR})')
    parser.add_argument('--db', default=DB_PATH,
                        help=f'Database path (default: {DB_PATH})')

    args = parser.parse_args()

    if args.command == 'dump':
        logging.info(f"Dumping {args.db} -> {args.dir}/")
        dump_database(args.db, args.dir)
    elif args.command == 'restore':
        logging.info(f"Restoring {args.dir}/ -> {args.db}")
        restore_database(args.db, args.dir)
    elif args.command == 'info':
        show_info(args.dir)


if __name__ == '__main__':
    main()
