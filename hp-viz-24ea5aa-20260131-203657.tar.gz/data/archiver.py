"""
Archival System for GNSS Interference Visualization
Automatically archives events older than configured retention period to JSON files
"""

import os
import json
import logging
import configparser
from datetime import datetime
import db_manager

# Load configuration
config = configparser.ConfigParser()
config_file = os.path.join(os.path.dirname(__file__), 'config.ini')
config.read(config_file)

# Configuration
ARCHIVE_DIR = '/app/archives'
RETENTION_DAYS = config.getint('retention', 'database_days', fallback=30)


def archive_old_events():
    """
    Archive events older than retention period to JSON files, then delete from database

    This function:
    1. Queries events older than RETENTION_DAYS from database
    2. Groups events by date for organized archive files
    3. Writes to /app/archives/events_YYYY-MM-DD.json
    4. Deletes archived events from database

    Returns:
        int: Number of events archived
    """
    logging.info("=" * 60)
    logging.info(f"Starting archival process (retention: {RETENTION_DAYS} days)...")
    logging.info("=" * 60)

    try:
        # Ensure archive directory exists
        os.makedirs(ARCHIVE_DIR, exist_ok=True)
        logging.info(f"Archive directory: {ARCHIVE_DIR}")

        # Get old events from database
        old_events = db_manager.get_old_events(days=RETENTION_DAYS)

        if not old_events:
            logging.info(f"No events to archive (all events within {RETENTION_DAYS}-day retention)")
            return 0

        logging.info(f"Found {len(old_events)} events older than {RETENTION_DAYS} days")

        # Group events by date for separate archive files
        events_by_date = {}
        for event in old_events:
            # Use batch timestamp to determine archive file date
            batch_timestamp = event.get('_batch_timestamp')
            if batch_timestamp:
                date_str = datetime.fromtimestamp(batch_timestamp).strftime('%Y-%m-%d')
            else:
                # Fallback to obTime if batch timestamp not available
                ob_time = event.get('obTime', '')
                if ob_time:
                    date_str = ob_time.split('T')[0]
                else:
                    date_str = 'unknown-date'

            if date_str not in events_by_date:
                events_by_date[date_str] = []

            # Remove internal timestamp field before archiving
            event_copy = event.copy()
            event_copy.pop('_batch_timestamp', None)
            events_by_date[date_str].append(event_copy)

        # Write archive files
        archived_count = 0
        archive_files = []

        for date_str, events in sorted(events_by_date.items()):
            archive_file = os.path.join(ARCHIVE_DIR, f'events_{date_str}.json')

            # If file exists, append to it (merge with existing archived events)
            if os.path.exists(archive_file):
                logging.info(f"Appending to existing archive: {archive_file}")
                try:
                    with open(archive_file, 'r') as f:
                        existing_events = json.load(f)
                    events = existing_events + events
                except Exception as e:
                    logging.warning(f"Could not read existing archive {archive_file}: {e}")
                    # Continue with new events only

            # Write archive file
            try:
                with open(archive_file, 'w') as f:
                    json.dump(events, f, indent=2)

                archived_count += len(events)
                archive_files.append(archive_file)
                logging.info(f"✓ Archived {len(events)} events to {archive_file}")

            except IOError as e:
                logging.error(f"✗ Failed to write archive file {archive_file}: {e}")
                logging.error("Aborting archival - events will remain in database")
                return 0

        # Only delete from database after successful archival
        logging.info(f"Deleting archived events from database...")
        deleted_count = db_manager.delete_old_events(days=RETENTION_DAYS)

        logging.info("=" * 60)
        logging.info("Archival complete!")
        logging.info(f"  - Events archived: {archived_count}")
        logging.info(f"  - Events deleted: {deleted_count}")
        logging.info(f"  - Archive files: {len(archive_files)}")
        logging.info("=" * 60)

        return archived_count

    except Exception as e:
        logging.error(f"Archival process failed: {e}")
        logging.error("Events remain in database")
        return 0


def list_archives():
    """
    List all archive files

    Returns:
        list: List of archive file information dicts
    """
    if not os.path.exists(ARCHIVE_DIR):
        return []

    archives = []
    for filename in sorted(os.listdir(ARCHIVE_DIR)):
        if filename.startswith('events_') and filename.endswith('.json'):
            filepath = os.path.join(ARCHIVE_DIR, filename)
            file_size = os.path.getsize(filepath)

            # Extract date from filename
            date_str = filename.replace('events_', '').replace('.json', '')

            # Count events in file
            try:
                with open(filepath, 'r') as f:
                    events = json.load(f)
                event_count = len(events)
            except:
                event_count = 0

            archives.append({
                'filename': filename,
                'date': date_str,
                'size_kb': round(file_size / 1024, 1),
                'event_count': event_count,
                'path': filepath
            })

    return archives


def get_archive_stats():
    """
    Get statistics about archived events

    Returns:
        dict: Archive statistics
    """
    archives = list_archives()

    total_events = sum(a['event_count'] for a in archives)
    total_size_kb = sum(a['size_kb'] for a in archives)

    return {
        'total_archive_files': len(archives),
        'total_archived_events': total_events,
        'total_size_kb': round(total_size_kb, 1),
        'oldest_archive': archives[0]['date'] if archives else None,
        'newest_archive': archives[-1]['date'] if archives else None,
        'archives': archives
    }


if __name__ == '__main__':
    # Manual execution for testing
    import sys

    # Set up logging for manual execution
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )

    if len(sys.argv) > 1 and sys.argv[1] == 'stats':
        # Show archive statistics
        stats = get_archive_stats()
        print("\n=== Archive Statistics ===")
        print(f"Total archive files: {stats['total_archive_files']}")
        print(f"Total archived events: {stats['total_archived_events']}")
        print(f"Total size: {stats['total_size_kb']} KB")
        print(f"Date range: {stats['oldest_archive']} to {stats['newest_archive']}")
        print("\nArchive files:")
        for archive in stats['archives']:
            print(f"  - {archive['filename']}: {archive['event_count']} events ({archive['size_kb']} KB)")
    else:
        # Run archival process
        print("\n=== Manual Archival Execution ===")
        print("This will archive events older than 30 days to JSON files.\n")
        archived = archive_old_events()
        print(f"\nArchival complete: {archived} events archived")
