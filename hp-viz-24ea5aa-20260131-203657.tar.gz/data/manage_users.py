#!/usr/bin/env python3
"""
CLI tool to manage user accounts for GNSS Interference Visualization
Run inside container with: docker exec -it uhu-viz python manage_users.py
"""
import argparse
import getpass
import json
import sys
from werkzeug.security import generate_password_hash

USERS_FILE = '/app/users.json'


def load_users():
    """Load users from JSON config file"""
    try:
        with open(USERS_FILE) as f:
            return json.load(f)
    except FileNotFoundError:
        return {"users": {}}
    except json.JSONDecodeError:
        print(f"Error: Invalid JSON in {USERS_FILE}")
        sys.exit(1)


def save_users(data):
    """Save users to JSON config file"""
    with open(USERS_FILE, 'w') as f:
        json.dump(data, f, indent=2)


def cmd_add(args):
    """Add a new user"""
    # Prompt for password securely if not provided
    if args.pwd:
        password = args.pwd
    else:
        try:
            password = getpass.getpass('Password: ')
            confirm = getpass.getpass('Confirm password: ')
        except KeyboardInterrupt:
            print('\n\nCancelled.')
            sys.exit(0)
        if password != confirm:
            print('Error: Passwords do not match')
            sys.exit(1)

    if not password:
        print('Error: Password cannot be empty')
        sys.exit(1)

    sensors = args.sensors.split(',') if args.sensors else ['*']

    data = load_users()
    if args.user in data['users']:
        print(f"Error: User '{args.user}' already exists")
        sys.exit(1)

    data['users'][args.user] = {
        'password_hash': generate_password_hash(password),
        'role': args.role,
        'sensors': sensors
    }
    save_users(data)
    print(f"User '{args.user}' added successfully")
    print(f"  Role: {args.role}")
    print(f"  Sensors: {sensors}")


def cmd_list(args):
    """List all users"""
    data = load_users()
    if not data['users']:
        print('No users configured')
        print('')
        print('Add a user with:')
        print('  python manage_users.py add -u <username> -r admin')
        return

    print('Users:')
    print('-' * 60)
    for name, info in sorted(data['users'].items()):
        role = info.get('role', 'user')
        sensors = info.get('sensors', ['*'])
        role_display = f"[{role.upper()}]" if role == 'admin' else f"[{role}]"
        print(f"  {name:15} {role_display:8} sensors: {', '.join(sensors)}")
    print('-' * 60)
    print(f"Total: {len(data['users'])} user(s)")


def cmd_delete(args):
    """Delete a user"""
    data = load_users()
    if args.user not in data['users']:
        print(f"Error: User '{args.user}' not found")
        sys.exit(1)

    # Confirm deletion
    if not args.force:
        try:
            confirm = input(f"Delete user '{args.user}'? (y/N): ")
        except KeyboardInterrupt:
            print('\n\nCancelled.')
            sys.exit(0)
        if confirm.lower() != 'y':
            print('Cancelled')
            return

    del data['users'][args.user]
    save_users(data)
    print(f"User '{args.user}' deleted")


def cmd_passwd(args):
    """Change user password"""
    data = load_users()
    if args.user not in data['users']:
        print(f"Error: User '{args.user}' not found")
        sys.exit(1)

    try:
        password = getpass.getpass('New password: ')
        confirm = getpass.getpass('Confirm password: ')
    except KeyboardInterrupt:
        print('\n\nCancelled.')
        sys.exit(0)
    if password != confirm:
        print('Error: Passwords do not match')
        sys.exit(1)

    if not password:
        print('Error: Password cannot be empty')
        sys.exit(1)

    data['users'][args.user]['password_hash'] = generate_password_hash(password)
    save_users(data)
    print(f"Password updated for '{args.user}'")


def cmd_update(args):
    """Update user role or sensors"""
    data = load_users()
    if args.user not in data['users']:
        print(f"Error: User '{args.user}' not found")
        sys.exit(1)

    updated = False
    if args.role:
        data['users'][args.user]['role'] = args.role
        print(f"Updated role to: {args.role}")
        updated = True

    if args.sensors:
        sensors = args.sensors.split(',')
        data['users'][args.user]['sensors'] = sensors
        print(f"Updated sensors to: {sensors}")
        updated = True

    if updated:
        save_users(data)
        print(f"User '{args.user}' updated")
    else:
        print("No changes specified. Use -r/--role or -s/--sensors")


def main():
    parser = argparse.ArgumentParser(
        description='Manage user accounts for GNSS Interference Visualization',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Add admin user (password prompted securely)
  python manage_users.py add -u admin -r admin

  # Add regular user with specific sensors
  python manage_users.py add -u analyst -r user -s hp-bhr.10.4,hp-omn.15.4

  # List all users
  python manage_users.py list

  # Change user password
  python manage_users.py passwd -u admin

  # Update user sensors
  python manage_users.py update -u analyst -s hp-bhr.10.4

  # Delete user
  python manage_users.py delete -u analyst
""")

    subparsers = parser.add_subparsers(dest='command', help='Commands')

    # Add user
    add_parser = subparsers.add_parser('add', help='Add a new user')
    add_parser.add_argument('-u', '--user', required=True, help='Username')
    add_parser.add_argument('-p', '--pwd', help='Password (omit for secure prompt)')
    add_parser.add_argument('-r', '--role', default='user', choices=['admin', 'user'],
                            help='User role (default: user)')
    add_parser.add_argument('-s', '--sensors',
                            help='Comma-separated sensor IDs (omit for all sensors)')
    add_parser.set_defaults(func=cmd_add)

    # List users
    list_parser = subparsers.add_parser('list', help='List all users')
    list_parser.set_defaults(func=cmd_list)

    # Delete user
    del_parser = subparsers.add_parser('delete', help='Delete a user')
    del_parser.add_argument('-u', '--user', required=True, help='Username to delete')
    del_parser.add_argument('-f', '--force', action='store_true', help='Skip confirmation')
    del_parser.set_defaults(func=cmd_delete)

    # Change password
    passwd_parser = subparsers.add_parser('passwd', help='Change user password')
    passwd_parser.add_argument('-u', '--user', required=True, help='Username')
    passwd_parser.set_defaults(func=cmd_passwd)

    # Update user
    update_parser = subparsers.add_parser('update', help='Update user role or sensors')
    update_parser.add_argument('-u', '--user', required=True, help='Username')
    update_parser.add_argument('-r', '--role', choices=['admin', 'user'], help='New role')
    update_parser.add_argument('-s', '--sensors', help='New comma-separated sensor IDs')
    update_parser.set_defaults(func=cmd_update)

    args = parser.parse_args()

    if args.command:
        args.func(args)
    else:
        parser.print_help()


if __name__ == '__main__':
    main()
