"""
Configuration for Central WSS Server
Centralizes sensor data from upstream processes and broadcasts to dashboard
"""

# -----------------------------------------------------------------------------
# Input Configuration (how sensors send data to central WSS)
# -----------------------------------------------------------------------------
INPUT_METHOD = "tcp"  # "tcp", "http", or "websocket"
TCP_HOST = "0.0.0.0"
TCP_PORT = 6911  # Changed from 6910 due to port conflict

# -----------------------------------------------------------------------------
# Output Configuration (dashboard WSS connection)
# -----------------------------------------------------------------------------
WSS_HOST = "0.0.0.0"
WSS_PORT = 8766  # Changed from 8765 due to port conflict
CERT_FILE = "certs/cert.pem"
KEY_FILE = "certs/key.pem"

# -----------------------------------------------------------------------------
# Queue and Batching
# -----------------------------------------------------------------------------
MAX_QUEUE_SIZE = 1000
BATCH_INTERVAL_SECONDS = 0.1  # Send batch every 100ms
MAX_BATCH_SIZE = 100  # Maximum events per batch

# -----------------------------------------------------------------------------
# Keepalive Configuration
# -----------------------------------------------------------------------------
KEEPALIVE_INTERVAL_SECONDS = 10

# -----------------------------------------------------------------------------
# TCP Server Configuration
# -----------------------------------------------------------------------------
TCP_BUFFER_SIZE = 65535  # Same as ws_server.py reference

# -----------------------------------------------------------------------------
# Logging Configuration
# -----------------------------------------------------------------------------
LOG_LEVEL = "INFO"  # DEBUG, INFO, WARNING, ERROR
