#!/bin/bash
#
# UHU Visualization - Air-Gapped Deployment Tool
#
# Usage:
#   ./deploy.sh package              Build release tarball
#   ./deploy.sh install <tarball>    Install/update from tarball (preserves config)
#   ./deploy.sh backup               Backup protected files
#   ./deploy.sh restore              Restore protected files from backup
#
# Protected files (never overwritten):
#   data/config.ini
#   data/event_data.db
#   data/users.json
#   data/certs/*
#   data/archives/*
#   data/dump/*

set -euo pipefail

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
BACKUP_DIR="${SCRIPT_DIR}/.deploy-backup"
TIMESTAMP=$(date +%Y%m%d-%H%M%S)

# Files/dirs that must NOT be overwritten during deployment
PROTECTED=(
    "docker-compose.yml"
    "data/config.ini"
    "data/event_data.db"
    "data/users.json"
    "data/certs"
    "data/archives"
    "data/dump"
)

log_info()  { echo -e "${GREEN}[INFO]${NC}  $1"; }
log_warn()  { echo -e "${YELLOW}[WARN]${NC}  $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

#
# PACKAGE - create release tarball from current repo
#
cmd_package() {
    cd "$SCRIPT_DIR"

    # Get version info
    local commit
    commit=$(git rev-parse --short HEAD 2>/dev/null || echo "unknown")
    local branch
    branch=$(git branch --show-current 2>/dev/null || echo "unknown")
    local tarball="hp-viz-${commit}-${TIMESTAMP}.tar.gz"

    log_info "Packaging release from ${branch}@${commit}"

    # Create tar excluding protected/generated files
    tar czf "$tarball" \
        --exclude='data/config.ini' \
        --exclude='data/event_data.db' \
        --exclude='data/event_data.db-wal' \
        --exclude='data/event_data.db-shm' \
        --exclude='data/users.json' \
        --exclude='data/certs/*.pem' \
        --exclude='data/certs/*.key' \
        --exclude='data/certs/*.crt' \
        --exclude='data/archives/*' \
        --exclude='data/dump/*' \
        --exclude='data/__pycache__' \
        --exclude='__pycache__' \
        --exclude='.git' \
        --exclude='.gitignore' \
        --exclude='.claude' \
        --exclude='.deploy-backup' \
        --exclude='*.tar.gz' \
        --exclude='*.pyc' \
        deploy.sh \
        test_central_wss.py \
        docs/ \
        data/

    log_info "Package created: ${tarball}"
    log_info "Size: $(du -h "$tarball" | cut -f1)"
    echo ""
    log_info "Transfer this file to the production server and run:"
    echo "  ./deploy.sh install ${tarball}"
}

#
# BACKUP - save protected files before install
#
cmd_backup() {
    cd "$SCRIPT_DIR"

    local backup_path="${BACKUP_DIR}/${TIMESTAMP}"
    mkdir -p "$backup_path"

    local count=0
    for item in "${PROTECTED[@]}"; do
        if [ -e "$item" ]; then
            local dest_dir
            dest_dir="${backup_path}/$(dirname "$item")"
            mkdir -p "$dest_dir"
            cp -a "$item" "$dest_dir/"
            count=$((count + 1))
        fi
    done

    log_info "Backed up ${count} protected items to ${backup_path}"
    echo "$backup_path"
}

#
# RESTORE - restore protected files from latest backup
#
cmd_restore() {
    cd "$SCRIPT_DIR"

    if [ ! -d "$BACKUP_DIR" ]; then
        log_error "No backups found at ${BACKUP_DIR}"
        exit 1
    fi

    # Find latest backup
    local latest
    latest=$(ls -td "${BACKUP_DIR}"/*/ 2>/dev/null | head -1)
    if [ -z "$latest" ]; then
        log_error "No backup directories found"
        exit 1
    fi

    log_info "Restoring from: ${latest}"

    local count=0
    for item in "${PROTECTED[@]}"; do
        if [ -e "${latest}/${item}" ]; then
            local dest_dir
            dest_dir="$(dirname "$item")"
            mkdir -p "$dest_dir"
            cp -a "${latest}/${item}" "$dest_dir/"
            log_info "  Restored: ${item}"
            count=$((count + 1))
        fi
    done

    log_info "Restored ${count} protected items"
}

#
# INSTALL - extract tarball and preserve protected files
#
cmd_install() {
    local tarball="$1"

    if [ ! -f "$tarball" ]; then
        log_error "Tarball not found: ${tarball}"
        exit 1
    fi

    cd "$SCRIPT_DIR"

    log_info "Installing from: ${tarball}"
    echo ""

    # Step 1: Backup protected files
    log_info "Step 1/5: Backing up protected files..."
    local backup_path
    backup_path=$(cmd_backup)

    # Step 2: Stop containers
    log_info "Step 2/5: Stopping containers..."
    docker compose down 2>/dev/null || log_warn "docker compose down failed (containers may not be running)"

    # Step 3: Extract tarball (overwrites app files)
    log_info "Step 3/5: Extracting update..."
    tar xzf "$tarball" -C "$SCRIPT_DIR"

    # Step 4: Restore protected files
    log_info "Step 4/5: Restoring protected files..."
    for item in "${PROTECTED[@]}"; do
        if [ -e "${backup_path}/${item}" ]; then
            local dest_dir
            dest_dir="$(dirname "$item")"
            mkdir -p "$dest_dir"
            cp -a "${backup_path}/${item}" "$dest_dir/"
            log_info "  Preserved: ${item}"
        fi
    done

    # Ensure required dirs exist
    mkdir -p data/certs data/archives data/dump

    # Step 5: Start containers
    log_info "Step 5/5: Starting containers..."
    docker compose up -d

    echo ""
    log_info "Deployment complete!"
    log_info "Backup saved at: ${backup_path}"
    echo ""
    log_info "Verify with:"
    echo "  docker compose ps"
    echo "  docker compose logs -f"
}

#
# MAIN
#
usage() {
    echo "Usage: $0 <command> [args]"
    echo ""
    echo "Commands:"
    echo "  package              Build release tarball for transfer"
    echo "  install <tarball>    Install/update from tarball (preserves config)"
    echo "  backup               Backup protected files"
    echo "  restore              Restore protected files from latest backup"
    echo ""
    echo "Protected files (never overwritten):"
    echo "  data/config.ini, data/users.json, data/event_data.db"
    echo "  data/certs/*, data/archives/*, data/dump/*"
}

case "${1:-}" in
    package)
        cmd_package
        ;;
    install)
        if [ -z "${2:-}" ]; then
            log_error "Usage: $0 install <tarball>"
            exit 1
        fi
        cmd_install "$2"
        ;;
    backup)
        cmd_backup
        ;;
    restore)
        cmd_restore
        ;;
    *)
        usage
        exit 1
        ;;
esac
