# UHU Visualization Architecture

**Last Updated:** 2025-12-28
**Version:** 2.0 (Central WSS Server Architecture)

---

## Overview

The UHU Visualization system uses a **centralized hub architecture** where sensor data flows through a central WSS server before reaching the dashboard. This design supports multiple sensors, scales efficiently, and separates data ingestion from visualization.

## Current Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                     Upstream Sensor Processes                    │
│  (Sensor 1, Sensor 2, Sensor 3, ... Sensor N)                   │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             │ CEF Format (Common Event Format)
                             │ TCP Port 6911
                             ▼
          ┌──────────────────────────────────────┐
          │     Central WSS Server               │
          │  (central_wss_server.py)             │
          │                                      │
          │  • Receives CEF via TCP              │
          │  • Parses and transforms to JSON     │
          │  • Queues and batches events         │
          │  • Broadcasts via WebSocket Secure   │
          └──────────────────┬───────────────────┘
                             │
                             │ JSON Format (Event Arrays)
                             │ WSS Port 8766
                             ▼
          ┌──────────────────────────────────────┐
          │     Dashboard Backend                │
          │  (app.py)                            │
          │                                      │
          │  • Receives JSON event batches       │
          │  • Processes and stores events       │
          │  • Auto-detects sensors              │
          │  • Manages database (SQLite)         │
          │  • Broadcasts to browser clients     │
          └──────────────────┬───────────────────┘
                             │
                             │ SocketIO + HTTPS
                             │ Port 8043
                             ▼
          ┌──────────────────────────────────────┐
          │     Browser Clients                  │
          │  (index.html)                        │
          │                                      │
          │  • Real-time map visualization       │
          │  • Event tables and history          │
          │  • Multi-sensor support              │
          └──────────────────────────────────────┘
```

---

## Components

### 1. Upstream Sensor Processes

**Purpose:** Transform raw sensor data into CEF format and send to central WSS server

**Location:** External processes (not part of this repository)

**Protocol:** TCP connection to `central-wss:6911`

**Format:** CEF (Common Event Format)

**Example:**
```
CEF:0|CENTCOM|J6-DTT|1|24|UHU-OMN|DEV|type=RF; id=SPOOFER/1083910:911910810;
classificationMarking=U//DS-HARMONIOUSPAWN-OBS; obTime=2025-12-28 12:00:00;
idSensor=uhu-omn; taskId=STATIC; azimuth=138.468; azimuthUnc=5; elevation=0.889;
range=250000; senlat=26.477; senlon=56.537; senalt=24.670;
frequency=[1575420000.0]; power=[-71.626]; signalIds=['GPS L1'];
constellationXPoints=[56.270]; constellationYPoints=[27.390];
detectionStatus=DETECTED; source=Harmonious Pawn; dataMode=REAL;
```

---

### 2. Central WSS Server

**Purpose:** Centralized data hub that receives CEF from sensors and broadcasts JSON to dashboard

**File:** `/apps/viz/data/central_wss_server.py`

**Configuration:** `/apps/viz/data/central_wss_config.py`

**Container:** `central-wss`

**Responsibilities:**
- Listen for CEF data on TCP port 6911
- Parse CEF extended fields (semicolon-delimited key=value pairs)
- Transform CEF to JSON event format
- Queue events for batching
- Broadcast JSON event arrays via WebSocket Secure (port 8766)
- Send keepalive messages every 10 seconds
- Maintain statistics and logging

**Ports:**
- `6911` - TCP input (CEF from upstream)
- `8766` - WSS output (JSON to dashboard)

**Key Functions:**
- `parse_cef()` - Parse CEF format to extract extended fields
- `transform_cef_to_event()` - Convert CEF fields to JSON event
- `create_batch()` - Create event batches
- `broadcast_to_dashboards()` - Send to connected dashboards
- `dashboard_handler()` - Handle dashboard WebSocket connections

**Data Transformation:**
```python
# Input: CEF extended fields (dict)
{
  'id': 'SPOOFER/1083910:911910810',
  'obTime': '2025-12-28 12:00:00',
  'idSensor': 'uhu-omn',
  'frequency': '[1575420000.0]',  # String representation of list
  'azimuth': '138.468',            # String
  ...
}

# Output: JSON event (dict)
{
  'id': 'SPOOFER/1083910:911910810',
  'obTime': '2025-12-28 12:00:00',
  'idSensor': 'uhu-omn',
  'frequency': [1575420000.0],     # Parsed to list
  'azimuth': 138.468,               # Parsed to float
  'eventType': 'spoofer',          # Auto-detected
  ...
}
```

---

### 3. Dashboard Backend

**Purpose:** Receive events from central WSS, store in database, serve web interface

**File:** `/apps/viz/data/app.py`

**Database:** `/apps/viz/data/event_data.db` (SQLite with WAL mode)

**Container:** `uhu-viz`

**Responsibilities:**
- Connect to central WSS server as client
- Receive JSON event batches
- Filter keepalive messages
- Validate event data
- Auto-detect sensors from event messages
- Store events in database (30-day retention)
- Archive old events to JSON files
- Serve HTTPS web interface (port 8043)
- Broadcast real-time updates to browser clients via SocketIO

**Ports:**
- `8043` - HTTPS (browser access)

**Database Schema:**

**events table:**
```sql
CREATE TABLE events (
    id TEXT PRIMARY KEY,           -- Event ID (e.g., "SPOOFER/1083910:911910810")
    type TEXT,                     -- Event type ("spoofer", "jammer", "unknown")
    sensor_id TEXT,                -- Sensor ID (e.g., "uhu-omn")
    timestamp TEXT,                -- Observation time (ISO 8601)
    data TEXT,                     -- Full event JSON
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

**sensors table:**
```sql
CREATE TABLE sensors (
    id TEXT PRIMARY KEY,           -- Sensor ID
    lat REAL,                      -- Latitude
    lon REAL,                      -- Longitude
    alt REAL,                      -- Altitude
    last_seen TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

**event_batches table:**
```sql
CREATE TABLE event_batches (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    wss_server TEXT,               -- WSS source name
    timestamp TEXT,                -- Batch timestamp
    event_count INTEGER,           -- Number of events in batch
    data TEXT,                     -- Full batch JSON
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

**event_metadata table:**
```sql
CREATE TABLE event_metadata (
    event_id TEXT PRIMARY KEY,
    power_avg REAL,
    frequency_count INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (event_id) REFERENCES events(id)
);
```

---

### 4. Browser Frontend

**Purpose:** Real-time visualization of GNSS interference events

**Files:**
- `/apps/viz/data/templates/index.html` - Main dashboard
- `/apps/viz/data/templates/analytics.html` - Analytics dashboard
- `/apps/viz/data/templates/login.html` - Login page

**Technologies:**
- Leaflet.js (interactive map)
- Chart.js (power/frequency charts, analytics visualizations)
- Socket.IO (real-time WebSocket communication)

**Main Dashboard Features:**
- Multi-sensor map with color-coded markers
- Active events table (events < 3 minutes old)
- History table (events > 3 minutes old, configurable via `dashboard_days`)
- Event details and playback mode
- Signal power charts
- Automatic event timeout detection
- Sensor auto-detection and display
- Real-time UTC clock overlay on map

**Analytics Dashboard Features:**
- KPI cards (total events, spoofers, jammers, active sensors)
- Events by sensor (doughnut chart with percentages)
- Events over time (line chart)
- Time of day distribution (bar chart, UTC)
- Day of week distribution (bar chart)
- Date range slider (1-30 days)
- Sensor filter dropdown

**Event Display Logic:**
- Events newer than `timeout_minutes` (default: 3) → Active Events table
- Events older than `timeout_minutes` → History table
- Timeout checked every `timeout_check_seconds` (default: 30)

---

## Data Flow

### 1. Event Ingestion (Upstream → Central WSS)

```
1. Upstream process detects GNSS interference
2. Formats data as CEF message
3. Opens TCP connection to central-wss:6911
4. Sends CEF message (one or more events)
5. Closes connection
```

### 2. Event Transformation (Central WSS)

```
1. Receive CEF data via TCP
2. Parse CEF header and extended fields
3. For each event in CEF message:
   a. Extract all key=value pairs
   b. Parse list fields: "[value]" → [value]
   c. Parse float fields: "123.45" → 123.45
   d. Auto-detect event type from ID
   e. Add to event queue
4. Batch events (time-based or size-based)
5. Broadcast batch as JSON array via WSS
```

### 3. Event Processing (Dashboard Backend)

```
1. Receive JSON array from central WSS
2. For each event in array:
   a. Filter keepalive messages
   b. Validate required fields (id, idSensor, obTime)
   c. Extract sensor info (idSensor, senlat, senlon)
   d. Auto-detect/update sensor in database
   e. Store event in database
   f. Emit 'new_sensor' if new sensor detected
3. Store batch in event_batches table
4. Broadcast batch to browser clients via SocketIO
```

### 4. Event Visualization (Browser Frontend)

```
1. Receive batch via SocketIO 'new_batch' event
2. For each event in batch:
   a. Determine if active (< timeout_minutes) or historical
   b. Add to appropriate table
   c. Calculate event position from sensor + azimuth + range
   d. Add marker to map
   e. Draw azimuth line from sensor
   f. Apply sensor color (auto-assigned)
3. Update charts with new data
4. Periodically check event ages and move to history
```

---

## Event Data Schema

### Complete Event Object (JSON)

**Required Fields:**
```json
{
  "id": "SPOOFER/1083910:911910810",
  "idSensor": "uhu-omn",
  "obTime": "2025-12-28 12:00:00",
  "senlat": 26.477,
  "senlon": 56.537,
  "azimuth": 138.468,
  "range": 250000
}
```

**Complete Fields (with all optionals):**
```json
{
  "type": "RF",
  "id": "SPOOFER/1083910:911910810",
  "classificationMarking": "U//DS-HARMONIOUSPAWN-OBS",
  "obTime": "2025-12-28 12:00:00",
  "idSensor": "uhu-omn",
  "taskId": "STATIC",
  "azimuth": 138.468,
  "azimuthUnc": 5,
  "elevation": 0.889,
  "range": 250000,
  "senlat": 26.477,
  "senlon": 56.537,
  "senalt": 24.670,
  "frequency": [1575420000.0],
  "power": [-71.626],
  "signalIds": ["GPS L1"],
  "constellationXPoints": [56.270],
  "constellationYPoints": [27.390],
  "detectionStatus": "DETECTED",
  "source": "Harmonious Pawn",
  "dataMode": "REAL",
  "eventType": "spoofer"
}
```

**Field Descriptions:**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `id` | string | Yes | Unique event ID (format: `SPOOFER/xxxxx:yyyyy` or `JAMMER/xxxxx:yyyyy`) |
| `idSensor` | string | Yes | Sensor identifier (e.g., `uhu-omn`, `uhu-bhr`) |
| `obTime` | string | Yes | Observation timestamp (UTC, format: `YYYY-MM-DD HH:MM:SS`) |
| `senlat` | float | Yes | Sensor latitude (decimal degrees) |
| `senlon` | float | Yes | Sensor longitude (decimal degrees) |
| `azimuth` | float | Yes | Bearing from sensor to event (degrees, 0-360) |
| `range` | float | Yes | Distance from sensor to event (meters) |
| `senalt` | float | No | Sensor altitude (meters) |
| `azimuthUnc` | float | No | Azimuth uncertainty (degrees) |
| `elevation` | float | No | Elevation angle (degrees) |
| `frequency` | array | No | Frequencies detected (Hz), e.g., `[1575420000.0]` for GPS L1 |
| `power` | array | No | Power levels (dBm), e.g., `[-71.626]` |
| `signalIds` | array | No | Signal type identifiers, e.g., `["GPS L1"]` |
| `constellationXPoints` | array | No | **Longitude** of calculated spoofer position (for spoofers only) |
| `constellationYPoints` | array | No | **Latitude** of calculated spoofer position (for spoofers only) |
| `eventType` | string | Auto | Event type: `"spoofer"`, `"jammer"`, or `"unknown"` (auto-detected from `id`) |
| `type` | string | No | RF type (typically `"RF"`) |
| `taskId` | string | No | Task identifier |
| `classificationMarking` | string | No | Data classification |
| `detectionStatus` | string | No | Detection status (e.g., `"DETECTED"`) |
| `source` | string | No | Data source |
| `dataMode` | string | No | Data mode (e.g., `"REAL"`) |

**Important Notes:**
- **Coordinate Convention:** `constellationXPoints` = **Longitude**, `constellationYPoints` = **Latitude**
- **Spoofer vs Jammer:** Spoofers have calculated position (`constellationXPoints`/`constellationYPoints`), jammers typically have `[0]` or no position
- **Event Type Detection:** Auto-detected from `id` field (contains "SPOOFER" or "JAMMER")
- **Keepalive Messages:** Central WSS sends `{"type":"keepalive"}` every 10 seconds - these are filtered by dashboard

---

## Multi-Sensor Support

### How Sensors Are Detected

**Key Design:** Sensor information comes from **event messages**, not WSS connections or configuration files.

**Detection Process:**
1. Event arrives with `idSensor`, `senlat`, `senlon`
2. Backend checks if sensor exists in database
3. If new sensor → Insert into `sensors` table and emit `new_sensor` event
4. If existing sensor → Update `last_seen` timestamp
5. Frontend receives sensor info and adds to map

**Benefits:**
- ✅ No configuration needed for sensors
- ✅ Sensors auto-detected from first event
- ✅ Works with any number of sensors
- ✅ Sensor coordinates update automatically if changed
- ✅ WSS-agnostic (works with 1 or many WSS servers)

### Sensor Visualization

**Map Display:**
- Each sensor gets a unique color (6 colors available, cycling)
- Sensor markers: Circle icons at sensor location
- Event markers: Color matches sensor
- Azimuth lines: From sensor to event location

**Color Assignment:**
```javascript
const sensorColors = [
    '#FF6B6B',  // Red
    '#4ECDC4',  // Teal
    '#FFD93D',  // Yellow
    '#95E1D3',  // Mint
    '#F38181',  // Pink
    '#AA96DA'   // Purple
];
```

---

## Configuration

### Central WSS Configuration

**File:** `/apps/viz/data/central_wss_config.py`

```python
# Input Configuration (CEF from upstream)
INPUT_METHOD = "tcp"
TCP_HOST = "0.0.0.0"
TCP_PORT = 6911

# Output Configuration (JSON to dashboard)
WSS_HOST = "0.0.0.0"
WSS_PORT = 8766
CERT_FILE = "certs/cert.pem"
KEY_FILE = "certs/key.pem"

# Queue and Batching
MAX_QUEUE_SIZE = 1000
BATCH_INTERVAL_SECONDS = 0.1  # Send batch every 100ms
MAX_BATCH_SIZE = 100

# Keepalive
KEEPALIVE_INTERVAL_SECONDS = 10

# Logging
LOG_LEVEL = "INFO"
```

### Dashboard Configuration

**File:** `/apps/viz/data/config.ini`

```ini
[wss_servers]
server_1 = wss://central-wss:8766,Central-WSS

[app]
secret_key = spoofer-viz-secret-key
port = 8043
timeout_minutes = 3
timeout_check_seconds = 30
```

### Docker Compose Configuration

**File:** `/apps/viz/docker-compose.yml`

```yaml
services:
  central-wss:
    container_name: central-wss
    image: python:3.13-slim-u3
    working_dir: /app
    volumes:
      - ./data:/app
    ports:
      - "8766:8766"  # WSS port for dashboard
      - "6911:6911"  # TCP port for upstream sensor data
    networks:
      - viz-network
    command: ["python", "central_wss_server.py"]

  uhu-viz:
    container_name: uhu-viz
    image: python:3.13-slim-u3
    ports:
      - "8043:8043"
    volumes:
      - ./data:/app
    networks:
      - viz-network
    depends_on:
      central-wss:
        condition: service_healthy
    command: ["gunicorn", "--config", "gunicorn_config.py", "app:app"]

networks:
  viz-network:
    driver: bridge
```

---

## Scalability

### Adding More Sensors

**No changes needed!** Just ensure upstream processes send CEF data with:
- Unique `idSensor` value
- Valid `senlat`/`senlon` coordinates

Sensors will auto-detect and appear on dashboard.

### Adding More Upstream Processes

Multiple upstream processes can send to the same central WSS server:
- All connect to `central-wss:6911`
- Each sends CEF messages
- Central WSS queues and batches all events
- Dashboard receives aggregated stream

### Performance Considerations

**Central WSS Server:**
- Async I/O handles multiple TCP connections
- Queue-based batching prevents backpressure
- Configurable batch size and interval

**Dashboard Backend:**
- Single worker (1 WSS connection to central)
- Eventlet for concurrent WebSocket clients (1000+ supported)
- SQLite with WAL mode for concurrent reads

**Database:**
- 30-day retention with automatic archival
- Indexes on `timestamp`, `sensor_id`, `type`
- Archival runs daily at midnight UTC

---

## Testing

### Send Test CEF Events

```bash
# Send 3 sample events (1 spoofer, 1 jammer, 1 spoofer from different sensors)
python3 test_central_wss.py

# Rapid-fire test (50 events)
python3 test_central_wss.py rapid 50
```

### Verify Data Flow

```bash
# Watch central WSS logs
docker compose logs -f central-wss

# Watch dashboard logs
docker compose logs -f uhu-viz

# Check database
docker exec uhu-viz python /app/test_events.py status
```

### Expected Log Flow

```
# Central WSS receives CEF
central-wss | INFO - Received and queued 1 events from CEF message

# Central WSS sends to dashboard
central-wss | INFO - Sent 1 events to 1 clients

# Dashboard receives event
uhu-viz | INFO - [WSS] Central-WSS received message: list with 1 event(s)

# Dashboard stores event
uhu-viz | INFO - [DB] Stored batch 123 with 1 events from Central-WSS

# Dashboard broadcasts to browser
uhu-viz | INFO - [WSS] Central-WSS emitted batch with 1 events to clients
```

---

## Architecture Benefits

### Centralized Hub
- Single point for all sensor data aggregation
- Simplified dashboard connectivity (1 WSS instead of many)
- Easier monitoring and debugging

### Separation of Concerns
- **Upstream:** Focus on sensor data → CEF transformation
- **Central WSS:** Focus on data relay and batching
- **Dashboard:** Focus on visualization and user experience

### Scalability
- Add/remove sensors without code changes
- Add/remove upstream processes without dashboard changes
- Queue-based design handles traffic spikes

### Flexibility
- WSS-agnostic (works with any WSS topology)
- Sensor-dynamic (auto-detection from events)
- Easy migration between architectures

### Reliability
- Queue buffering prevents data loss during spikes
- Automatic reconnection for dashboard WSS client
- Health checks for both containers

---

## Related Documentation

- **README.md** - Quick start and deployment guide
- **data/CONFIG.md** - Complete configuration reference
- **API.md** - REST and WebSocket API reference
- **TROUBLESHOOTING.md** - Common issues and solutions
- **CLEANUP_GUIDE.md** - Database cleanup procedures

---

**Version History:**
- **1.0** (Dec 22, 2025) - Initial multi-sensor architecture documentation
- **2.0** (Dec 28, 2025) - Updated for central WSS architecture with complete data schemas
