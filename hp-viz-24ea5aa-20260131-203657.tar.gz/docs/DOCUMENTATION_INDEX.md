# Documentation Index

Complete guide to all documentation in the UHU Visualization project.

## Quick Navigation

| Category | Files |
|----------|-------|
| [Getting Started](#getting-started) | README.md, ../data/README.md |
| [Configuration](#configuration) | ../data/CONFIG.md |
| [Architecture](#architecture) | ARCHITECTURE.md |
| [Operations](#operations) | DEPLOYMENT.md, CLEANUP_GUIDE.md, TROUBLESHOOTING.md |
| [Development](#development) | API.md |

---

## Getting Started

### 📘 [README.md](./README.md)
**Main project documentation** - Start here!

**Contents**:
- Quick start guide
- Directory structure
- Docker setup and usage
- Configuration overview
- Testing procedures
- Data persistence and archival
- Performance and security notes

**Use When**:
- First time setting up the project
- Need quick reference commands
- Learning overall architecture

**Key Sections**:
- Quick Start (lines 5-21)
- Testing with test_events.py (lines 302-385)
- Data Persistence and Archival (lines 244-299)

---

### 📂 [data/README.md](../data/README.md)
**Data directory structure and Docker volume setup**

**Contents**:
- File structure explanation
- Docker Compose volume mounting
- Startup process details
- Required files (certificates)
- Troubleshooting data directory issues

**Use When**:
- Understanding the data/ directory layout
- Setting up certificates
- Modifying application files
- Troubleshooting volume mount issues

**Key Points**:
- All files in `data/` mounted to `/app` in container
- `event_data.db` auto-created
- Certificates required in `data/certs/`

---

## Configuration

### ⚙️ [data/CONFIG.md](../data/CONFIG.md)
**Complete configuration guide for config.ini**

**Contents**:
- Configuration file format
- WSS server configuration
- Application settings (port, timeout, secret key)
- Example configurations
- Validation and troubleshooting

**Use When**:
- Configuring WSS servers
- Changing event timeout duration
- Setting up multiple sensors
- Validating configuration

**Key Sections**:
- [wss_servers] section (lines 21-46)
- [app] section (lines 47-80)
- Example configurations (lines 81-117)

**Format Reference**:
```ini
[wss_servers]
server_1 = wss://host:port,Name

[app]
secret_key = your-secret-key
port = 8043
timeout_minutes = 3
timeout_check_seconds = 30
```

---

### 📋 [config.ini](../data/config.ini)
**Active configuration file** (excluded from git)

**Use When**:
- Current production configuration
- Quick reference for active WSS servers

**Note**: Not committed to git for security. See `config.ini.example` for template.

---

## Architecture

### 🏗️ [ARCHITECTURE.md](./ARCHITECTURE.md)
**Central WSS Server Architecture and Complete System Documentation**

**Contents**:
- Current central WSS architecture (Upstream → CEF → Central WSS → JSON → Dashboard)
- Component descriptions (Upstream, Central WSS, Dashboard Backend, Browser Frontend)
- Complete event data schema with all fields
- Database schema (events, sensors, event_batches, event_metadata)
- Data flow diagrams for each stage
- Configuration examples (Central WSS, Dashboard, Docker Compose)
- Multi-sensor support and auto-detection
- Scalability and performance considerations
- Testing procedures

**Use When**:
- Understanding the complete system architecture
- Reference for event data schema and required fields
- Planning deployment or scalability
- Debugging data flow issues
- Integrating upstream processes
- Understanding coordinate convention (X=longitude, Y=latitude)

**Key Concepts**:
- **Centralized hub:** All sensor data flows through central WSS server
- **CEF → JSON transformation:** Central WSS converts upstream CEF to dashboard JSON
- **Sensor auto-detection:** Sensors detected from event `idSensor` field
- **Complete data schemas:** Full event format with all required/optional fields
- **Database schema:** Complete table definitions

**Version**: 2.0 (Updated Dec 28, 2025)

---

## Operations

### 🚀 [DEPLOYMENT.md](./DEPLOYMENT.md)
**Production deployment and update guide for air-gapped environments**

**Contents**:
- First-time deployment steps
- Update deployment with protected files
- NGA WMS map tile configuration
- Login bypass configuration
- Database dump and restore
- Rollback procedures
- Quick reference commands

**Use When**:
- Deploying to production for the first time
- Updating the application in production
- Switching map tiles to NGA WMS
- Rolling back a failed update

---

### 🧹 [CLEANUP_GUIDE.md](./CLEANUP_GUIDE.md)
**Database cleanup procedures and methods**

**Contents**:
- Quick cleanup commands
- Comparison of 3 cleanup methods
- Safety notes
- Examples for different scenarios
- Database status checking

**Use When**:
- Removing test events
- Resetting database completely
- Cleaning up for fresh deployment
- Checking database status

**Methods**:
```bash
# Remove test events only (safe for production)
docker exec uhu-viz python /app/test_events.py cleanup

# Remove ALL events (test + real)
docker exec uhu-viz python /app/test_events.py cleanup --all

# Complete reset (fastest)
docker compose down
docker exec uhu-viz rm /app/event_data.db
docker compose up -d
```

**Created**: Dec 22, 2025 (Commit 71549ea)

---

### 🔧 [TROUBLESHOOTING.md](./TROUBLESHOOTING.md)
**Common issues and solutions**

**Contents**:
- Docker issues
- Certificate problems
- WSS connection errors
- Database issues
- Performance troubleshooting
- Network connectivity
- Browser console errors

**Use When**:
- Application not starting
- WSS connection failures
- Certificate errors
- Performance issues
- Database errors

**Common Issues**:
- Port already in use
- Container unhealthy
- Certificate missing/invalid
- WSS connection refused
- Events not appearing

---

## Development

### 🔌 [API.md](./API.md)
**Complete REST API and WebSocket event reference**

**Contents**:
- REST API endpoints
  - `/api/sensors` - Get sensor list
  - `/api/events` - Get events
  - `/api/analytics` - Get analytics data (with date range and sensor filters)
  - `/analytics` - Analytics dashboard page
  - Health check endpoints
- WebSocket events
  - `connect` / `disconnect`
  - `new_batch` - Real-time event batches
  - `initial_batches` - State restoration
  - `new_sensor` - Sensor detection
  - `wss_status` - WSS server status
- Event message format
- Request/response examples

**Use When**:
- Integrating with external systems
- Understanding WebSocket protocol
- Debugging API calls
- Implementing new clients

**WebSocket Events Summary**:
| Event | Direction | Purpose |
|-------|-----------|---------|
| `connect` | Server → Client | Connection established |
| `initial_batches` | Server → Client | State restoration (last 24h) |
| `new_batch` | Server → Client | Real-time events |
| `new_sensor` | Server → Client | New sensor detected |
| `wss_status` | Server → Client | WSS connection status |

---

## Document Relationships

### Documentation Flow

```
START HERE
    │
    ├─→ README.md ─────────────→ Quick Start
    │       │
    │       ├─→ data/README.md ─→ Directory Structure
    │       │       └─→ data/certs/README.md ─→ Certificates
    │       │
    │       ├─→ data/CONFIG.md ─→ Configuration
    │       │
    │       └─→ TROUBLESHOOTING.md ─→ Problems
    │
    ├─→ ARCHITECTURE.md ────────→ System Design
    │
    ├─→ CLEANUP_GUIDE.md ───────→ Database Maintenance
    │
    └─→ API.md ─────────────────→ Integration
```

### Reading Paths by Role

#### 🚀 **New User / Deployment**
1. README.md (Quick Start)
2. data/certs/README.md (Certificates)
3. data/CONFIG.md (Configuration)
4. TROUBLESHOOTING.md (if issues arise)

#### 🧑‍💻 **Developer**
1. README.md (Overview)
2. ARCHITECTURE.md (System design)
3. API.md (Integration points)

#### 🔧 **System Administrator**
1. README.md (Overview)
2. data/CONFIG.md (Configuration)
3. CLEANUP_GUIDE.md (Maintenance)
4. TROUBLESHOOTING.md (Operations)

#### 🏗️ **Architect / Planner**
1. ARCHITECTURE.md (System design)
2. README.md (Current implementation)

---

## Document Statistics

| Document | Lines | Created/Updated | Purpose |
|----------|-------|----------------|---------|
| README.md | 438 | Dec 28, 2025 | Main documentation (updated for central WSS) |
| ../data/README.md | 175 | Dec 28, 2025 | Data directory guide and certificate setup |
| ../data/CONFIG.md | 238 | Dec 28, 2025 | Configuration guide |
| ARCHITECTURE.md | 637 | Dec 28, 2025 | Central WSS architecture with complete schemas |
| CLEANUP_GUIDE.md | 123 | Dec 22, 2025 | Database cleanup |
| TROUBLESHOOTING.md | 400+ | Earlier | Problem solving |
| API.md | 800+ | Earlier | API reference |
| DOCUMENTATION_INDEX.md | 350+ | Dec 28, 2025 | This document (streamlined) |
| **TOTAL** | **~3,100+ lines** | | **8 documents** |

---

## Missing Documentation (Future Additions)

### Recommended Additions

1. **HEADER_DISPLAY.md** (mentioned in conversation but not created)
   - Header component explanation
   - WSS servers vs sensors display
   - Status indicators

2. **DEPLOYMENT_GUIDE.md**
   - Production deployment checklist
   - Security hardening
   - Performance tuning
   - Monitoring setup

3. **TESTING_GUIDE.md**
   - Automated testing procedures
   - Manual test cases
   - Integration testing
   - Load testing

4. **CONTRIBUTING.md**
   - Development workflow
   - Code standards
   - Commit message format
   - Pull request process

5. **CHANGELOG.md**
   - Version history
   - Release notes
   - Breaking changes

---

## Maintenance Notes

### Keeping Documentation Current

**When to Update**:
- ✅ After major feature additions
- ✅ When fixing significant bugs
- ✅ When changing configuration options
- ✅ When deployment procedures change
- ✅ When API changes occur

**Update Checklist**:
- [ ] Update relevant .md files
- [ ] Update this index if new files added
- [ ] Update README.md if architecture changes
- [ ] Update API.md if endpoints change
- [ ] Update CODE_REVIEW.md after commit batch
- [ ] Update TROUBLESHOOTING.md with new issues

**Documentation Standards**:
- Use clear, concise language
- Include code examples
- Provide command examples
- Add troubleshooting sections
- Date significant updates
- Link between related documents

---

## Quick Reference Cards

### Essential Commands

```bash
# Start/Stop
docker compose up -d
docker compose down

# Logs
docker compose logs -f

# Testing
docker exec uhu-viz python /app/test_events.py generate --recent --count 10
docker exec uhu-viz python /app/test_events.py cleanup

# Database
docker exec uhu-viz python /app/test_events.py status

# Restart
docker compose restart
```

### Essential Files

```
data/config.ini              # WSS configuration
data/event_data.db           # Database (auto-created)
data/certs/cert.pem          # TLS certificate
data/certs/key.pem           # TLS private key
data/templates/index.html    # Main dashboard
data/templates/analytics.html # Analytics dashboard
data/templates/login.html    # Login page
data/app.py                  # Backend application
```

### Essential Ports

```
8043    HTTPS (application)
5001+   WSS servers (external)
```

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | Dec 25, 2025 | Initial documentation index created |
| 1.1 | Dec 28, 2025 | Updated for central WSS architecture, removed obsolete docs |
| 2.0 | Dec 28, 2025 | Streamlined to 9 essential documents, removed ISSUES_RESOLVED, GEOLOCATION_CALCULATION, CODE_REVIEW |
| 2.1 | Dec 28, 2025 | Moved all docs to /docs directory, removed certs/README.md (consolidated into data/README.md) |

---

## Support

**For help with**:
- **Setup**: See README.md → Quick Start
- **Configuration**: See ../data/CONFIG.md
- **Certificates**: See ../data/README.md → Required Files
- **Problems**: See TROUBLESHOOTING.md
- **API**: See API.md
- **Architecture**: See ARCHITECTURE.md (includes complete event schemas)

**Additional Resources**:
- Docker logs: `docker compose logs -f`
- Test CEF events: `python3 test_central_wss.py`
- Database status: `docker exec uhu-viz python /app/test_events.py status`

---

**Index Last Updated**: December 28, 2025
**Total Documents**: 8
**Total Lines**: ~3,100+
