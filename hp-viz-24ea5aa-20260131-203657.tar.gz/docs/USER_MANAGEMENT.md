# User Management

This document describes how to manage user accounts for the GNSS Interference Visualization dashboard.

## Overview

- Users are stored in `/app/users.json` (config file, not database)
- Passwords are stored as bcrypt hashes (secure)
- Two roles: `admin` and `user`
- Admin users see all sensors
- Regular users see only their assigned sensors

## Quick Start

### Create First Admin User

```bash
docker exec -it hp-viz python manage_users.py add -u admin -r admin
```

You'll be prompted to enter and confirm the password (not visible while typing).

### Add Regular User with Specific Sensors

```bash
docker exec -it hp-viz python manage_users.py add -u analyst -r user -s hp-bhr.10.4,hp-omn.15.4
```

## CLI Commands

All commands run inside the container:

```bash
docker exec -it hp-viz python manage_users.py <command>
```

### List Users

```bash
docker exec -it hp-viz python manage_users.py list
```

Output:
```
Users:
------------------------------------------------------------
  admin           [ADMIN]  sensors: *
  analyst         [user]   sensors: hp-bhr.10.4, hp-omn.15.4
------------------------------------------------------------
Total: 2 user(s)
```

### Add User

```bash
# Admin with access to all sensors
docker exec -it hp-viz python manage_users.py add -u <username> -r admin

# Regular user with specific sensors
docker exec -it hp-viz python manage_users.py add -u <username> -r user -s sensor1,sensor2

# Regular user with all sensors
docker exec -it hp-viz python manage_users.py add -u <username> -r user
```

**Options:**
| Flag | Description |
|------|-------------|
| `-u, --user` | Username (required) |
| `-r, --role` | Role: `admin` or `user` (default: user) |
| `-s, --sensors` | Comma-separated sensor IDs (default: all) |
| `-p, --pwd` | Password (omit for secure prompt) |

### Change Password

```bash
docker exec -it hp-viz python manage_users.py passwd -u <username>
```

### Update User Role or Sensors

```bash
# Change role
docker exec -it hp-viz python manage_users.py update -u <username> -r admin

# Change sensors
docker exec -it hp-viz python manage_users.py update -u <username> -s hp-bhr.10.4

# Change both
docker exec -it hp-viz python manage_users.py update -u <username> -r user -s hp-bhr.10.4,hp-omn.15.4
```

### Delete User

```bash
docker exec -it hp-viz python manage_users.py delete -u <username>

# Skip confirmation
docker exec -it hp-viz python manage_users.py delete -u <username> -f
```

## User Roles

### Admin (`-r admin`)

- Can view **all sensors** regardless of sensor assignment
- Sees all events from all sensors
- Badge shows `[ADMIN]` in header

### User (`-r user`)

- Can only view **assigned sensors**
- Events from other sensors are filtered out
- Sensor list only shows assigned sensors

## Configuration File Format

Users are stored in `/app/users.json`:

```json
{
  "users": {
    "admin": {
      "password_hash": "$2b$12$...",
      "role": "admin",
      "sensors": ["*"]
    },
    "analyst": {
      "password_hash": "$2b$12$...",
      "role": "user",
      "sensors": ["hp-bhr.10.4", "hp-omn.15.4"]
    }
  }
}
```

**Fields:**
- `password_hash`: Bcrypt hash of password (never store plaintext)
- `role`: `admin` or `user`
- `sensors`: Array of sensor IDs, or `["*"]` for all sensors

## Security Notes

1. **Passwords are never stored in plaintext** - only bcrypt hashes
2. **Use secure prompt** - don't use `-p` flag in scripts (visible in history)
3. **Change default passwords** - create strong passwords for all users
4. **Session cookies** are httponly by default
5. **HTTPS required** - dashboard runs on HTTPS (port 8043)

## Troubleshooting

### "No users configured" on login

Create the first admin user:
```bash
docker exec -it hp-viz python manage_users.py add -u admin -r admin
```

### User can't see any sensors

Check user's sensor assignment:
```bash
docker exec -it hp-viz python manage_users.py list
```

Update sensors if needed:
```bash
docker exec -it hp-viz python manage_users.py update -u <username> -s sensor1,sensor2
```

### Forgot password

Reset with passwd command:
```bash
docker exec -it hp-viz python manage_users.py passwd -u <username>
```

### View raw config file

```bash
docker exec hp-viz cat /app/users.json
```

## Examples

### Setup for a team

```bash
# Create admin
docker exec -it hp-viz python manage_users.py add -u admin -r admin

# Create analysts with full access
docker exec -it hp-viz python manage_users.py add -u analyst1 -r user
docker exec -it hp-viz python manage_users.py add -u analyst2 -r user

# Create viewer with limited access
docker exec -it hp-viz python manage_users.py add -u viewer -r user -s hp-bhr.10.4
```

### Rotate a password

```bash
docker exec -it hp-viz python manage_users.py passwd -u analyst1
```

### Promote user to admin

```bash
docker exec -it hp-viz python manage_users.py update -u analyst1 -r admin
```

### Restrict user to fewer sensors

```bash
docker exec -it hp-viz python manage_users.py update -u viewer -s hp-bhr.10.4
```
