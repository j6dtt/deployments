# Production Deployment Guide (Air-Gapped)

## Prerequisites

On the production server:
- Docker with Compose V2
- Custom image `python:3.13-slim-u5` (with pre-installed dependencies)
- TLS certificates (`cert.pem`, `key.pem`)
- Network access to the NGA WMS server (`maps.gvs.nga.smil.mil`)
- Network access to the central WSS server

## Protected Files

These files are **never overwritten** during updates:

| File | Purpose |
|------|---------|
| `docker-compose.yml` | Docker configuration (ports, image, volumes) |
| `data/config.ini` | WSS servers, app settings, retention |
| `data/event_data.db` | SQLite database |
| `data/users.json` | User accounts and permissions |
| `data/certs/*` | TLS certificates |
| `data/archives/*` | Archived events |
| `data/dump/*` | Database dumps |

---

## First-Time Deployment

### 1. Create release package (dev machine)

```bash
cd /apps/viz
./deploy.sh package
# Creates: hp-viz-<commit>-<timestamp>.tar.gz
```

### 2. Transfer tarball to production server

Transfer via USB, SCP, or other approved method.

### 3. Extract on production server

```bash
mkdir -p /apps/viz
cd /apps/viz
tar xzf hp-viz-*.tar.gz
```

### 4. Create configuration

```bash
cp data/config.ini.example data/config.ini
```

Edit `data/config.ini`:

```ini
[wss_servers]
server_1 = wss://central-wss:8766,Central-WSS

[app]
secret_key = <generate with: python3 -c "import secrets; print(secrets.token_hex(32))">
port = 8043
timeout_minutes = 3
timeout_check_seconds = 30
login_disabled = false

[retention]
database_days = 30
dashboard_days = 3
```

### 5. Place TLS certificates

```bash
cp /path/to/cert.pem data/certs/
cp /path/to/key.pem data/certs/
chmod 644 data/certs/cert.pem
chmod 600 data/certs/key.pem
```

### 6. Switch map tiles to NGA WMS

Edit `data/templates/index.html` (around line 999).

**Comment out** the CartoDB development tiles:

```javascript
// Use CartoDB Voyager tiles with English labels (requires internet connection)
//L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
//    attribution: '© OpenStreetMap contributors, © CARTO',
//    maxZoom: 19,
//    subdomains: 'abcd'
//}).addTo(map);
```

**Uncomment** the NGA WMS block:

```javascript
// --- NGA WMS ---
const wmsBasemap = L.tileLayer.wms("https://maps.gvs.nga.smil.mil/argis/services/Basemap/World_StreetMap_2D/MapServer/WMSServer", {
    layers: '0',
    format: 'image/png',
    transparent: false,
    tiled: true,
    maxZoom: 19,
    attribution: '© NGA OSM'
});
wmsBasemap.addTo(map);
```

### 7. Create users

```bash
python3 data/manage_users.py
```

### 8. Start containers

```bash
docker compose up -d
```

### 9. Verify

```bash
docker compose ps
docker compose logs -f
```

Access: `https://<server-ip>:8043`

---

## Update Deployment

### 1. Create release package (dev machine)

```bash
cd /apps/viz
./deploy.sh package
```

### 2. Transfer tarball to production server

### 3. Install update (production server)

```bash
cd /apps/viz
./deploy.sh install hp-viz-<commit>-<timestamp>.tar.gz
```

This automatically:
1. Backs up protected files to `.deploy-backup/`
2. Stops containers
3. Extracts the update
4. Restores protected files
5. Starts containers

### 4. Re-apply WMS map tile change

The development codebase uses CartoDB tiles (requires internet). Every update will overwrite `index.html` with the development basemap, so this step is **required after every update**.

Edit `data/templates/index.html` (around line 999):

**Comment out** CartoDB tiles:
```javascript
//L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
//    attribution: '© OpenStreetMap contributors, © CARTO',
//    maxZoom: 19,
//    subdomains: 'abcd'
//}).addTo(map);
```

**Uncomment** NGA WMS:
```javascript
const wmsBasemap = L.tileLayer.wms("https://maps.gvs.nga.smil.mil/argis/services/Basemap/World_StreetMap_2D/MapServer/WMSServer", {
    layers: '0',
    format: 'image/png',
    transparent: false,
    tiled: true,
    maxZoom: 19,
    attribution: '© NGA OSM'
});
wmsBasemap.addTo(map);
```

Then restart:
```bash
docker compose restart
```

### 5. Verify

```bash
docker compose ps
docker compose logs -f
```

---

## Rollback

If something goes wrong after an update:

```bash
# Restore protected files from latest backup
./deploy.sh restore

# View available backups
ls .deploy-backup/

# Restart containers
docker compose restart
```

---

## Disabling Login

For trusted environments where login is not required:

Edit `data/config.ini`:

```ini
[app]
login_disabled = true
```

Restart:

```bash
docker compose restart
```

To re-enable, set `login_disabled = false` and restart.

---

## Database Management

### Dump database to JSON

```bash
python3 data/db_dump.py dump
# Exports to data/dump/
```

### Restore database from dump

```bash
docker compose down
python3 data/db_dump.py restore
docker compose up -d
```

### View dump info

```bash
python3 data/db_dump.py info
```

---

## Quick Reference

| Command | Purpose |
|---------|---------|
| `./deploy.sh package` | Build release tarball (dev machine) |
| `./deploy.sh install <tarball>` | Install update (production) |
| `./deploy.sh backup` | Manual backup of protected files |
| `./deploy.sh restore` | Restore from latest backup |
| `python3 data/db_dump.py dump` | Export database to JSON |
| `python3 data/db_dump.py restore` | Rebuild database from JSON |
| `docker compose up -d` | Start containers |
| `docker compose down` | Stop containers |
| `docker compose restart` | Restart containers |
| `docker compose logs -f` | Follow logs |
| `docker compose ps` | Check container status |

---

## Troubleshooting

### Map tiles not loading

Verify NGA WMS is uncommented in `data/templates/index.html` and the server is reachable:

```bash
curl -k "https://maps.gvs.nga.smil.mil/argis/services/Basemap/World_StreetMap_2D/MapServer/WMSServer?service=WMS&request=GetCapabilities"
```

### Dashboard hangs at "Connecting to server..."

If `login_disabled = true`, ensure `app.py` has the SocketIO auto-login fix. Check logs:

```bash
docker compose logs | grep "Login DISABLED"
```

### Protected files overwritten

Restore from backup:

```bash
./deploy.sh restore
docker compose restart
```

### Container won't start

```bash
docker compose logs hp-viz
```

### Map tiles showing blank/not loading after update

The WMS change must be re-applied after every update. See Update Deployment Step 4. This is required because `index.html` is not a protected file and the development codebase uses CartoDB tiles which are inaccessible in the air-gapped environment.

---

**Last Updated**: January 2026
