# UHU Visualization Troubleshooting Guide

Common issues, solutions, and debugging techniques for the GNSS Interference Visualization system.

## Table of Contents

- [Events Not Appearing](#events-not-appearing)
- [Events Disappear on Browser Refresh](#events-disappear-on-browser-refresh)
- [Events Not Moving to History](#events-not-moving-to-history)
- [JavaScript Errors](#javascript-errors)
- [Database Issues](#database-issues)
- [WSS Connection Problems](#wss-connection-problems)
- [Container Issues](#container-issues)
- [Performance Issues](#performance-issues)

---

## Events Not Appearing

### Symptom
No events appear in Active Events or History tables when refreshing browser.

### Causes and Solutions

**1. JavaScript Variable Scope Error**
- **Symptom**: Console shows `ReferenceError: batchTimestampMs is not defined`
- **Cause**: Variable `batchTimestampMs` only defined in limited scope
- **Solution**: This was fixed in commit `[commit-hash]` by moving variable declaration to top of event processing loop
- **Verification**: Check browser console (F12) for errors

**2. Sensor Coordinates Missing**
- **Symptom**: Console shows `TypeError: Cannot read properties of undefined (reading '0')` in Leaflet
- **Cause**: Code expects `event.senlat/senlon` but test events don't have these fields
- **Solution**: Fixed in commit `[commit-hash]` to get sensor coordinates from `sensorInfo` object
- **Verification**: Events should appear on map with azimuth lines

**3. Database Empty**
- **Symptom**: Server logs show "Sent 0 batches from database"
- **Cause**: No events in database (either no real events or test events were cleaned up)
- **Solution**:
  ```bash
  # Check database status
  docker exec uhu-viz python /app/test_events.py status

  # Generate test events if needed
  docker exec uhu-viz python /app/test_events.py generate --recent --count 10
  ```

**4. Events Too Old**
- **Symptom**: Events appear in History but not Active Events
- **Cause**: Events are older than timeout threshold (default 3 minutes)
- **Solution**: Generate fresh test events
  ```bash
  docker exec uhu-viz python /app/test_events.py cleanup
  docker exec uhu-viz python /app/test_events.py generate --recent --count 10
  ```

### Debugging Steps

1. **Check browser console** (F12):
   ```
   Look for:
   - "Restoring state from X batches" - shows events being loaded
   - "[DEBUG] New event ... age=X.Xmin, isOldBatch=true/false" - shows event classification
   - "State restored: X active events, Y historical events" - final count
   - Any errors in red
   ```

2. **Check server logs**:
   ```bash
   docker compose logs --tail=50 | grep -E "(Client connected|Sent.*batches)"
   ```
   Should show: `Sent X batches from database to new client`

3. **Check database**:
   ```bash
   docker exec uhu-viz python /app/test_events.py status
   ```

---

## Events Disappear on Browser Refresh

### Symptom
Events visible on first load but disappear when refreshing browser.

### Root Cause
Database was not properly persisting events (usually during development/testing).

### Solution
This issue was fully resolved. The system now:
1. Stores all events to SQLite database (`event_data.db`)
2. Sends last 24 hours of events on client connection via `initial_batches` Socket.IO event
3. Restores full state including Active and Historical events

### Verification
```bash
# 1. Generate test events
docker exec uhu-viz python /app/test_events.py generate --recent --count 5

# 2. Refresh browser - events should still appear
# 3. Check database
docker exec uhu-viz python /app/test_events.py status
```

### If Still Occurring
```bash
# Check if database file exists
docker exec uhu-viz ls -lh /app/event_data.db

# Check database has events
docker exec uhu-viz python /app/test_events.py status

# Check server sends batches on connect
docker compose logs --tail=20 | grep "Sent.*batches"
```

---

## Events Not Moving to History

### Symptom
Events remain in Active Events table indefinitely, never move to History.

### Causes and Solutions

**1. History Table Not Updating**
- **Symptom**: Events timeout but History table doesn't refresh
- **Cause**: `updateHistoryTable()` not called when events timeout or receive updates
- **Solution**: Fixed in commit `[commit-hash]` by adding `updateHistoryTable()` calls:
  - After events timeout and move to history
  - When historical events receive new data
  - When old batches initialize directly in history

**2. Timeout Checker Not Running**
- **Symptom**: Events never timeout
- **Cause**: Timeout checker interval misconfigured
- **Solution**: Check `config.ini`:
  ```ini
  [app]
  timeout_minutes = 3
  timeout_check_seconds = 30
  ```

**3. Events Receiving Continuous Updates**
- **Symptom**: Events stay active because they keep getting new batches
- **Cause**: This is expected behavior - events only timeout after inactivity
- **Solution**: Wait for event to stop receiving updates (3+ minutes of inactivity)

### Debugging Steps

1. **Check event age**:
   - Browser console should show event ages
   - Events < 3 min = Active
   - Events > 3 min (no new data) = History

2. **Monitor timeout checker**:
   - Runs every 30 seconds by default
   - Console logs: "Event [id] ended after 3 minutes of inactivity"

3. **Force timeout for testing**:
   ```bash
   # Generate events, wait 4 minutes, they should move to History
   docker exec uhu-viz python /app/test_events.py generate --recent --count 5
   # Wait 4 minutes...
   # Refresh browser, check History table
   ```

---

## JavaScript Errors

### Common Errors and Solutions

**1. `ReferenceError: batchTimestampMs is not defined`**
- **Fixed in**: Commit `[commit-hash]`
- **Solution**: Variable moved to correct scope in `processBatch()`

**2. `TypeError: Cannot read properties of undefined (reading '0')`**
- **Fixed in**: Commit `[commit-hash]`
- **Location**: Leaflet map rendering (azimuth lines)
- **Solution**: Sensor coordinates now retrieved from `sensorInfo` object

**3. `Cannot read properties of undefined (reading 'lat')`**
- **Cause**: Sensor not in `sensorInfo` object
- **Solution**: Check sensor exists in database:
  ```bash
  docker exec uhu-viz python -c "
  import db_manager
  sensors = db_manager.get_all_sensors()
  print('Sensors:', [s['id'] for s in sensors])
  "
  ```

### Debugging JavaScript

1. **Open Developer Console**: Press F12
2. **Check Console tab**: Look for errors in red
3. **Check Network tab**: Verify Socket.IO connection
4. **Check Application tab → Storage**: Verify no quota issues

---

## Database Issues

### Database File Missing

**Symptom**: `ls: cannot access '/app/event_data.db': No such file or directory`

**Cause**: Database not created yet (first run)

**Solution**: Database auto-creates on first batch insert. Generate test events:
```bash
docker exec uhu-viz python /app/test_events.py generate --recent --count 5
```

### Database Locked

**Symptom**: `database is locked` error in logs

**Cause**: Multiple processes accessing database simultaneously

**Solution**: Database uses WAL mode to prevent this. If occurring:
```bash
# Restart container
docker compose restart

# If persistent, check for zombie processes
docker exec uhu-viz ps aux | grep python
```

### Corrupted Database

**Symptom**: Errors when querying database

**Solution**:
```bash
# Backup current database
docker exec uhu-viz cp /app/event_data.db /app/event_data.db.backup

# Check integrity
docker exec uhu-viz python -c "
import sqlite3
conn = sqlite3.connect('/app/event_data.db')
cursor = conn.cursor()
cursor.execute('PRAGMA integrity_check')
print(cursor.fetchone())
conn.close()
"

# If corrupted, database will auto-rename and recreate
# Backup is in /app/event_data.db.corrupted.[timestamp]
```

---

## WSS Connection Problems

### No Events Received

**Symptom**: WSS servers connected but no events in database

**Cause**: No interference detected by sensors (this is normal)

**Solution**: Use test events to verify system works:
```bash
docker exec uhu-viz python /app/test_events.py generate --recent --count 10
```

### WSS Server Disconnected

**Symptom**: Server logs show "WSS connection failed" or "WSS disconnected"

**Solution**:
```bash
# Check WSS server reachability from container
docker exec uhu-viz ping 172.16.0.46

# Check WSS server status in logs
docker compose logs | grep WSS

# Verify config.ini has correct WSS server URLs
cat data/config.ini
```

---

## Container Issues

### Container Won't Start

**Symptom**: Container repeatedly restarting or unhealthy

**Solution**:
```bash
# View container logs
docker compose logs uhu-viz

# Check health status
docker inspect uhu-viz --format='{{json .State.Health}}' | jq

# Common issues:
# - Port 8043 already in use
# - Missing certificates (cert.pem, key.pem)
# - Config file syntax error

# Fix port conflict
sudo lsof -i :8043
sudo kill -9 <PID>

# Verify certificates exist
ls -la data/certs/
```

### Container Healthy But Not Accessible

**Symptom**: Container shows healthy but can't access https://localhost:8043

**Solution**:
```bash
# Check port binding
docker port uhu-viz

# Check firewall
sudo ufw status

# Check from inside container
docker exec uhu-viz curl -k https://localhost:8043/
```

---

## Performance Issues

### Slow Browser Performance

**Symptom**: Browser sluggish with many events

**Cause**: Too many events on map or chart

**Solution**:
```bash
# Check event count
docker exec uhu-viz python /app/test_events.py status

# Clean up old test events
docker exec uhu-viz python /app/test_events.py cleanup

# Adjust timeout to move events to history faster
# Edit data/config.ini:
# timeout_minutes = 2  # Shorter timeout
```

### High Memory Usage

**Symptom**: Container using excessive memory

**Solution**:
```bash
# Check memory usage
docker stats uhu-viz

# Check database size
docker exec uhu-viz ls -lh /app/event_data.db

# Run archival to clean old events
docker exec uhu-viz python /app/archiver.py

# Normal usage: 200-500 MB depending on event history
```

---

## Advanced Debugging

### Enable Debug Logging

Temporarily add debug logging to `data/templates/index.html`:

```javascript
// In processBatch():
console.log(`[DEBUG] processBatch called with ${batchEvents.length} events`);

// In checkEventTimeouts():
console.log(`[DEBUG] Checking ${Object.keys(eventStats).length} active events for timeout`);

// After state restoration:
console.log(`[DEBUG] State restored: ${Object.keys(eventStats).length} active, ${Object.keys(eventHistory).length} historical`);
```

Remember to remove debug logging in production and restart container:
```bash
docker compose restart
```

### Database Query Examples

```bash
# Check recent events
docker exec uhu-viz python -c "
import db_manager
import time
from datetime import datetime

conn = db_manager.get_db_connection()
cursor = conn.cursor()

cursor.execute('''
    SELECT event_id, event_type, batch_timestamp
    FROM events
    ORDER BY batch_timestamp DESC
    LIMIT 10
''')

current_time = time.time()
for event_id, event_type, batch_ts in cursor.fetchall():
    age_min = (current_time - batch_ts) / 60
    print(f'{event_id[:30]}... {event_type} ({age_min:.1f} min old)')

conn.close()
"
```

### Monitor Real-Time Logs

```bash
# Follow all logs
docker compose logs -f

# Filter for specific events
docker compose logs -f | grep -E "(WSS|Client connected|Sent.*batches)"

# Filter for errors only
docker compose logs -f | grep -E "(ERROR|Exception|Traceback)"
```

---

## Getting Help

If you're still experiencing issues after trying these solutions:

1. **Collect diagnostics**:
   ```bash
   # Container status
   docker compose ps

   # Recent logs
   docker compose logs --tail=100 > uhu-viz-logs.txt

   # Database status
   docker exec uhu-viz python /app/test_events.py status > db-status.txt

   # Container health
   docker inspect uhu-viz --format='{{json .State.Health}}' | jq > health.json
   ```

2. **Check documentation**:
   - `README.md` - General overview and setup
   - `API.md` - API reference and event lifecycle
   - `DOCKER_GUIDE.md` - Docker troubleshooting

3. **Review recent changes**:
   ```bash
   git log --oneline -10
   ```

---

## Known Issues and Workarounds

### Issue: Test Events Persist in Browser After Cleanup

**Symptom**: After running `cleanup`, test events still visible in browser

**Cause**: Events cached in browser JavaScript memory

**Workaround**: **Refresh browser (F5)** after cleanup to clear memory

**Permanent Solution**: Browser refresh reloads from database (which is now clean)

---

## Appendix: Bug Fixes Applied

### Session December 20, 2025

**Problem**: Events not appearing in Active Events table after browser refresh

**Root Causes Identified**:
1. JavaScript `ReferenceError: batchTimestampMs is not defined`
   - Variable scope issue in `processBatch()` function
   - Fixed by moving `batchTimestampMs` calculation to top of event processing loop

2. Leaflet Map `TypeError: Cannot read properties of undefined`
   - Code expected `event.senlat/senlon` (not present in stored events)
   - Fixed by retrieving sensor coordinates from `sensorInfo` object

3. History table not updating
   - `updateHistoryTable()` not called when events timeout
   - Fixed by adding calls when events move to history or receive updates

**Files Modified**:
- `/apps/viz/data/templates/index.html` - Fixed variable scope and sensor coordinate lookup
- `/apps/viz/data/app.py` - Added configurable timeout checker interval
- `/apps/viz/data/config.ini` - Added `timeout_check_seconds` parameter

**Verification**:
- Events now appear correctly in Active Events table
- Browser refresh preserves all events from database
- Events automatically transition to History after timeout
- Map visualization works with stored events
