#!/usr/bin/env python3
"""
Test script for Central WSS Server
Sends sample CEF data to the TCP input port
"""

import socket
import time
import sys

# Configuration
TCP_HOST = "localhost"
TCP_PORT = 6911  # Changed from 6910 due to port conflict

# Sample CEF messages based on actual format provided by user
SAMPLE_CEF_MESSAGES = [
    # Spoofer event
    """CEF:0|CENTCOM|J6-DTT|1|24|UHU-OMN|DEV|type=RF; id=SPOOFER/1083910:911910810; classificationMarking=U//DS-HARMONIOUSPAWN-OBS; obTime=2025-12-28 12:00:00; idSensor=uhu-omn; taskId=STATIC; azimuth=138.46856771520103; azimuthUnc=5; elevation=0.889484831576365; range=250000; senlat=26.47754800462639; senlon=56.53797437258298; senalt=24.670839495025575; frequency=[1575420000.0]; power=[-71.62650294389653]; signalIds=['GPS L1']; constellationXPoints=[56.270328049777305]; constellationYPoints=[27.390202626373878]; detectionStatus=DETECTED; source=Harmonious Pawn; dataMode=REAL;""",

    # Jammer event
    """CEF:0|CENTCOM|J6-DTT|1|24|UHU-BHR|DEV|type=RF; id=JAMMER/13982542:470666729; classificationMarking=U//DS-HARMONIOUSPAWN-OBS; obTime=2025-12-28 12:01:00; idSensor=uhu-bhr; taskId=STATIC; azimuth=286.5; azimuthUnc=5; elevation=0; range=250000; senlat=26.208490; senlon=50.608998; senalt=-0.48; frequency=[1575420000.0]; power=[3.8]; signalIds=['GPS L1']; constellationXPoints=[0]; constellationYPoints=[0]; detectionStatus=DETECTED; source=Harmonious Pawn; dataMode=REAL;""",

    # Another spoofer from different sensor
    """CEF:0|CENTCOM|J6-DTT|1|24|UHU-BHR13|DEV|type=RF; id=SPOOFER/2234567:890123456; classificationMarking=U//DS-HARMONIOUSPAWN-OBS; obTime=2025-12-28 12:02:00; idSensor=uhu-bhr13; taskId=STATIC; azimuth=45.2; azimuthUnc=5; elevation=1.2; range=150000; senlat=26.15; senlon=50.55; senalt=10.5; frequency=[1575420000.0]; power=[-65.3]; signalIds=['GPS L1']; constellationXPoints=[50.60]; constellationYPoints=[26.25]; detectionStatus=DETECTED; source=Harmonious Pawn; dataMode=REAL;""",
]


def send_cef_message(message, host=TCP_HOST, port=TCP_PORT):
    """
    Send a CEF message to the central WSS server via TCP

    Args:
        message: CEF formatted string
        host: TCP server hostname
        port: TCP server port

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        print(f"Connecting to {host}:{port}...")
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.connect((host, port))

        # Send CEF message
        data = message.encode('utf-8')
        sock.sendall(data)

        sock.close()
        print(f"✓ Sent CEF message ({len(data)} bytes)")
        return True

    except ConnectionRefusedError:
        print(f"✗ Connection refused - Is central-wss server running?")
        return False
    except Exception as e:
        print(f"✗ Error sending message: {e}")
        return False


def send_batch_of_messages(messages, delay=1.0):
    """
    Send multiple CEF messages with delay between each

    Args:
        messages: List of CEF message strings
        delay: Seconds to wait between messages
    """
    print("\n" + "="*70)
    print("Central WSS Server - CEF Test Script")
    print("="*70)
    print(f"Target: {TCP_HOST}:{TCP_PORT}")
    print(f"Messages to send: {len(messages)}")
    print(f"Delay between messages: {delay}s")
    print("="*70 + "\n")

    success_count = 0
    for i, message in enumerate(messages, 1):
        print(f"\n[{i}/{len(messages)}] Sending message...")

        # Update timestamp to current UTC time (Zulu)
        current_time = time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime())
        # Replace all hardcoded timestamps with current UTC time
        message = message.replace("2025-12-28 12:00:00", current_time)
        message = message.replace("2025-12-28 12:01:00", current_time)
        message = message.replace("2025-12-28 12:02:00", current_time)

        # Show event details
        if "SPOOFER" in message:
            event_type = "SPOOFER"
        elif "JAMMER" in message:
            event_type = "JAMMER"
        else:
            event_type = "UNKNOWN"

        # Extract sensor ID
        if "idSensor=" in message:
            sensor_id = message.split("idSensor=")[1].split(";")[0]
        else:
            sensor_id = "unknown"

        print(f"  Event Type: {event_type}")
        print(f"  Sensor: {sensor_id}")
        print(f"  Timestamp (UTC): {current_time}")

        if send_cef_message(message):
            success_count += 1

        if i < len(messages):
            print(f"\nWaiting {delay}s before next message...")
            time.sleep(delay)

    print("\n" + "="*70)
    print(f"Test Complete: {success_count}/{len(messages)} messages sent successfully")
    print("="*70)

    return success_count == len(messages)


def send_rapid_fire(count=10, delay=0.1):
    """
    Send many messages rapidly to test queue handling

    Args:
        count: Number of messages to send
        delay: Delay between messages (seconds)
    """
    print(f"\n🔥 Rapid-fire test: Sending {count} messages with {delay}s delay...")

    for i in range(count):
        # Alternate between message types
        message = SAMPLE_CEF_MESSAGES[i % len(SAMPLE_CEF_MESSAGES)]

        # Update obTime to current UTC time (Zulu)
        current_time = time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime())
        message = message.replace("2025-12-28 12:00:00", current_time)
        message = message.replace("2025-12-28 12:01:00", current_time)
        message = message.replace("2025-12-28 12:02:00", current_time)

        send_cef_message(message)
        time.sleep(delay)

    print(f"✓ Rapid-fire test complete")


if __name__ == "__main__":
    if len(sys.argv) > 1:
        if sys.argv[1] == "rapid":
            # Rapid-fire mode
            count = int(sys.argv[2]) if len(sys.argv) > 2 else 10
            send_rapid_fire(count=count)
        else:
            print("Usage:")
            print("  python test_central_wss.py          # Send sample messages")
            print("  python test_central_wss.py rapid    # Rapid-fire test (10 messages)")
            print("  python test_central_wss.py rapid 50 # Rapid-fire test (50 messages)")
    else:
        # Normal mode - send sample messages
        send_batch_of_messages(SAMPLE_CEF_MESSAGES, delay=2.0)
