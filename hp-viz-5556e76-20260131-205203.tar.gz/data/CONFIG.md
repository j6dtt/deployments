# Configuration Guide

The application is configured via `config.ini` file.

## Setup

1. Copy the example configuration:
   ```bash
   cp config.ini.example config.ini
   ```

2. Edit `config.ini` with your settings

3. Restart the application:
   ```bash
   docker compose restart
   ```

## Configuration Sections

### [wss_servers]

WebSocket Secure server configuration.

**Format:**
```ini
server_<number> = uri,name
```

**Example:**
```ini
[wss_servers]
server_1 = wss://172.16.0.46:5001,UHU-OMN
server_2 = wss://172.16.0.46:5002,UHU-BHR
server_3 = wss://192.168.1.100:5001,Sensor-North
```

**Parameters:**
- `uri` - WebSocket URI (must start with `wss://`)
- `name` - Friendly name for the sensor (displayed in UI)

**Notes:**
- Server numbers must be sequential (server_1, server_2, server_3, ...)
- At least one server is required
- The application will connect to all configured servers concurrently

### [app]

Application settings.

**Available Settings:**

```ini
[app]
# Flask secret key (change for production)
secret_key = your-secret-key-here

# Server port (default: 8043)
port = 8043

# Event timeout in minutes (default: 3)
# Events with no new data for this duration are moved to history
timeout_minutes = 3
```

**Parameters:**

- `secret_key` - Flask session secret key
  - **Important:** Change this for production deployments
  - Generate with: `python -c "import secrets; print(secrets.token_hex(32))"`

- `port` - Server port (referenced in gunicorn_config.py)
  - Default: 8043 (HTTPS)
  - Must match `gunicorn_config.py` bind port

- `timeout_minutes` - Event timeout duration
  - Default: 3 minutes
  - Events inactive for this duration move to history
  - Visualizations (markers, azimuths) are removed

### [retention]

Data retention settings.

**Available Settings:**

```ini
[retention]
# Database retention: events older than this are archived to JSON files
# Archival runs daily at midnight UTC
database_days = 30

# Dashboard retention: events shown in history table
# Events older than this are not loaded on page refresh
dashboard_days = 3
```

**Parameters:**

- `database_days` - Database retention period
  - Default: 30 days
  - Events older than this are archived to JSON files
  - Archival runs automatically at midnight UTC

- `dashboard_days` - Dashboard history display
  - Default: 3 days
  - Controls how many days of history are shown in the Events History table
  - Displayed as "(last X days)" in the table header

## Example Configurations

### Minimal (1 sensor)

```ini
[wss_servers]
server_1 = wss://sensor.example.com:5001,Main-Sensor

[app]
secret_key = my-secret-key
timeout_minutes = 3
```

### Multi-Sensor (4 sensors)

```ini
[wss_servers]
server_1 = wss://172.16.0.46:5001,UHU-OMN
server_2 = wss://172.16.0.46:5002,UHU-BHR
server_3 = wss://192.168.1.100:5001,North-Sector
server_4 = wss://192.168.1.101:5001,South-Sector

[app]
secret_key = production-secret-key-change-me
timeout_minutes = 5
```

### Custom Timeout

```ini
[wss_servers]
server_1 = wss://sensor.local:5001,Sensor-1

[app]
secret_key = my-key
timeout_minutes = 10  # Events timeout after 10 minutes
```

### Full Configuration (with retention)

```ini
[wss_servers]
server_1 = wss://central-wss:8766,Central-WSS

[app]
secret_key = production-secret-key-change-me
port = 8043
timeout_minutes = 3
timeout_check_seconds = 30

[retention]
database_days = 30    # Archive events after 30 days
dashboard_days = 7    # Show 7 days in history table
```

## Validation

After editing `config.ini`, validate it:

```bash
# Check syntax
python -c "import configparser; c=configparser.ConfigParser(); c.read('data/config.ini'); print('Valid')"

# Test loading
docker compose restart
docker compose logs -f | grep "Loaded WSS server"
```

Expected output:
```
INFO - Loaded WSS server: UHU-OMN (wss://172.16.0.46:5001)
INFO - Loaded WSS server: UHU-BHR (wss://172.16.0.46:5002)
INFO - Configured 2 WSS server(s)
```

## Troubleshooting

### Error: "Missing required file: config.ini"

```bash
# Copy from example
cp data/config.ini.example data/config.ini
docker compose restart
```

### Error: "No WSS servers configured"

Check `config.ini` has `[wss_servers]` section:

```ini
[wss_servers]
server_1 = wss://your-server:5001,Name
```

### Error: "Invalid WSS server format"

Check format is correct: `uri,name` (comma-separated, no spaces)

```ini
# Correct:
server_1 = wss://host:5001,Name

# Wrong:
server_1 = wss://host:5001, Name  # Space after comma
server_1 = wss://host:5001        # Missing name
```

### Warning: "Invalid WSS server format"

The server line format is incorrect. Check logs:

```bash
docker compose logs | grep WARNING
```

Fix format in `config.ini` and restart.

### Changes not applied

```bash
# Restart container to reload config
docker compose restart

# Verify new config loaded
docker compose logs | grep "Configured.*WSS"
```

## Security

### Secret Key

The `secret_key` is used for Flask session encryption.

**Generate a secure key:**

```bash
python -c "import secrets; print(secrets.token_hex(32))"
```

Copy the output to `config.ini`:

```ini
[app]
secret_key = 8a3d9f2e1c4b5a6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0
```

**Important:** Never commit `config.ini` to git (it's excluded via `.gitignore`).

## File Location

In Docker container:
- Config file: `/app/config.ini`
- Example: `/app/config.ini.example`

On host:
- Config file: `data/config.ini`
- Example: `data/config.ini.example`

## Backup

```bash
# Backup current configuration
cp data/config.ini data/config.ini.backup

# Restore from backup
cp data/config.ini.backup data/config.ini
docker compose restart
```

## See Also

- `../docs/README.md` - Main documentation
- `../docs/ARCHITECTURE.md` - System architecture
- `README.md` - Data directory structure
