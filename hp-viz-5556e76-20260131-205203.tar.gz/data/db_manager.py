"""
Database Manager for GNSS Interference Visualization
Handles SQLite database operations for 30-day event persistence
"""

import sqlite3
import time
import json
import os
import logging
from datetime import datetime

# Database configuration
DB_PATH = '/app/event_data.db'
DB_VERSION = 1

def init_database():
    """Initialize database schema on first run"""
    logging.info("Initializing database schema...")

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # Enable WAL mode for concurrent reads during writes
    cursor.execute('PRAGMA journal_mode=WAL')
    cursor.execute('PRAGMA synchronous=NORMAL')  # Balance durability vs speed

    # Create event_batches table - primary storage for WSS batches
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS event_batches (
            batch_id INTEGER PRIMARY KEY AUTOINCREMENT,
            batch_timestamp REAL NOT NULL,
            batch_data TEXT NOT NULL,
            created_at REAL NOT NULL
        )
    ''')

    # Create indexes for event_batches
    cursor.execute('''
        CREATE INDEX IF NOT EXISTS idx_batches_timestamp
        ON event_batches(batch_timestamp)
    ''')

    cursor.execute('''
        CREATE INDEX IF NOT EXISTS idx_batches_created_at
        ON event_batches(created_at)
    ''')

    # Create events table - individual event records
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS events (
            event_id TEXT PRIMARY KEY,
            sensor_id TEXT NOT NULL,
            event_type TEXT NOT NULL CHECK(event_type IN ('spoofer', 'jammer', 'unknown')),
            batch_timestamp REAL NOT NULL,
            event_data TEXT NOT NULL,
            ob_time TEXT NOT NULL,
            created_at REAL NOT NULL
        )
    ''')

    # Create indexes for events
    cursor.execute('''
        CREATE INDEX IF NOT EXISTS idx_events_batch_ts
        ON events(batch_timestamp)
    ''')

    cursor.execute('''
        CREATE INDEX IF NOT EXISTS idx_events_created_at
        ON events(created_at)
    ''')

    cursor.execute('''
        CREATE INDEX IF NOT EXISTS idx_events_sensor
        ON events(sensor_id)
    ''')

    cursor.execute('''
        CREATE INDEX IF NOT EXISTS idx_events_type
        ON events(event_type)
    ''')

    # Create sensors table - sensor metadata
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS sensors (
            sensor_id TEXT PRIMARY KEY,
            sensor_data TEXT NOT NULL,
            first_seen REAL NOT NULL,
            last_seen REAL NOT NULL
        )
    ''')

    # Create event_metadata table - aggregated statistics
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS event_metadata (
            event_id TEXT PRIMARY KEY,
            total_readings INTEGER DEFAULT 0,
            first_seen REAL NOT NULL,
            last_seen REAL NOT NULL,
            FOREIGN KEY (event_id) REFERENCES events(event_id) ON DELETE CASCADE
        )
    ''')

    # Create schema_version table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS schema_version (
            version INTEGER PRIMARY KEY,
            applied_at REAL NOT NULL
        )
    ''')

    # Insert schema version if not exists
    cursor.execute('SELECT version FROM schema_version WHERE version = ?', (DB_VERSION,))
    if cursor.fetchone() is None:
        cursor.execute('INSERT INTO schema_version VALUES (?, ?)', (DB_VERSION, time.time()))
        logging.info(f"Database schema version {DB_VERSION} initialized")

    conn.commit()
    conn.close()

    logging.info("Database schema initialized successfully")


def get_db_connection():
    """Get database connection with optimized settings"""
    conn = sqlite3.connect(DB_PATH, timeout=10.0)
    conn.row_factory = sqlite3.Row  # Access columns by name
    conn.execute('PRAGMA journal_mode=WAL')
    return conn


def check_db_integrity():
    """Check database integrity on startup"""
    try:
        conn = sqlite3.connect(DB_PATH, timeout=5.0)
        cursor = conn.execute('PRAGMA integrity_check')
        result = cursor.fetchone()[0]
        conn.close()

        if result != 'ok':
            logging.error(f"Database integrity check failed: {result}")
            backup_path = f'{DB_PATH}.corrupted.{int(time.time())}'
            os.rename(DB_PATH, backup_path)
            logging.warning(f"Corrupted database moved to {backup_path}")
            init_database()
            return False
        else:
            logging.info("Database integrity check passed")
            return True
    except Exception as e:
        logging.error(f"Integrity check failed: {e}")
        return False


def insert_batch(batch_data):
    """
    Insert a batch of events into the database

    Args:
        batch_data: Dict with 'events' (list) and 'timestamp' (ISO string)

    Returns:
        int: batch_id of inserted batch
    """
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        # Parse timestamp - handle multiple formats from WSS servers
        timestamp_str = batch_data.get('timestamp')
        if timestamp_str:
            # Remove fractional seconds if present
            timestamp_str = timestamp_str.split('.')[0]

            # Try multiple timestamp formats
            timestamp_formats = [
                '%Y-%m-%dT%H:%M:%S',  # ISO format: 2025-12-21T05:29:19
                '%Y-%m-%d %H:%M:%S',  # Space format: 2025-12-21 05:29:19
            ]

            batch_timestamp = None
            for fmt in timestamp_formats:
                try:
                    batch_timestamp = time.mktime(time.strptime(timestamp_str, fmt))
                    break
                except ValueError:
                    continue

            if batch_timestamp is None:
                logging.warning(f"Could not parse timestamp '{timestamp_str}', using current time")
                batch_timestamp = time.time()
        else:
            batch_timestamp = time.time()

        created_at = time.time()

        # Insert batch record
        cursor.execute('''
            INSERT INTO event_batches (batch_timestamp, batch_data, created_at)
            VALUES (?, ?, ?)
        ''', (batch_timestamp, json.dumps(batch_data), created_at))

        batch_id = cursor.lastrowid

        # Insert individual events
        for event in batch_data.get('events', []):
            event_id = event.get('id')
            sensor_id = event.get('idSensor')
            event_type = event.get('eventType', 'unknown')
            ob_time = event.get('obTime', timestamp_str)

            if event_id:
                # Insert or replace event
                cursor.execute('''
                    INSERT OR REPLACE INTO events
                    (event_id, sensor_id, event_type, batch_timestamp, event_data, ob_time, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ''', (event_id, sensor_id, event_type, batch_timestamp, json.dumps(event), ob_time, created_at))

                # Update event metadata
                cursor.execute('''
                    INSERT INTO event_metadata (event_id, total_readings, first_seen, last_seen)
                    VALUES (?, 1, ?, ?)
                    ON CONFLICT(event_id) DO UPDATE SET
                        total_readings = total_readings + 1,
                        last_seen = excluded.last_seen
                ''', (event_id, created_at, created_at))

        conn.commit()
        return batch_id

    except Exception as e:
        conn.rollback()
        logging.error(f"Failed to insert batch: {e}")
        raise
    finally:
        conn.close()


def insert_sensor(sensor_data):
    """
    Insert or update sensor information

    Args:
        sensor_data: Dict with sensor information (id, lat, lon, alt)
    """
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        sensor_id = sensor_data.get('id')
        created_at = time.time()

        cursor.execute('''
            INSERT INTO sensors (sensor_id, sensor_data, first_seen, last_seen)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(sensor_id) DO UPDATE SET
                sensor_data = excluded.sensor_data,
                last_seen = excluded.last_seen
        ''', (sensor_id, json.dumps(sensor_data), created_at, created_at))

        conn.commit()

    except Exception as e:
        conn.rollback()
        logging.error(f"Failed to insert sensor: {e}")
        raise
    finally:
        conn.close()


def get_batches_since(hours=24):
    """
    Get batches from the last N hours

    Args:
        hours: Number of hours to look back (default 24)

    Returns:
        list: List of batch data dicts
    """
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cutoff = time.time() - (hours * 60 * 60)

        cursor.execute('''
            SELECT batch_data, batch_timestamp
            FROM event_batches
            WHERE batch_timestamp >= ?
            ORDER BY batch_timestamp ASC
        ''', (cutoff,))

        batches = []
        for row in cursor.fetchall():
            batch_data = json.loads(row['batch_data'])

            # Reconstruct timestamp from batch_timestamp (convert Unix timestamp to datetime string)
            # Frontend expects format: "2025-12-28 00:19:08"
            timestamp_dt = datetime.fromtimestamp(row['batch_timestamp'])
            batch_data['timestamp'] = timestamp_dt.strftime('%Y-%m-%d %H:%M:%S')

            batches.append(batch_data)

        return batches

    finally:
        conn.close()


def get_readings_count_since(hours=24):
    """
    Get event readings count for events in the last N hours

    Args:
        hours: Number of hours to look back (default 24)

    Returns:
        dict: {event_id: total_readings}
    """
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cutoff = time.time() - (hours * 60 * 60)

        cursor.execute('''
            SELECT em.event_id, em.total_readings
            FROM event_metadata em
            JOIN events e ON em.event_id = e.event_id
            WHERE e.batch_timestamp >= ?
        ''', (cutoff,))

        readings_count = {row['event_id']: row['total_readings'] for row in cursor.fetchall()}
        return readings_count

    finally:
        conn.close()


def get_all_sensors():
    """Get all sensors from database"""
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute('SELECT sensor_data FROM sensors')
        sensors = [json.loads(row['sensor_data']) for row in cursor.fetchall()]
        return sensors

    finally:
        conn.close()


def get_events(limit=1000):
    """
    Get recent events from database

    Args:
        limit: Maximum number of events to return

    Returns:
        list: List of event data dicts
    """
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute('''
            SELECT event_data
            FROM events
            ORDER BY batch_timestamp DESC
            LIMIT ?
        ''', (limit,))

        events = [json.loads(row['event_data']) for row in cursor.fetchall()]
        return events

    finally:
        conn.close()


def get_stats():
    """
    Get statistics about events in database

    Returns:
        dict: Statistics including counts and averages
    """
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        # Count events by type
        cursor.execute('''
            SELECT
                event_type,
                COUNT(*) as count,
                AVG(CAST(json_extract(event_data, '$.power[0]') AS REAL)) as avg_power
            FROM events
            GROUP BY event_type
        ''')

        stats = {}
        for row in cursor.fetchall():
            stats[row['event_type']] = {
                'count': row['count'],
                'avg_power': row['avg_power']
            }

        return stats

    finally:
        conn.close()


def delete_old_events(days=30):
    """
    Delete events older than N days

    Args:
        days: Age threshold in days (default 30)

    Returns:
        int: Number of events deleted
    """
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cutoff = time.time() - (days * 24 * 60 * 60)

        # Delete old events
        cursor.execute('DELETE FROM events WHERE created_at < ?', (cutoff,))
        events_deleted = cursor.rowcount

        # Delete old batches
        cursor.execute('DELETE FROM event_batches WHERE created_at < ?', (cutoff,))
        batches_deleted = cursor.rowcount

        conn.commit()

        logging.info(f"Deleted {events_deleted} events and {batches_deleted} batches older than {days} days")
        return events_deleted

    except Exception as e:
        conn.rollback()
        logging.error(f"Failed to delete old events: {e}")
        raise
    finally:
        conn.close()


def get_old_events(days=30):
    """
    Get events older than N days (for archival)

    Args:
        days: Age threshold in days (default 30)

    Returns:
        list: List of event data dicts
    """
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cutoff = time.time() - (days * 24 * 60 * 60)

        cursor.execute('''
            SELECT event_data, batch_timestamp
            FROM events
            WHERE created_at < ?
            ORDER BY batch_timestamp ASC
        ''', (cutoff,))

        old_events = []
        for row in cursor.fetchall():
            event = json.loads(row['event_data'])
            event['_batch_timestamp'] = row['batch_timestamp']
            old_events.append(event)

        return old_events

    finally:
        conn.close()


def get_analytics_data(days=7, sensor_id=None):
    """
    Get aggregated analytics data for the specified number of days.

    Args:
        days: Number of days to look back (default 7, max 30)
        sensor_id: Optional sensor ID to filter by (default None for all sensors)

    Returns:
        dict with keys:
        - days: Number of days queried
        - totals: {total_events, spoofers, jammers, sensors_active}
        - events_by_sensor: [{sensor_id, spoofers, jammers, total}]
        - events_by_hour: [{hour: 0-23, spoofers, jammers}]
        - events_by_weekday: [{weekday: 0-6, name, spoofers, jammers}]
        - events_by_date: [{date: 'YYYY-MM-DD', spoofers, jammers}]
    """
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cutoff_timestamp = time.time() - (days * 24 * 60 * 60)

        # Build sensor filter condition
        sensor_condition = ""
        params = [cutoff_timestamp]
        if sensor_id:
            sensor_condition = " AND sensor_id = ?"
            params.append(sensor_id)

        # Events by sensor
        cursor.execute(f'''
            SELECT sensor_id, event_type, COUNT(*) as count
            FROM events
            WHERE batch_timestamp >= ?{sensor_condition}
            GROUP BY sensor_id, event_type
        ''', params)

        sensor_data = {}
        for row in cursor.fetchall():
            sid = row['sensor_id']
            if sid not in sensor_data:
                sensor_data[sid] = {'sensor_id': sid, 'spoofers': 0, 'jammers': 0, 'total': 0}
            if row['event_type'] == 'spoofer':
                sensor_data[sid]['spoofers'] = row['count']
            elif row['event_type'] == 'jammer':
                sensor_data[sid]['jammers'] = row['count']
            sensor_data[sid]['total'] += row['count']

        events_by_sensor = list(sensor_data.values())

        # Events by hour of day (using ob_time)
        cursor.execute(f'''
            SELECT
                CAST(strftime('%H', ob_time) AS INTEGER) as hour,
                event_type,
                COUNT(*) as count
            FROM events
            WHERE batch_timestamp >= ?{sensor_condition}
            GROUP BY hour, event_type
            ORDER BY hour
        ''', params)

        hour_data = {h: {'hour': h, 'spoofers': 0, 'jammers': 0} for h in range(24)}
        for row in cursor.fetchall():
            hour = row['hour']
            if hour is not None:
                if row['event_type'] == 'spoofer':
                    hour_data[hour]['spoofers'] = row['count']
                elif row['event_type'] == 'jammer':
                    hour_data[hour]['jammers'] = row['count']

        events_by_hour = list(hour_data.values())

        # Events by day of week (0=Sunday, 6=Saturday)
        weekday_names = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
        cursor.execute(f'''
            SELECT
                CAST(strftime('%w', ob_time) AS INTEGER) as weekday,
                event_type,
                COUNT(*) as count
            FROM events
            WHERE batch_timestamp >= ?{sensor_condition}
            GROUP BY weekday, event_type
            ORDER BY weekday
        ''', params)

        weekday_data = {w: {'weekday': w, 'name': weekday_names[w], 'spoofers': 0, 'jammers': 0} for w in range(7)}
        for row in cursor.fetchall():
            weekday = row['weekday']
            if weekday is not None:
                if row['event_type'] == 'spoofer':
                    weekday_data[weekday]['spoofers'] = row['count']
                elif row['event_type'] == 'jammer':
                    weekday_data[weekday]['jammers'] = row['count']

        events_by_weekday = list(weekday_data.values())

        # Events by date (for timeline)
        cursor.execute(f'''
            SELECT
                date(ob_time) as date,
                event_type,
                COUNT(*) as count
            FROM events
            WHERE batch_timestamp >= ?{sensor_condition}
            GROUP BY date, event_type
            ORDER BY date
        ''', params)

        date_data = {}
        for row in cursor.fetchall():
            date_str = row['date']
            if date_str:
                if date_str not in date_data:
                    date_data[date_str] = {'date': date_str, 'spoofers': 0, 'jammers': 0}
                if row['event_type'] == 'spoofer':
                    date_data[date_str]['spoofers'] = row['count']
                elif row['event_type'] == 'jammer':
                    date_data[date_str]['jammers'] = row['count']

        events_by_date = list(date_data.values())

        # Calculate totals
        total_spoofers = sum(s['spoofers'] for s in events_by_sensor)
        total_jammers = sum(s['jammers'] for s in events_by_sensor)
        total_events = total_spoofers + total_jammers
        sensors_active = len(events_by_sensor)

        return {
            'days': days,
            'totals': {
                'total_events': total_events,
                'spoofers': total_spoofers,
                'jammers': total_jammers,
                'sensors_active': sensors_active
            },
            'events_by_sensor': events_by_sensor,
            'events_by_hour': events_by_hour,
            'events_by_weekday': events_by_weekday,
            'events_by_date': events_by_date
        }

    finally:
        conn.close()
