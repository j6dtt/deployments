# Gunicorn configuration file for production deployment
import multiprocessing
import os

# Server socket
bind = "0.0.0.0:8043"  # HTTPS port
backlog = 2048

# Worker processes
# IMPORTANT: Using 1 worker because WSS connections are created per worker
# Multiple workers = duplicate WSS connections + isolated data stores
# For high load, use Redis message queue instead of multiple workers
workers = 1
worker_class = "eventlet"  # Required for SocketIO support
worker_connections = 1000  # Eventlet can handle many concurrent connections with 1 worker
timeout = 120
keepalive = 5

# SSL/TLS Configuration
certfile = os.path.join(os.path.dirname(__file__), "certs", "cert.pem")
keyfile = os.path.join(os.path.dirname(__file__), "certs", "key.pem")

# Certificate chain (for publicly signed certificates)
# If you have intermediate certificates, uncomment and provide the CA bundle:
ca_certs = os.path.join(os.path.dirname(__file__), "certs", "ca-bundle.crt")
if not os.path.exists(ca_certs):
    ca_certs = None

# SSL/TLS Protocol Configuration
# Use modern TLS (1.2 and 1.3) - this is the CORRECT way to configure TLS
import ssl
ssl_version = ssl.PROTOCOL_TLS_SERVER  # Enables TLS 1.2+ (not SSLv2!)

# Restrict to TLS 1.2 and above (disable older protocols)
# This ensures no SSLv2, SSLv3, TLS 1.0, or TLS 1.1
import ssl
ssl_options = (
    ssl.OP_NO_SSLv2 |
    ssl.OP_NO_SSLv3 |
    ssl.OP_NO_TLSv1 |
    ssl.OP_NO_TLSv1_1
)

# Modern cipher suite (strong encryption only)
ciphers = 'ECDHE+AESGCM:ECDHE+CHACHA20:DHE+AESGCM:DHE+CHACHA20:!aNULL:!MD5:!DSS'

# Logging
accesslog = "-"  # Log to stdout
errorlog = "-"   # Log to stderr
loglevel = "info"
access_log_format = '%(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s "%(f)s" "%(a)s"'

# Process naming
proc_name = "harmonious-pawn-viz"

# Server mechanics
daemon = False
pidfile = None
umask = 0
user = None
group = None
tmp_upload_dir = None
