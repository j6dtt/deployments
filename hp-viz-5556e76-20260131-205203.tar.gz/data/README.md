# Data Directory for Docker Compose

This directory contains all application files that are mounted into the Docker container.

## Structure

```
data/
├── app.py                    # Dashboard Flask application
├── db_manager.py             # SQLite database operations
├── db_dump.py                # Database dump & restore tool
├── archiver.py               # 30-day archival system
├── central_wss_server.py     # Central WSS server (CEF → JSON relay)
├── central_wss_config.py     # Central WSS configuration
├── gunicorn_config.py        # Gunicorn configuration
├── config.ini                # Dashboard WSS server configuration
├── requirements.txt          # Python dependencies (includes APScheduler)
├── event_data.db             # SQLite database (auto-created)
├── archives/                 # Archived events (auto-created)
│   └── events_YYYY-MM-DD.json
├── certs/                    # TLS certificates (YOU provide)
│   ├── cert.pem             # Public certificate (required)
│   └── key.pem              # Private key (required)
├── templates/                # HTML templates
│   ├── index.html           # Main dashboard
│   ├── analytics.html       # Analytics dashboard
│   └── login.html           # Login page
└── static/                   # Static files
    ├── css/
    ├── js/
    └── ...
```

## How It Works

### Docker Compose Setup

The `docker-compose.yml` mounts this entire directory into the container:

```yaml
volumes:
  - ./data:/app
```

All files in this directory are accessible inside the container at `/app`.

### Startup Process

**Two containers start:**

1. **central-wss container** runs `central_wss_server.py`
   - Listens for CEF data on TCP port 6911 (from upstream sensors)
   - Parses CEF and transforms to JSON
   - Broadcasts JSON to dashboard via WebSocket Secure (port 8766)
   - Sends keepalive messages every 10 seconds

2. **uhu-viz container** runs `app.py` via Gunicorn
   - Connects to central-wss:8766 as WebSocket client
   - Receives JSON event batches
   - Stores events in SQLite database (30-day retention)
   - Starts APScheduler for daily midnight archival
   - Serves HTTPS dashboard on port 8043 (Gunicorn + Eventlet)
   - Loads TLS certificates from `certs/cert.pem` and `certs/key.pem`
   - Handles 1000+ concurrent browser connections

### Required Files

You must provide these files:

```
data/certs/cert.pem   # TLS certificate (public)
data/certs/key.pem    # Private key
```

These are **excluded from git** (see `.gitignore`).

## Usage

From the parent directory (`/apps/viz`):

```bash
# 1. Place certificates
cp /path/to/cert.pem data/certs/
cp /path/to/key.pem data/certs/

# 2. Start container
docker compose up -d

# 3. View logs
docker compose logs -f

# 4. Check health
docker compose ps

# 5. Stop container
docker compose down
```

Access: **https://localhost:8043**

## Healthcheck

The container includes a healthcheck that:
- Runs every 30 seconds
- Tests HTTPS endpoint on port 8043
- Considers container unhealthy after 3 consecutive failures
- Waits 40 seconds after startup before first check

Check status:
```bash
docker compose ps
# STATUS column shows (healthy) or (unhealthy)
```

## Modifying the Application

Since this directory is mounted as a volume, you can edit files locally and restart:

```bash
# Edit files in data/ directory
vim data/app.py

# Restart to apply changes
docker compose restart

# View logs
docker compose logs -f
```

## Troubleshooting

### Certificates missing
```bash
# Check if certificates exist
ls -la data/certs/

# Copy your certificates
cp /path/to/cert.pem data/certs/
cp /path/to/key.pem data/certs/

# Restart
docker compose restart
```

### Certificate permissions
```bash
chmod 644 data/certs/cert.pem
chmod 600 data/certs/key.pem
```

### View container logs
```bash
docker compose logs -f uhu-viz
```

### Execute commands in container
```bash
docker compose exec uhu-viz bash
```

## Data Persistence

Events are stored in `event_data.db` and persist across container restarts:
- **Retention**: 30 days of event history
- **Archival**: Events older than 30 days archived to `archives/events_YYYY-MM-DD.json`
- **Schedule**: Automatic archival runs daily at midnight UTC
- **Client reconnection**: Last 7 days sent to browsers on refresh

Manual archival:
```bash
docker exec uhu-viz python /app/archiver.py
docker exec uhu-viz python /app/archiver.py stats
```

Database dump & restore (run from host):
```bash
python3 data/db_dump.py dump       # Export to data/dump/
python3 data/db_dump.py restore    # Create db from data/dump/
python3 data/db_dump.py info       # Show dump statistics
```

## Important Notes

1. **Provide your own certificates** - Place `cert.pem` and `key.pem` in `certs/` (for HTTPS dashboard)
2. **Dependencies pre-installed** - The `python:3.13-slim-u3` image has all packages (including APScheduler)
3. **Central WSS architecture** - Upstream → CEF → central-wss → JSON → dashboard (see ../docs/ARCHITECTURE.md)
4. **Volume mount** - Files in `data/` are directly accessible in both containers at `/app`
5. **Database and archives persist** - Survive container restarts via volume mount
