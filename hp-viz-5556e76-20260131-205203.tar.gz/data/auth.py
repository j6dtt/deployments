"""
Authentication helpers for GNSS Interference Visualization
Manages user authentication via JSON config file
"""
import json
import os
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin

USERS_FILE = '/app/users.json'


class User(UserMixin):
    """User class for Flask-Login"""

    def __init__(self, username, role, sensors):
        self.id = username
        self.username = username
        self.role = role
        self.sensors = sensors

    def is_admin(self):
        """Check if user has admin role"""
        return self.role == 'admin'

    def can_access_sensor(self, sensor_id):
        """Check if user can access a specific sensor"""
        if self.is_admin():
            return True
        return sensor_id in self.sensors or '*' in self.sensors


def load_users():
    """Load users from JSON config file"""
    if not os.path.exists(USERS_FILE):
        return {}
    try:
        with open(USERS_FILE, 'r') as f:
            data = json.load(f)
        return data.get('users', {})
    except (json.JSONDecodeError, IOError):
        return {}


def get_user(username):
    """Get user by username, returns User object or None"""
    users = load_users()
    if username in users:
        u = users[username]
        return User(username, u.get('role', 'user'), u.get('sensors', []))
    return None


def verify_password(username, password):
    """Verify username/password, returns User object or None"""
    users = load_users()
    if username not in users:
        return None
    try:
        if check_password_hash(users[username]['password_hash'], password):
            u = users[username]
            return User(username, u.get('role', 'user'), u.get('sensors', []))
    except (KeyError, TypeError):
        return None
    return None


def hash_password(password):
    """Generate password hash (for CLI tool)"""
    return generate_password_hash(password)
