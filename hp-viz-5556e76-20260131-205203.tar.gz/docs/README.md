# UHU Visualization - Docker Deployment

GNSS interference visualization with real-time WebSocket streaming.

## Quick Start

```bash
# 1. Create configuration file
cp data/config.ini.example data/config.ini
# Edit data/config.ini to configure WSS servers

# 2. Place your TLS certificates
cp /path/to/cert.pem data/certs/
cp /path/to/key.pem data/certs/

# 3. Start container
docker compose up -d

# 4. Access application
https://localhost:8043
```

## Directory Structure

```
/apps/viz/
├── docker-compose.yml          # Docker configuration
├── data/                       # Application files (mounted to /app)
│   ├── app.py                 # Flask dashboard application
│   ├── db_manager.py          # Database operations
│   ├── db_dump.py             # Database dump & restore tool
│   ├── archiver.py            # 30-day archival system
│   ├── central_wss_server.py  # Central WSS server (CEF → JSON relay)
│   ├── central_wss_config.py  # Central WSS configuration
│   ├── config.ini             # Configuration (YOU create from example)
│   ├── config.ini.example     # Configuration template
│   ├── gunicorn_config.py     # Gunicorn config (1 worker, port 8043)
│   ├── requirements.txt       # Python dependencies
│   ├── event_data.db          # SQLite database (auto-created)
│   ├── dump/                  # Database dumps (auto-created, git-ignored)
│   ├── archives/              # Archived events (auto-created)
│   │   └── events_YYYY-MM-DD.json  # Daily archive files
│   ├── certs/                 # TLS certificates (YOU provide)
│   │   ├── cert.pem          # Place your cert here
│   │   └── key.pem           # Place your key here
│   ├── templates/             # HTML templates
│   │   ├── index.html         # Main dashboard
│   │   ├── analytics.html     # Analytics dashboard
│   │   └── login.html         # Login page
│   └── static/                # Static assets (CSS, JS, images)
├── test_central_wss.py         # Test script for sending CEF to central-wss
├── docker-compose-test.sh      # Validation script
└── *.md                        # Documentation
```

## Requirements

- Docker with Compose V2
- Custom Python image: `python:3.13-slim-u3` (with pre-installed dependencies including APScheduler)
- TLS certificates (cert.pem and key.pem)

**Important**: The custom `python:3.13-slim-u3` image must include all dependencies from `data/requirements.txt`, especially:
- APScheduler==3.10.4 (required for automatic 30-day archival)

## Configuration

### docker-compose.yml

```yaml
services:
  uhu-viz:
    container_name: uhu-viz
    image: python:3.13-slim-u3      # Custom image with dependencies
    ports:
      - "8043:8043"                  # HTTPS port
    volumes:
      - ./data:/app                  # Mount application files
    command: ["gunicorn", "--config", "gunicorn_config.py", "app:app"]
    healthcheck:                     # Monitors application health
      interval: 30s
      timeout: 10s
      start_period: 40s
      retries: 3
```

### Central WSS Configuration

Edit `data/config.ini`:

```ini
[wss_servers]
server_1 = wss://central-wss:8766,Central-WSS

[app]
secret_key = spoofer-viz-secret-key
port = 8043
timeout_minutes = 3
timeout_check_seconds = 30
```

The dashboard connects to the central WSS server which aggregates data from all sensors. See `data/CONFIG.md` for full configuration guide.

### Gunicorn Settings

Edit `data/gunicorn_config.py`:

```python
bind = "0.0.0.0:8043"          # Port
workers = 1                     # Single worker (avoids duplicate WSS connections)
worker_class = "eventlet"       # Required for SocketIO
worker_connections = 1000       # Max concurrent clients per worker
certfile = "/app/certs/cert.pem"
keyfile = "/app/certs/key.pem"
```

## Usage

### Validate Setup

```bash
./docker-compose-test.sh
```

### Start Container

```bash
docker compose up -d
```

### View Logs

```bash
# Follow logs
docker compose logs -f

# Last 100 lines
docker compose logs --tail=100

# Filter for WSS connections
docker compose logs | grep WSS
```

### Check Health

```bash
# Container status
docker compose ps

# Health status
docker inspect uhu-viz --format='{{.State.Health.Status}}'
```

### Stop Container

```bash
# Stop
docker compose down

# Stop and remove volumes
docker compose down -v
```

### Restart

```bash
docker compose restart
```

## Making Code Changes

Since `data/` is mounted as a volume, you can edit files locally:

```bash
# Edit application code
vim data/app.py

# Restart to apply changes
docker compose restart

# View logs
docker compose logs -f
```

## Healthcheck

The container monitors itself every 30 seconds:

- **healthy** - Application responding on port 8043
- **starting** - Initializing (first 40 seconds)
- **unhealthy** - Failed 3 consecutive health checks

View health logs:
```bash
docker inspect uhu-viz | jq '.[0].State.Health'
```

## Troubleshooting

### Port Already in Use

```bash
sudo lsof -i :8043
sudo kill -9 <PID>
```

### Container Won't Start

```bash
docker compose logs uhu-viz
```

### Certificate Issues

```bash
# Verify certificates exist
ls -la data/certs/

# Check permissions
chmod 644 data/certs/cert.pem
chmod 600 data/certs/key.pem
```

### WSS Connection Problems

```bash
# Check WSS connection logs
docker compose logs | grep WSS

# Test network from container
docker compose exec uhu-viz ping 172.16.0.46
```

### Container Unhealthy

```bash
# View detailed health status
docker inspect uhu-viz --format='{{json .State.Health}}' | jq

# Restart container
docker compose restart
```

## Performance

- **Single Worker**: Uses 1 worker to avoid duplicate WSS connections
- **Eventlet**: Handles 1000+ concurrent clients via greenlets
- **Memory**: ~200-500 MB depending on event history
- **CPU**: Single core utilization

## Security

1. **Certificates**: Use CA-signed certificates in production
2. **Secrets**: Never commit certificates to git (excluded via `.gitignore`)
3. **Network**: Restrict access via firewall rules
4. **Updates**: Regularly update base image

## Data Persistence and Archival

### Database

Event data is persisted to SQLite database for 30-day retention:

- **Location**: `data/event_data.db` (auto-created on first run)
- **Format**: SQLite with WAL (Write-Ahead Logging) mode
- **Retention**: 30 days of event history
- **Survives**: Container restarts and rebuilds

**Tables**:
- `event_batches` - Raw batches from WSS servers
- `events` - Individual event records
- `sensors` - Sensor metadata
- `event_metadata` - Event statistics

### Archival System

Events older than 30 days are automatically archived and deleted:

- **Schedule**: Daily at midnight UTC (via APScheduler)
- **Archive Location**: `data/archives/events_YYYY-MM-DD.json`
- **Format**: JSON (human-readable)
- **Process**: Archive to file → Delete from database

**Manual archival**:
```bash
# Run archival manually
docker exec uhu-viz python /app/archiver.py

# View archive statistics
docker exec uhu-viz python /app/archiver.py stats
```

### Client Reconnection

When browsers refresh or new clients connect:
- **Receives**: Last 24 hours of event data from database
- **Performance**: <100ms query time with 10,000+ events stored
- **Benefit**: Full state restoration even after container restart

### Database Dump & Restore

The `db_dump.py` script exports the entire database to JSON files and can recreate the database from a dump. Useful for migrations, backups, and transferring data between environments.

```bash
# Dump database to data/dump/
python3 data/db_dump.py dump

# Restore database from data/dump/
docker compose down
python3 data/db_dump.py restore
docker compose up -d

# Show dump statistics
python3 data/db_dump.py info
```

**Dump output** (`data/dump/`):
- `manifest.json` - Dump metadata and row counts
- `event_batches.json` - Raw WSS batches
- `events.json` - Individual event records
- `sensors.json` - Sensor metadata
- `event_metadata.json` - Event statistics
- `schema_version.json` - Schema version

**Custom paths:**
```bash
python3 data/db_dump.py dump --db data/event_data.db --dir /path/to/dump
python3 data/db_dump.py restore --db data/event_data.db --dir /path/to/dump
```

**Note**: On restore, the existing database is automatically backed up to `event_data.db.backup`.

### Backup

Database and archives persist via Docker volume:

```bash
# Backup database
docker exec uhu-viz cp /app/event_data.db /app/event_data.db.backup

# Backup archives
cp -r data/archives/ ~/backups/uhu-viz-archives-$(date +%Y%m%d)/

# View database size
docker exec uhu-viz ls -lh /app/event_data.db
```

## Testing

### Test Event Generator

The `test_events.py` script generates simulated GNSS interference events for testing persistence, browser refresh, and timeout behavior without waiting for real events.

**Generate Recent Events (Active Events Table):**
```bash
# Generate 10 events (0-2 minutes old) for Active Events table
docker exec uhu-viz python /app/test_events.py generate --recent --count 10

# Specify event type
docker exec uhu-viz python /app/test_events.py generate --recent --type spoofer
docker exec uhu-viz python /app/test_events.py generate --recent --type jammer
docker exec uhu-viz python /app/test_events.py generate --recent --type mixed  # default
```

**Generate Historical Events:**
```bash
# Generate events spread over 10 minutes (some in History table)
docker exec uhu-viz python /app/test_events.py generate --count 10 --spread 10
```

**View Database Status:**
```bash
docker exec uhu-viz python /app/test_events.py status
```

**Clean Up Test Events:**
```bash
# Remove all test events from database
docker exec uhu-viz python /app/test_events.py cleanup

# IMPORTANT: Refresh browser (F5) after cleanup to clear from browser memory
```

### Testing Scenarios

**Test 1: Browser Refresh Persistence**
```bash
# 1. Generate test events
docker exec uhu-viz python /app/test_events.py generate --recent --count 5

# 2. Refresh browser - events should appear in Active Events table
# 3. Refresh again - events should still be there (persistence working)
# 4. Clean up
docker exec uhu-viz python /app/test_events.py cleanup
```

**Test 2: Event Timeout Behavior**
```bash
# 1. Generate active events
docker exec uhu-viz python /app/test_events.py generate --recent --count 5

# 2. Watch Active Events table in browser
# 3. Wait 3-4 minutes
# 4. Events should automatically move to History table
# 5. Refresh browser - events should remain in History (persistence working)
# 6. Clean up
docker exec uhu-viz python /app/test_events.py cleanup
```

**Test 3: Mixed Active and Historical Events**
```bash
# 1. Generate both active and historical events
docker exec uhu-viz python /app/test_events.py generate --recent --count 5
docker exec uhu-viz python /app/test_events.py generate --count 5 --spread 10

# 2. Refresh browser
# 3. Verify ~5 events in Active Events, ~5 in History
# 4. Clean up
docker exec uhu-viz python /app/test_events.py cleanup
```

### Test Event Details

- **Event ID Prefix**: `TEST-EVENT-` (for easy identification)
- **Location**: Near Bahrain (26.2085°N, 50.6090°E)
- **Sensor**: `uhu-bhr`
- **Power**: Randomized realistic values
- **Frequencies**: GPS L1 (1575.42 MHz) and L2 (1227.60 MHz)
- **Cleanup**: Test events are completely removed from database (events, metadata, batches)

**Note**: Test events use the same database schema as real events, so they fully test persistence, state restoration, and timeout behavior.

## Analytics Dashboard

The application includes an interactive Analytics dashboard accessible at `/analytics`.

### Features

- **KPI Cards** - Total events, spoofers, jammers, and active sensors
- **Events by Sensor** - Doughnut chart showing event distribution with percentages
- **Events Over Time** - Line chart showing spoofer/jammer trends
- **Time of Day** - Bar chart showing event patterns by hour (UTC)
- **Day of Week** - Bar chart showing weekly patterns
- **Date Range Slider** - Adjust analysis window from 1-30 days
- **Sensor Filter** - Filter all charts by specific sensor

### Access

Navigate to the Analytics page via the button in the dashboard header, or directly at:
```
https://localhost:8043/analytics
```

### API Endpoint

**Note:** API endpoints require authentication. See `docs/API.md` for authentication details.

```bash
# First, login and save cookies
curl -k -c cookies.txt -X POST https://localhost:8043/login \
  -d "username=admin&password=yourpassword"

# Then use cookies for API requests
curl -k -b cookies.txt https://localhost:8043/api/analytics

# Get analytics for specific date range
curl -k -b cookies.txt "https://localhost:8043/api/analytics?days=14"

# Filter by sensor
curl -k -b cookies.txt "https://localhost:8043/api/analytics?days=7&sensor=hp-bhr.10.4"
```

## Documentation

All documentation is in the `/docs` directory:

- `docs/ARCHITECTURE.md` - Central WSS architecture with complete event schemas
- `docs/API.md` - Complete API reference (REST endpoints and WebSocket events)
- `docs/TROUBLESHOOTING.md` - Common issues and solutions
- `docs/CLEANUP_GUIDE.md` - Database cleanup procedures
- `docs/DOCUMENTATION_INDEX.md` - Complete documentation guide
- `data/README.md` - Data directory structure and certificate setup
- `data/CONFIG.md` - Configuration reference

## Architecture

### Current: Central WSS Server

```
Sensor 1 → Upstream ┐
Sensor 2 → Upstream ├→ CEF (TCP 6911) → Central WSS Server → JSON (WSS 8766) → Dashboard
Sensor 3 → Upstream ┘                                                              ↓
                                                                          Browser (HTTPS 8043)
```

**Components:**
- **central-wss**: Receives CEF from upstream processes (TCP 6911), broadcasts JSON to dashboard (WSS 8766)
- **uhu-viz**: Dashboard application (Flask + SocketIO, HTTPS 8043)

**Data Flow:**
1. Upstream sensor processes send CEF messages to central-wss (TCP port 6911)
2. Central-wss transforms CEF → JSON and broadcasts via WebSocket Secure (port 8766)
3. Dashboard receives events, stores in SQLite, and displays real-time visualization
4. Browser clients connect via HTTPS (port 8043)

See `data/central_wss_server.py` and `data/central_wss_config.py` for implementation details.

## Support

For issues:
1. Check logs: `docker compose logs -f`
2. Verify health: `docker compose ps`
3. Test connectivity: `./docker-compose-test.sh`
4. Review documentation in `docs/*.md` files

## License

Internal use only
