# UHU Visualization API Documentation

Complete API reference for the GNSS Interference Visualization system.

## Table of Contents

- [Overview](#overview)
- [Base URL](#base-url)
- [Authentication](#authentication)
- [REST API Endpoints](#rest-api-endpoints)
- [WebSocket API](#websocket-api)
- [Data Structures](#data-structures)
- [Event Lifecycle and Timeout Configuration](#event-lifecycle-and-timeout-configuration)
- [Examples](#examples)

## Overview

The UHU Visualization API provides both REST endpoints and real-time WebSocket communication for GNSS interference event monitoring. The system tracks jamming and spoofing events from multiple sensors, stores 30 days of historical data, and provides real-time updates to connected clients.

**Features:**
- Real-time event streaming via WebSocket
- 30-day event persistence in SQLite database
- Automatic archival of events older than 30 days
- Client state restoration (last 24 hours on reconnection)
- Multi-sensor support with geographic visualization

## Base URL

```
https://localhost:8043
```

**Protocol:** HTTPS only
**WebSocket:** WSS (WebSocket Secure)

## Authentication

The API requires authentication via Flask-Login. Users must log in before accessing API endpoints.

### Browser Access
Most API endpoints are accessed via the browser after logging in at `/login`. The session cookie handles authentication automatically.

### Programmatic Access (curl/scripts)

For programmatic API access, you need to:

1. **Login and capture cookies:**
```bash
# Login and save session cookie
curl -k -c cookies.txt -X POST https://localhost:8043/login \
  -d "username=admin&password=yourpassword"
```

2. **Use cookies for API calls:**
```bash
# Use saved cookies for API requests
curl -k -b cookies.txt https://localhost:8043/api/analytics?days=7
curl -k -b cookies.txt https://localhost:8043/api/sensors
curl -k -b cookies.txt https://localhost:8043/api/events
```

### Python Example with Session

```python
import requests

# Create session to maintain cookies
session = requests.Session()
session.verify = False  # For self-signed certs

# Login
login_response = session.post('https://localhost:8043/login', data={
    'username': 'admin',
    'password': 'yourpassword'
})

# Now make authenticated API calls
analytics = session.get('https://localhost:8043/api/analytics?days=7')
print(analytics.json())

sensors = session.get('https://localhost:8043/api/sensors')
print(sensors.json())
```

**Note:** Replace `admin` and `yourpassword` with valid credentials configured in your users file.

---

## REST API Endpoints

### 1. Get Main Page

**Endpoint:** `GET /`

**Description:** Serves the main HTML interface with embedded map visualization.

**Response:**
- **Content-Type:** `text/html`
- **Status Code:** `200 OK`

**Example (curl):**
```bash
curl -k https://localhost:8043/
```

**Example (Python):**
```python
import requests
response = requests.get('https://localhost:8043/', verify=False)
print(response.text[:500])  # First 500 characters
```

---

### 2. Get Map Tiles

**Endpoint:** `GET /tiles/<z>/<x>/<y>.png`

**Description:** Serves cached map tiles for offline operation.

**Parameters:**
- `z` (path, integer): Zoom level
- `x` (path, integer): Tile X coordinate
- `y` (path, integer): Tile Y coordinate

**Response:**
- **Content-Type:** `image/png`
- **Status Code:** `200 OK` or `404 Not Found`

**Example (curl):**
```bash
curl -k https://localhost:8043/tiles/10/234/567.png -o tile.png
```

**Example (Python):**
```python
import requests
response = requests.get('https://localhost:8043/tiles/10/234/567.png', verify=False)
with open('tile.png', 'wb') as f:
    f.write(response.content)
```

---

### 3. Get All Sensors

**Endpoint:** `GET /api/sensors`

**Description:** Retrieves all known sensors from the database.

**Response:**
```json
{
  "count": 2,
  "sensors": [
    {
      "id": "UHU-OMN",
      "lat": 40.7128,
      "lon": -74.0060,
      "alt": 10.5
    },
    {
      "id": "UHU-BHR",
      "lat": 40.7580,
      "lon": -73.9855,
      "alt": 15.2
    }
  ]
}
```

**Fields:**
- `count` (integer): Number of sensors
- `sensors` (array): List of sensor objects
  - `id` (string): Unique sensor identifier
  - `lat` (float): Latitude in decimal degrees
  - `lon` (float): Longitude in decimal degrees
  - `alt` (float): Altitude in meters

**Example (curl):**
```bash
curl -k https://localhost:8043/api/sensors
```

**Example (Python):**
```python
import requests
response = requests.get('https://localhost:8043/api/sensors', verify=False)
data = response.json()
print(f"Total sensors: {data['count']}")
for sensor in data['sensors']:
    print(f"  {sensor['id']}: ({sensor['lat']}, {sensor['lon']})")
```

---

### 4. Get Recent Events

**Endpoint:** `GET /api/events`

**Description:** Retrieves recent events from the database with optional limit.

**Query Parameters:**
- `limit` (integer, optional): Maximum number of events to return (default: 1000)

**Response:**
```json
{
  "count": 5,
  "events": [
    {
      "id": "event-123",
      "idSensor": "UHU-OMN",
      "eventType": "spoofer",
      "obTime": "2025-12-18T10:30:45.123Z",
      "latitude": 40.7128,
      "longitude": -74.0060,
      "altitude": 10.5,
      "power": [-45.5, -42.3],
      "frequency": [1575.42, 1227.60]
    }
  ]
}
```

**Event Fields:**
- `id` (string): Unique event identifier
- `idSensor` (string): Sensor that detected the event
- `eventType` (string): `"spoofer"`, `"jammer"`, or `"unknown"`
- `obTime` (string): ISO 8601 timestamp
- `latitude` (float): Event latitude
- `longitude` (float): Event longitude
- `altitude` (float): Event altitude in meters
- `power` (array of floats): Signal power measurements in dBm
- `frequency` (array of floats): Frequencies in MHz

**Example (curl):**
```bash
# Get last 100 events
curl -k "https://localhost:8043/api/events?limit=100"
```

**Example (Python):**
```python
import requests
response = requests.get(
    'https://localhost:8043/api/events',
    params={'limit': 100},
    verify=False
)
data = response.json()
print(f"Retrieved {data['count']} events")
for event in data['events'][:5]:  # First 5
    print(f"  {event['eventType']}: {event['id']}")
```

---

### 5. Get Event by ID

**Endpoint:** `GET /api/events/<event_id>`

**Description:** Retrieves a specific event by its ID.

**Parameters:**
- `event_id` (path, string): Unique event identifier

**Response:**
```json
{
  "id": "event-123",
  "idSensor": "UHU-OMN",
  "eventType": "spoofer",
  "obTime": "2025-12-18T10:30:45.123Z",
  "latitude": 40.7128,
  "longitude": -74.0060,
  "altitude": 10.5,
  "power": [-45.5, -42.3],
  "frequency": [1575.42, 1227.60]
}
```

**Status Codes:**
- `200 OK`: Event found
- `404 Not Found`: Event not found

**Example (curl):**
```bash
curl -k https://localhost:8043/api/events/event-123
```

**Example (Python):**
```python
import requests
event_id = "event-123"
response = requests.get(f'https://localhost:8043/api/events/{event_id}', verify=False)
if response.status_code == 200:
    event = response.json()
    print(f"{event['eventType']}: {event['id']}")
    print(f"  Sensor: {event['idSensor']}")
    print(f"  Location: ({event['latitude']}, {event['longitude']})")
else:
    print(f"Event not found: {event_id}")
```

---

### 6. Get Statistics

**Endpoint:** `GET /api/stats`

**Description:** Retrieves aggregated statistics about events and system status.

**Response:**
```json
{
  "total_events": 150,
  "spoofer_count": 75,
  "jammer_count": 73,
  "avg_spoofer_power": -45.5,
  "avg_jammer_power": -52.3,
  "sensors": [
    {
      "id": "UHU-OMN",
      "lat": 40.7128,
      "lon": -74.0060,
      "alt": 10.5
    }
  ],
  "wss_servers": {
    "UHU-OMN": true,
    "UHU-BHR": true
  }
}
```

**Fields:**
- `total_events` (integer): Total number of events in database
- `spoofer_count` (integer): Number of spoofing events
- `jammer_count` (integer): Number of jamming events
- `avg_spoofer_power` (float): Average power of spoofer events (dBm)
- `avg_jammer_power` (float): Average power of jammer events (dBm)
- `sensors` (array): List of all known sensors
- `wss_servers` (object): WSS server connection status (true/false)

**Example (curl):**
```bash
curl -k https://localhost:8043/api/stats
```

**Example (Python):**
```python
import requests
response = requests.get('https://localhost:8043/api/stats', verify=False)
stats = response.json()
print(f"Total events: {stats['total_events']}")
print(f"Spoofers: {stats['spoofer_count']}")
print(f"Jammers: {stats['jammer_count']}")
print(f"WSS servers connected: {stats['wss_servers']}")
```

---

### 7. Get Event History

**Endpoint:** `GET /api/history`

**Description:** Retrieves the last 3 days of ended events for the history table.

**Response:**
```json
{
  "count": 0,
  "events": []
}
```

**Note:** This endpoint currently returns an empty array as the history is managed client-side. Future versions may populate this from the database.

**Example (curl):**
```bash
curl -k https://localhost:8043/api/history
```

**Example (Python):**
```python
import requests
response = requests.get('https://localhost:8043/api/history', verify=False)
data = response.json()
print(f"History events: {data['count']}")
```

---

### 8. Get Analytics Page

**Endpoint:** `GET /analytics`

**Description:** Serves the Analytics dashboard page with interactive charts.

**Response:**
- **Content-Type:** `text/html`
- **Status Code:** `200 OK`

**Features:**
- KPI cards (total events, spoofers, jammers, active sensors)
- Events by sensor doughnut chart (with percentages)
- Events over time line chart
- Time of day bar chart (UTC)
- Day of week bar chart
- Date range slider (1-30 days)
- Sensor filter dropdown

---

### 9. Get Analytics Data

**Endpoint:** `GET /api/analytics`

**Description:** Retrieves aggregated analytics data for visualizations.

**Query Parameters:**
- `days` (integer, optional): Number of days to analyze (1-30, default: 7)
- `sensor` (string, optional): Filter by specific sensor ID

**Response:**
```json
{
  "days": 7,
  "totals": {
    "total_events": 1250,
    "spoofers": 800,
    "jammers": 450,
    "sensors_active": 3
  },
  "events_by_sensor": [
    {"sensor_id": "hp-bhr.10.4", "spoofers": 300, "jammers": 150, "total": 450}
  ],
  "events_by_hour": [
    {"hour": 0, "spoofers": 20, "jammers": 10},
    {"hour": 1, "spoofers": 15, "jammers": 8}
  ],
  "events_by_weekday": [
    {"weekday": 0, "name": "Sun", "spoofers": 100, "jammers": 50},
    {"weekday": 1, "name": "Mon", "spoofers": 150, "jammers": 80}
  ],
  "events_by_date": [
    {"date": "2026-01-19", "spoofers": 120, "jammers": 60},
    {"date": "2026-01-20", "spoofers": 115, "jammers": 65}
  ]
}
```

**Fields:**
- `days` (integer): Number of days queried
- `totals` (object): Summary statistics
- `events_by_sensor` (array): Event counts per sensor
- `events_by_hour` (array): Event counts by hour of day (0-23, UTC)
- `events_by_weekday` (array): Event counts by day of week (0=Sun, 6=Sat)
- `events_by_date` (array): Daily event counts

**Example (curl):**
```bash
# Default 7 days
curl -k https://localhost:8043/api/analytics

# Last 14 days
curl -k "https://localhost:8043/api/analytics?days=14"

# Filter by sensor
curl -k "https://localhost:8043/api/analytics?days=7&sensor=hp-bhr.10.4"
```

**Example (Python):**
```python
import requests
response = requests.get(
    'https://localhost:8043/api/analytics',
    params={'days': 14, 'sensor': 'hp-bhr.10.4'},
    verify=False
)
data = response.json()
print(f"Total events: {data['totals']['total_events']}")
print(f"Spoofers: {data['totals']['spoofers']}")
print(f"Jammers: {data['totals']['jammers']}")
```

---

## WebSocket API

The WebSocket API provides real-time event streaming and bi-directional communication.

### Connection

**URL:** `wss://localhost:8043/socket.io/`

**Transport:** WebSocket (Socket.IO)

**Protocol:** WSS (WebSocket Secure)

### Client → Server Events

#### 1. `connect`

**Description:** Establish WebSocket connection.

**Payload:** None

**Response:** Server sends multiple initialization messages:
1. `connection_response`
2. `initial_sensors`
3. `initial_batches` (if historical data exists)

**Example (Python):**
```python
import socketio

sio = socketio.Client(ssl_verify=False)

@sio.on('connect')
def on_connect():
    print('Connected to server')

sio.connect('https://localhost:8043', transports=['websocket'])
```

---

#### 2. `disconnect`

**Description:** Disconnect from server.

**Payload:** None

**Example (Python):**
```python
sio.disconnect()
```

---

#### 3. `request_events`

**Description:** Request events from server with optional limit.

**Payload:**
```json
{
  "limit": 100
}
```

**Fields:**
- `limit` (integer, optional): Maximum number of events (default: 100)

**Response:** Server emits `events_response`

**Example (Python):**
```python
sio.emit('request_events', {'limit': 50})
```

---

### Server → Client Events

#### 1. `connection_response`

**Description:** Sent immediately upon connection to confirm status.

**Payload:**
```json
{
  "status": "connected",
  "wss_servers": {
    "UHU-OMN": true,
    "UHU-BHR": true
  }
}
```

**Fields:**
- `status` (string): Connection status (`"connected"`)
- `wss_servers` (object): Current WSS server connection states

**Example (Python):**
```python
@sio.on('connection_response')
def on_connection_response(data):
    print('Connection status:', data['status'])
    print('WSS servers:', data['wss_servers'])
```

---

#### 2. `initial_sensors`

**Description:** Sent on connection with all known sensors from database.

**Payload:**
```json
{
  "sensors": [
    {
      "id": "UHU-OMN",
      "lat": 40.7128,
      "lon": -74.0060,
      "alt": 10.5
    }
  ]
}
```

**Fields:**
- `sensors` (array): List of all sensor objects

**Example (Python):**
```python
@sio.on('initial_sensors')
def on_initial_sensors(data):
    for sensor in data['sensors']:
        print(f"Sensor: {sensor['id']} at ({sensor['lat']}, {sensor['lon']})")
```

---

#### 3. `initial_batches`

**Description:** Sent on connection with last 24 hours of event batches for state restoration.

**Payload:**
```json
{
  "batches": [
    {
      "timestamp": "2025-12-18T10:30:45.123Z",
      "events": [
        {
          "id": "event-123",
          "idSensor": "UHU-OMN",
          "eventType": "spoofer",
          "obTime": "2025-12-18T10:30:45.123Z",
          "latitude": 40.7128,
          "longitude": -74.0060,
          "altitude": 10.5,
          "power": [-45.5, -42.3],
          "frequency": [1575.42, 1227.60]
        }
      ]
    }
  ],
  "readings_count": {
    "event-123": 5
  }
}
```

**Fields:**
- `batches` (array): List of event batch objects
  - `timestamp` (string): Batch timestamp in ISO 8601 format
  - `events` (array): List of event objects
- `readings_count` (object): Map of event IDs to total reading counts

**Example (Python):**
```python
@sio.on('initial_batches')
def on_initial_batches(data):
    print(f"Restoring {len(data['batches'])} batches from database")
    for batch in data['batches']:
        process_batch(batch)
```

---

#### 4. `new_batch`

**Description:** Real-time event batch from WSS servers.

**Payload:**
```json
{
  "timestamp": "2025-12-18T10:30:45.123Z",
  "events": [
    {
      "id": "event-456",
      "idSensor": "UHU-BHR",
      "eventType": "jammer",
      "obTime": "2025-12-18T10:30:45.123Z",
      "latitude": 40.7580,
      "longitude": -73.9855,
      "altitude": 15.2,
      "power": [-52.1],
      "frequency": [1575.42]
    }
  ]
}
```

**Frequency:** Real-time as events are received from WSS servers

**Example (Python):**
```python
@sio.on('new_batch')
def on_new_batch(batch):
    print(f"New batch with {len(batch['events'])} events")
    for event in batch['events']:
        add_event_to_map(event)
```

---

#### 5. `new_sensor`

**Description:** Broadcast when a new sensor is discovered.

**Payload:**
```json
{
  "id": "UHU-NEW",
  "lat": 40.7489,
  "lon": -73.9680,
  "alt": 12.0
}
```

**Example (Python):**
```python
@sio.on('new_sensor')
def on_new_sensor(sensor):
    print(f"New sensor discovered: {sensor['id']}")
    add_sensor_to_map(sensor)
```

---

#### 6. `wss_status`

**Description:** WSS server connection status update.

**Payload:**
```json
{
  "servers": {
    "UHU-OMN": true,
    "UHU-BHR": false
  },
  "connected": false
}
```

**Fields:**
- `servers` (object): Per-server connection status (true/false)
- `connected` (boolean): Overall connection status (all servers connected)

**Frequency:** Sent when any WSS connection state changes

**Example (Python):**
```python
@sio.on('wss_status')
def on_wss_status(status):
    if status['connected']:
        print('All WSS servers connected')
    else:
        print('WSS connection issue:', status['servers'])
```

---

#### 7. `events_response`

**Description:** Response to `request_events` message.

**Payload:**
```json
{
  "events": [
    {
      "id": "event-789",
      "idSensor": "UHU-OMN",
      "eventType": "spoofer",
      "obTime": "2025-12-18T10:30:45.123Z",
      "latitude": 40.7128,
      "longitude": -74.0060,
      "altitude": 10.5,
      "power": [-45.5],
      "frequency": [1575.42]
    }
  ]
}
```

**Example (Python):**
```python
@sio.on('events_response')
def on_events_response(data):
    print(f"Received {len(data['events'])} events")
```

---

## Data Structures

### Event Object

Complete event object structure:

```json
{
  "id": "event-123",
  "idSensor": "UHU-OMN",
  "eventType": "spoofer",
  "obTime": "2025-12-18T10:30:45.123Z",
  "latitude": 40.7128,
  "longitude": -74.0060,
  "altitude": 10.5,
  "power": [-45.5, -42.3, -44.1],
  "frequency": [1575.42, 1227.60, 1176.45]
}
```

**Field Descriptions:**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `id` | string | Yes | Unique event identifier |
| `idSensor` | string | Yes | Sensor ID that detected the event |
| `eventType` | string | Yes | Event type: `"spoofer"`, `"jammer"`, or `"unknown"` |
| `obTime` | string | Yes | Observation time in ISO 8601 format |
| `latitude` | float | Yes | Latitude in decimal degrees (-90 to 90) |
| `longitude` | float | Yes | Longitude in decimal degrees (-180 to 180) |
| `altitude` | float | Yes | Altitude in meters above sea level |
| `power` | array[float] | Yes | Signal power measurements in dBm (negative values) |
| `frequency` | array[float] | Yes | Frequencies in MHz (typically GNSS bands) |

**Event Types:**
- `spoofer`: GNSS spoofing attack detected
- `jammer`: GNSS jamming attack detected
- `unknown`: Unclassified interference event

---

### Sensor Object

```json
{
  "id": "UHU-OMN",
  "lat": 40.7128,
  "lon": -74.0060,
  "alt": 10.5
}
```

**Field Descriptions:**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `id` | string | Yes | Unique sensor identifier |
| `lat` | float | Yes | Sensor latitude in decimal degrees |
| `lon` | float | Yes | Sensor longitude in decimal degrees |
| `alt` | float | Yes | Sensor altitude in meters |

---

### Batch Object

```json
{
  "timestamp": "2025-12-18T10:30:45.123Z",
  "events": [
    { /* event object */ }
  ]
}
```

**Field Descriptions:**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `timestamp` | string | Yes | Batch timestamp in ISO 8601 format |
| `events` | array[Event] | Yes | List of event objects in this batch |

---

## Event Lifecycle and Timeout Configuration

### Event States

Events transition through two states:

1. **Active Events** - Recently received events (< timeout threshold)
   - Displayed in the "Active Events" table
   - Shown on the map with markers and azimuth lines
   - Plotted on the power chart
   - Updated in real-time as new data arrives

2. **Historical Events** - Events that have timed out (> timeout threshold)
   - Moved to the "History" table
   - Removed from map visualization
   - Removed from power chart
   - Persist in database for 30 days
   - Automatically archived after 30 days

### Timeout Configuration

Configure event timeouts in `/app/config.ini`:

```ini
[app]
# Event timeout in minutes
# Events with no new data for this duration are moved to history
timeout_minutes = 3

# Timeout checker interval in seconds
# How often to check if events have timed out (default: 30 seconds)
timeout_check_seconds = 30
```

**Configuration Parameters:**

| Parameter | Default | Description |
|-----------|---------|-------------|
| `timeout_minutes` | 3 | Minutes of inactivity before event moves to history |
| `timeout_check_seconds` | 30 | How often to check for timed out events |

### Timeout Behavior

**Timeline Example:**
```
T+0:00  - Event receives last batch from WSS server
T+3:00  - Event reaches timeout threshold
T+3:00 to T+3:30 - Waiting for next timeout check
T+3:15  - Timeout checker runs (assuming 30s interval)
         - Event moved to History table
         - Map marker removed
         - Chart data removed
```

**Maximum Delay:** `timeout_minutes` + `timeout_check_seconds`
- With defaults: 3 minutes + 30 seconds = 3.5 minutes maximum

**Minimum Delay:** `timeout_minutes`
- If checker runs immediately after timeout: exactly 3 minutes

**Average Delay:** `timeout_minutes` + (`timeout_check_seconds` / 2)
- With defaults: approximately 3 minutes 15 seconds

### State Restoration on Browser Refresh

When a browser connects or refreshes:

1. Server sends `initial_batches` with last 24 hours of data
2. Client processes all batches with `processBatch()`
3. Events are automatically sorted:
   - Age < `timeout_minutes` → Active Events table
   - Age > `timeout_minutes` → History table
4. Timeout checker continues monitoring for state transitions

**Important:** Browser refresh does NOT clear events from database. All events persist and are restored from the database.

### Testing Timeouts

Use the test event generator to verify timeout behavior:

```bash
# Generate active events (0-2 minutes old)
docker exec uhu-viz python /app/test_events.py generate --recent --count 10

# Wait 3-4 minutes and refresh browser
# Events should move from Active to History

# Clean up test events
docker exec uhu-viz python /app/test_events.py cleanup
```

---

## Examples

### Complete WebSocket Client Implementation (Python)

```python
#!/usr/bin/env python3
"""
Complete UHU Visualization WebSocket Client Example

Requirements:
    pip install python-socketio[client] requests urllib3

Usage:
    python client_example.py
"""

import socketio
import requests
import time
import urllib3

# Disable SSL warnings for self-signed certificates
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Create Socket.IO client
sio = socketio.Client(ssl_verify=False)


@sio.on('connect')
def on_connect():
    """Handle connection established"""
    print('✓ Connected to UHU Visualization')


@sio.on('connection_response')
def on_connection_response(data):
    """Handle connection response with server status"""
    print(f"Status: {data['status']}")
    print(f"WSS servers: {data['wss_servers']}")


@sio.on('initial_sensors')
def on_initial_sensors(data):
    """Receive all known sensors on connection"""
    print(f"\n{'='*60}")
    print(f"Loaded {len(data['sensors'])} sensors:")
    for sensor in data['sensors']:
        print(f"  - {sensor['id']}: ({sensor['lat']}, {sensor['lon']}) @ {sensor['alt']}m")
    print(f"{'='*60}\n")


@sio.on('initial_batches')
def on_initial_batches(data):
    """Restore state from last 24 hours"""
    batches = data['batches']
    readings_count = data.get('readings_count', {})

    print(f"\n{'='*60}")
    print(f"Restoring state from database:")
    print(f"  - Batches: {len(batches)}")

    event_count = sum(len(batch['events']) for batch in batches)
    print(f"  - Events: {event_count}")

    # Count by event type
    spoofers = sum(1 for batch in batches for event in batch['events']
                   if event.get('eventType') == 'spoofer')
    jammers = sum(1 for batch in batches for event in batch['events']
                  if event.get('eventType') == 'jammer')

    print(f"  - Spoofers: {spoofers}")
    print(f"  - Jammers: {jammers}")
    print(f"{'='*60}\n")

    # Process each batch
    for batch in batches:
        process_batch(batch, readings_count)


@sio.on('new_batch')
def on_new_batch(batch):
    """Handle real-time event batches"""
    timestamp = batch['timestamp']
    events = batch['events']

    print(f"\n[{timestamp}] New batch: {len(events)} events")
    process_batch(batch)


@sio.on('new_sensor')
def on_new_sensor(sensor):
    """Handle new sensor discovered"""
    print(f"\n🆕 New sensor: {sensor['id']} at ({sensor['lat']}, {sensor['lon']})")


@sio.on('wss_status')
def on_wss_status(status):
    """Handle WSS connection status changes"""
    if status['connected']:
        print('\n✓ All WSS servers connected')
    else:
        print('\n⚠ WSS connection status changed:')
        for name, connected in status['servers'].items():
            status_icon = '✓' if connected else '✗'
            print(f"  {status_icon} {name}: {'Connected' if connected else 'Disconnected'}")


@sio.on('events_response')
def on_events_response(data):
    """Handle response to event request"""
    print(f"\nReceived {len(data['events'])} events from request")
    for event in data['events']:
        display_event(event)


@sio.on('disconnect')
def on_disconnect():
    """Handle disconnection"""
    print('\n✗ Disconnected from server')


def process_batch(batch, readings_count=None):
    """Process a batch of events"""
    for event in batch['events']:
        display_event(event, readings_count)


def display_event(event, readings_count=None):
    """Display event information"""
    event_id = event['id']
    event_type = event['eventType']
    sensor_id = event['idSensor']
    ob_time = event['obTime']
    lat = event['latitude']
    lon = event['longitude']
    power = event.get('power', [])
    freq = event.get('frequency', [])

    # Event type indicator
    type_icon = '🛰️' if event_type == 'spoofer' else '📡' if event_type == 'jammer' else '❓'

    # Get readings count if available
    readings = f" [{readings_count.get(event_id, 1)} readings]" if readings_count else ""

    print(f"  {type_icon} {event_type.upper()}: {event_id}{readings}")
    print(f"     Sensor: {sensor_id}")
    print(f"     Location: ({lat:.4f}, {lon:.4f})")
    print(f"     Time: {ob_time}")
    if power:
        avg_power = sum(power) / len(power)
        print(f"     Power: {avg_power:.1f} dBm (avg of {len(power)} measurements)")
    if freq:
        print(f"     Frequencies: {', '.join(f'{f:.2f} MHz' for f in freq)}")


def request_events(limit=50):
    """Request specific number of events from server"""
    print(f"\n📥 Requesting {limit} events...")
    sio.emit('request_events', {'limit': limit})


def main():
    """Main function"""
    print("UHU Visualization Python Client")
    print("=" * 60)

    try:
        # Connect to server
        print("Connecting to https://localhost:8043...")
        sio.connect('https://localhost:8043', transports=['websocket'])

        # Wait a bit for initial data
        time.sleep(2)

        # Optional: Request additional events
        # request_events(100)

        # Keep connection alive
        print("\nMonitoring events (Ctrl+C to exit)...")
        sio.wait()

    except KeyboardInterrupt:
        print("\n\nShutting down...")
        sio.disconnect()
    except Exception as e:
        print(f"\n❌ Error: {e}")


if __name__ == '__main__':
    main()
```

---

### REST API Examples (Python)

```python
#!/usr/bin/env python3
"""
UHU Visualization REST API Examples

Requirements:
    pip install requests urllib3

Usage:
    python rest_api_examples.py
"""

import requests
import json
import urllib3

# Disable SSL warnings for self-signed certificates
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Base URL
BASE_URL = 'https://localhost:8043'


def get_statistics():
    """Get system statistics"""
    print("\n" + "="*60)
    print("GET /api/stats - System Statistics")
    print("="*60)

    response = requests.get(f'{BASE_URL}/api/stats', verify=False)

    if response.status_code == 200:
        stats = response.json()
        print(f"Total events: {stats['total_events']}")
        print(f"Spoofers: {stats['spoofer_count']}")
        print(f"Jammers: {stats['jammer_count']}")
        print(f"Avg spoofer power: {stats['avg_spoofer_power']} dBm")
        print(f"Avg jammer power: {stats['avg_jammer_power']} dBm")
        print(f"Sensors: {len(stats['sensors'])}")
        print("\nWSS Server Status:")
        for name, connected in stats['wss_servers'].items():
            status = '✓ Connected' if connected else '✗ Disconnected'
            print(f"  {name}: {status}")
    else:
        print(f"Error: {response.status_code}")

    return response.json() if response.status_code == 200 else None


def get_sensors():
    """Get all sensors"""
    print("\n" + "="*60)
    print("GET /api/sensors - All Sensors")
    print("="*60)

    response = requests.get(f'{BASE_URL}/api/sensors', verify=False)

    if response.status_code == 200:
        data = response.json()
        print(f"Total sensors: {data['count']}")
        for sensor in data['sensors']:
            print(f"\n  Sensor: {sensor['id']}")
            print(f"    Location: ({sensor['lat']}, {sensor['lon']})")
            print(f"    Altitude: {sensor['alt']} m")
    else:
        print(f"Error: {response.status_code}")

    return response.json() if response.status_code == 200 else None


def get_events(limit=100):
    """Get recent events"""
    print("\n" + "="*60)
    print(f"GET /api/events?limit={limit} - Recent Events")
    print("="*60)

    response = requests.get(
        f'{BASE_URL}/api/events',
        params={'limit': limit},
        verify=False
    )

    if response.status_code == 200:
        data = response.json()
        print(f"Total events returned: {data['count']}")

        # Group by event type
        spoofers = [e for e in data['events'] if e['eventType'] == 'spoofer']
        jammers = [e for e in data['events'] if e['eventType'] == 'jammer']

        print(f"  Spoofers: {len(spoofers)}")
        print(f"  Jammers: {len(jammers)}")

        # Show first few events
        if data['events']:
            print("\nFirst 3 events:")
            for event in data['events'][:3]:
                print(f"\n  {event['eventType'].upper()}: {event['id']}")
                print(f"    Sensor: {event['idSensor']}")
                print(f"    Time: {event['obTime']}")
                print(f"    Location: ({event['latitude']}, {event['longitude']})")
    else:
        print(f"Error: {response.status_code}")

    return response.json() if response.status_code == 200 else None


def get_event_by_id(event_id):
    """Get specific event by ID"""
    print("\n" + "="*60)
    print(f"GET /api/events/{event_id} - Specific Event")
    print("="*60)

    response = requests.get(f'{BASE_URL}/api/events/{event_id}', verify=False)

    if response.status_code == 200:
        event = response.json()
        print(f"Event ID: {event['id']}")
        print(f"Type: {event['eventType']}")
        print(f"Sensor: {event['idSensor']}")
        print(f"Time: {event['obTime']}")
        print(f"Location: ({event['latitude']}, {event['longitude']}, {event['altitude']}m)")
        print(f"Power: {event.get('power', [])} dBm")
        print(f"Frequencies: {event.get('frequency', [])} MHz")
    elif response.status_code == 404:
        print(f"Event not found: {event_id}")
    else:
        print(f"Error: {response.status_code}")

    return response.json() if response.status_code == 200 else None


def get_history():
    """Get event history"""
    print("\n" + "="*60)
    print("GET /api/history - Event History")
    print("="*60)

    response = requests.get(f'{BASE_URL}/api/history', verify=False)

    if response.status_code == 200:
        data = response.json()
        print(f"History events: {data['count']}")
    else:
        print(f"Error: {response.status_code}")

    return response.json() if response.status_code == 200 else None


def main():
    """Run all REST API examples"""
    print("UHU Visualization REST API Examples")
    print("=" * 60)

    try:
        # Get statistics
        stats = get_statistics()

        # Get all sensors
        sensors = get_sensors()

        # Get recent events
        events = get_events(limit=100)

        # Get specific event (if any events exist)
        if events and events['count'] > 0:
            first_event_id = events['events'][0]['id']
            get_event_by_id(first_event_id)

        # Get history
        history = get_history()

        print("\n" + "="*60)
        print("All API calls completed successfully!")
        print("="*60)

    except requests.exceptions.ConnectionError:
        print("\n❌ Error: Could not connect to server")
        print("Make sure the server is running at https://localhost:8043")
    except Exception as e:
        print(f"\n❌ Error: {e}")


if __name__ == '__main__':
    main()
```

---

### Quick Python Snippets

**Simple REST API Call:**
```python
import requests
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Get statistics
response = requests.get('https://localhost:8043/api/stats', verify=False)
stats = response.json()
print(f"Total events: {stats['total_events']}")
print(f"Spoofers: {stats['spoofer_count']}, Jammers: {stats['jammer_count']}")
```

**Simple WebSocket Monitor:**
```python
import socketio

sio = socketio.Client(ssl_verify=False)

@sio.on('new_batch')
def on_batch(batch):
    for event in batch['events']:
        print(f"{event['eventType']}: {event['id']} from {event['idSensor']}")

sio.connect('https://localhost:8043', transports=['websocket'])
sio.wait()
```

**Event Counter:**
```python
import socketio

event_count = {'spoofer': 0, 'jammer': 0}

sio = socketio.Client(ssl_verify=False)

@sio.on('new_batch')
def on_batch(batch):
    for event in batch['events']:
        event_count[event['eventType']] += 1
        print(f"Spoofers: {event_count['spoofer']}, Jammers: {event_count['jammer']}")

sio.connect('https://localhost:8043', transports=['websocket'])
sio.wait()
```

**Save Events to JSON File:**
```python
import socketio
import json
from datetime import datetime

events = []

sio = socketio.Client(ssl_verify=False)

@sio.on('new_batch')
def on_batch(batch):
    events.extend(batch['events'])
    # Save every 100 events
    if len(events) % 100 == 0:
        filename = f"events_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(filename, 'w') as f:
            json.dump(events, f, indent=2)
        print(f"Saved {len(events)} events to {filename}")

sio.connect('https://localhost:8043', transports=['websocket'])
sio.wait()
```

---

## Data Persistence

### Database Storage

All events are stored in SQLite database with 30-day retention:

- **Database:** `/app/event_data.db`
- **Retention:** 30 days
- **Tables:** `events`, `event_batches`, `sensors`, `event_metadata`
- **Journal Mode:** WAL (Write-Ahead Logging) for concurrent reads

### Automatic Archival

Events older than 30 days are automatically archived:

- **Schedule:** Daily at midnight UTC (via APScheduler)
- **Archive Location:** `/app/archives/events_YYYY-MM-DD.json`
- **Format:** JSON (human-readable)
- **Process:** Archive to file → Delete from database

### Client State Restoration

When clients connect or refresh:

- **Initial Data:** Last 24 hours of events from database
- **Query Time:** <100ms for 10,000+ events (indexed timestamps)
- **Readings Count:** Total readings per event for accurate statistics

---

## Error Handling

### HTTP Status Codes

| Code | Description |
|------|-------------|
| `200 OK` | Request successful |
| `404 Not Found` | Resource not found (event ID, tile, etc.) |
| `500 Internal Server Error` | Server error (database failure, etc.) |

### WebSocket Error Handling

WebSocket connections automatically reconnect on disconnection. The client library (Socket.IO) handles:

- Automatic reconnection with exponential backoff
- Connection state management
- Message queuing during disconnection

### Database Fallback

All database operations have in-memory fallbacks:

1. **Primary:** Query database
2. **Fallback:** Use in-memory data structures
3. **Logging:** Errors logged for debugging

---

## Rate Limiting

Currently, no rate limiting is implemented. For production deployments:

- Consider implementing rate limiting at reverse proxy level
- Monitor WebSocket connection count
- Implement per-client message rate limits if needed

---

## Versioning

**Current Version:** 1.0 (Persistence Release)

**Breaking Changes:** None (backward compatible with previous versions)

**Changelog:**
- **1.0:** Added 30-day persistence, automatic archival, client state restoration
- **0.9:** Initial release with real-time WebSocket streaming

---

## Support

For issues or questions:

1. Check logs: `docker compose logs -f`
2. Verify database: `ls -lh data/event_data.db`
3. Check archives: `docker exec uhu-viz python /app/archiver.py stats`
4. Review documentation: `README.md`, `DOCKER_GUIDE.md`

---

## License

Internal use only
