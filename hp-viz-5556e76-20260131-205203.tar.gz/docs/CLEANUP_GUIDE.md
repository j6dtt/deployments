# Database Cleanup Guide

Quick reference for cleaning up events and sensors from the UHU Visualization database.

## Quick Commands

### Remove Test Events Only
```bash
docker exec uhu-viz python /app/test_events.py cleanup
```
- ✅ Removes test events (created by generator)
- ✅ Preserves real WSS events
- ✅ Preserves sensors
- ✅ Safe for production

### Remove Everything (Test + Real Events + Sensors)
```bash
docker exec uhu-viz python /app/test_events.py cleanup --all
```
- ⚠️ Removes ALL events (test + real)
- ⚠️ Removes ALL sensors
- ⚠️ Complete database reset
- ⚠️ Use with caution

### Dump Before Reset
```bash
# Export database to JSON before wiping
python3 data/db_dump.py dump
```
- ✅ Saves all data to `data/dump/` as JSON
- ✅ Can restore later with `python3 data/db_dump.py restore`

### Remove Database File (Fastest Method)
```bash
docker compose down
rm data/event_data.db
docker compose up -d
```
- ⚠️ Complete reset
- ✅ Fastest method
- ✅ Database auto-recreates
- ✅ Recommended for deployments

## Comparison

| Method | Speed | Removes Test Events | Removes Real Events | Removes Sensors | Best For |
|--------|-------|-------------------|-------------------|----------------|----------|
| `cleanup` | Fast | ✅ Yes | ❌ No | ❌ No | Development |
| `cleanup --all` | Fast | ✅ Yes | ✅ Yes | ✅ Yes | Reset with app running |
| Remove DB file | Fastest | ✅ Yes | ✅ Yes | ✅ Yes | Deployments |

## After Cleanup

**Always refresh your browser (F5)** after cleanup to clear events from browser memory.

## Database Persistence

The database file (`event_data.db`) is:
- ✅ Excluded from git (`.gitignore`)
- ✅ Auto-created on first event
- ✅ Persistent across container restarts
- ✅ Located at `/app/event_data.db` inside container

## Examples

### Development Workflow
```bash
# Generate test events
docker exec uhu-viz python /app/test_events.py generate --recent --count 10

# Test visualization...

# Clean up test events (keep real WSS events)
docker exec uhu-viz python /app/test_events.py cleanup

# Refresh browser
```

### Complete Reset
```bash
# Remove everything
docker exec uhu-viz python /app/test_events.py cleanup --all

# Refresh browser
```

### Fresh Deployment
```bash
# Stop container
docker compose down

# Remove database
docker exec uhu-viz rm /app/event_data.db

# Restart
docker compose up -d

# Database auto-creates on first WSS event
```

## Checking Database Status

```bash
docker exec uhu-viz python /app/test_events.py status
```

Shows:
- Total events (test vs real)
- Total batches
- Total sensors
- Recent batch timestamps
- Event breakdown by type

## Help

```bash
# See all commands
docker exec uhu-viz python /app/test_events.py --help

# See cleanup options
docker exec uhu-viz python /app/test_events.py cleanup --help
```

## Safety Notes

- `cleanup` (without --all) is safe for production - only removes test events
- `cleanup --all` removes real WSS events - use carefully
- Database is excluded from git - safe to delete
- Always refresh browser after cleanup
- Container logs show all WSS events being received (check with `docker compose logs`)
