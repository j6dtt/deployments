# Quick Start Guide

For detailed instructions, see [HARBOR.md](HARBOR.md)

## TL;DR - Get Running in 8 Commands

### Prerequisites:
- Harbor registry access
- kubectl configured for VKS

### On Build Machine:
```bash
# 1. Configure Harbor settings (edit build-harbor.sh)
# Set HARBOR_URL and HARBOR_PROJECT

# 2. Build and push to Harbor
./build-harbor.sh
```

### In VKS Environment:
```bash
# 3. Update image paths in YAML files
# Edit kubernetes/03-llama-deployment.yaml
# Edit kubernetes/06-code-assistant.yaml
# Change image: to your Harbor URL or existing image

# 4. Create imagePullSecret (if Harbor requires auth)
kubectl create secret docker-registry harbor-secret \
  --docker-server=harbor.yourdomain.com \
  --docker-username=YOUR_USER \
  --docker-password=YOUR_PASS

# 5. Create storage
kubectl apply -f kubernetes/01-code-storage.yaml

# 6. Upload your code
kubectl apply -f kubernetes/02-upload-pod.yaml
kubectl wait --for=condition=ready pod/upload-pod --timeout=60s
kubectl cp /apps/myapp upload-pod:/code/
kubectl delete pod upload-pod

# 7. Deploy everything
kubectl apply -f kubernetes/03-llama-deployment.yaml
kubectl apply -f kubernetes/04-llama-service.yaml
kubectl apply -f kubernetes/05-code-assistant-config.yaml
kubectl apply -f kubernetes/06-code-assistant.yaml

# 8. Get access URL
kubectl get svc code-assistant-service
# Open http://<EXTERNAL-IP>:5000 in browser
```

## Architecture

- **llama-deployment**: Runs Ollama with Llama 3.2 model (auto-restart enabled)
- **code-assistant**: Web UI + API server that reads your code
- **code-storage**: PVC containing your application code
- **llama-service**: ClusterIP service (internal only)
- **code-assistant-service**: LoadBalancer (external access)

## Usage

1. Open http://<EXTERNAL-IP>:5000
2. Select files from sidebar (your code files)
3. Ask questions about your code
4. Get AI-powered answers based on your actual codebase

## Troubleshooting

```bash
# Check pods
kubectl get pods

# Check services
kubectl get svc

# View logs
kubectl logs -f deployment/code-assistant
kubectl logs -f deployment/llama-deployment

# Verify code uploaded
kubectl exec deployment/code-assistant -- ls -la /code
```

See [HARBOR.md](HARBOR.md) for detailed instructions.
