# Llama Code Assistant for Air-Gapped Kubernetes

A complete setup for using Llama 3.2 as a code assistant in VMware Kubernetes Service (VKS) air-gapped environments.

## Overview

This system provides:
- Web-based interface to chat with Llama 3.2
- Access to your entire codebase as context
- File browser to select which files to include in conversations
- Fully air-gapped compatible (no internet required)

## Architecture

```
┌─────────────────┐
│  Your Browser   │
└────────┬────────┘
         │
         ▼
┌─────────────────────────┐
│ code-assistant-service  │  (LoadBalancer)
│     Port: 5000          │
└────────┬────────────────┘
         │
         ▼
┌─────────────────────────┐       ┌──────────────────┐
│  code-assistant pod     │◄─────►│  llama-service   │
│  - Web Interface        │       │  Port: 11434     │
│  - File Reader          │       └────────┬─────────┘
│  - API Server           │                │
└────────┬────────────────┘                ▼
         │                        ┌─────────────────┐
         ▼                        │  llama32-pod    │
┌─────────────────────────┐      │  (Ollama)       │
│   code-storage (PVC)    │      │  - Llama 3.2    │
│   - Your Application    │◄─────┤                 │
│   - Code Files          │      └─────────────────┘
└─────────────────────────┘
```

## Prerequisites

- VMware Kubernetes Service (VKS) cluster
- kubectl configured and connected to your cluster
- Docker or podman on your build machine
- Your application code at `/apps/myapp` (or adjust path accordingly)

## Installation Steps

### Part 1: Build the Docker Image (On Build Machine)

1. **Copy all files from this package to your build machine**

2. **Build the Docker image:**
   ```bash
   cd llama-code-assistant
   docker build -t code-assistant:v1 .
   ```

3. **Save the image as a tar file:**
   ```bash
   docker save code-assistant:v1 -o code-assistant-v1.tar
   ```

4. **Transfer to your air-gapped VKS environment:**
   - Copy `code-assistant-v1.tar` to your VKS environment using your approved method

5. **Load the image in your VKS environment:**
   ```bash
   # Method depends on your VKS setup
   # Example for containerd:
   ctr -n k8s.io images import code-assistant-v1.tar
   
   # Or for docker:
   docker load -i code-assistant-v1.tar
   ```

### Part 2: Deploy in Kubernetes

All commands should be run from the `kubernetes/` directory:

```bash
cd kubernetes
```

#### Step 1: Create Storage for Your Code

```bash
kubectl apply -f 01-code-storage.yaml
```

Verify it's bound:
```bash
kubectl get pvc code-storage
# Wait until STATUS shows "Bound"
```

#### Step 2: Create Upload Pod

```bash
kubectl apply -f 02-upload-pod.yaml
```

Wait for it to be ready:
```bash
kubectl wait --for=condition=ready pod/upload-pod --timeout=60s
```

#### Step 3: Upload Your Application Code

**Important:** Adjust the path `/apps/myapp` to match your actual code location.

```bash
kubectl cp /apps/myapp upload-pod:/code/
```

This copies your entire codebase into Kubernetes storage.

Verify the upload:
```bash
kubectl exec upload-pod -- ls -la /code
```

You should see your `myapp` folder listed.

Delete the upload pod (no longer needed):
```bash
kubectl delete pod upload-pod
```

#### Step 4: Deploy Llama Pod

**Note:** This assumes you already have an `ollama32:latest` image with Llama 3.2 loaded.

```bash
kubectl apply -f 03-llama-pod.yaml
```

Wait for it to be ready:
```bash
kubectl wait --for=condition=ready pod/llama32-pod --timeout=120s
```

Verify the model is loaded:
```bash
kubectl exec llama32-pod -- ollama list
```

You should see `llama3.2` in the list.

#### Step 5: Expose Llama API

```bash
kubectl apply -f 04-llama-service.yaml
```

Get the service IP:
```bash
kubectl get svc llama-service
```

Note the EXTERNAL-IP (or wait if it shows `<pending>`).

#### Step 6: Deploy Code Assistant

```bash
kubectl apply -f 05-code-assistant.yaml
```

Wait for deployment:
```bash
kubectl wait --for=condition=available deployment/code-assistant --timeout=120s
```

Get the service IP:
```bash
kubectl get svc code-assistant-service
```

Note the EXTERNAL-IP.

### Part 3: Access the Web Interface

Open your browser and navigate to:

```
http://<EXTERNAL-IP>:5000
```

Replace `<EXTERNAL-IP>` with the IP from `code-assistant-service`.

## Using the Code Assistant

### Interface Layout

**Left Sidebar:**
- Lists all files from your codebase (including subdirectories)
- Click files to select them as context
- Selected files appear as blue tags below the file list

**Main Area:**
- Chat interface
- Type your questions about the code
- View AI responses

### Example Usage

1. **Select relevant files:**
   - Click on `app.py` in the sidebar
   - Click on `models/user.py`
   - Both files now show as selected (blue tags)

2. **Ask a question:**
   - Type: "How does the User model connect to the database?"
   - Press Enter or click Send

3. **The AI will:**
   - Read the contents of `app.py` and `models/user.py`
   - Include them as context in the prompt
   - Provide an answer based on your actual code

### Tips

- **Select only relevant files:** Too many files can overwhelm the context window
- **Use specific questions:** "Explain the authentication flow in auth.py" works better than "Tell me about authentication"
- **Deselect files:** Click the × on the blue tags to remove files from context
- **Subdirectories work automatically:** Files like `api/routes.py` are shown with their full path

## Troubleshooting

### Files not showing in sidebar

```bash
# Check if code was uploaded correctly
kubectl exec -it llama32-pod -- ls -la /code/myapp

# Check code-assistant logs
kubectl logs -f deployment/code-assistant
```

### Can't connect to web interface

```bash
# Check if service has external IP
kubectl get svc code-assistant-service

# Check if pod is running
kubectl get pods -l app=code-assistant

# Check pod logs
kubectl logs -f deployment/code-assistant
```

### Model not responding

```bash
# Check llama-service
kubectl get svc llama-service

# Check if Ollama is running
kubectl exec llama32-pod -- ollama list

# Check llama pod logs
kubectl logs -f llama32-pod
```

### Code Assistant can't reach Ollama

```bash
# Test connectivity from code-assistant to llama-service
kubectl exec deployment/code-assistant -- curl http://llama-service:11434/api/tags
```

## File Structure

```
llama-code-assistant/
├── Dockerfile                    # Docker image definition
├── requirements.txt              # Python dependencies
├── code-assistant-server.py      # Flask API server
├── index.html                    # Web interface
├── kubernetes/                   # Kubernetes manifests
│   ├── 01-code-storage.yaml     # Storage for code
│   ├── 02-upload-pod.yaml       # Temporary pod for uploads
│   ├── 03-llama-pod.yaml        # Llama model pod
│   ├── 04-llama-service.yaml    # Llama API service
│   └── 05-code-assistant.yaml   # Code assistant deployment
└── README.md                     # This file
```

## Customization

### Change Code Path

If your code is not at `/apps/myapp`, you need to:

1. Update the upload command in Step 3:
   ```bash
   kubectl cp /your/actual/path upload-pod:/code/
   ```

2. Update `code-assistant-server.py`:
   ```python
   CODE_PATH = "/code/yourfoldername"  # Change this line
   ```

3. Rebuild the Docker image

### Adjust Storage Size

Edit `01-code-storage.yaml`:
```yaml
resources:
  requests:
    storage: 10Gi  # Change from 5Gi to whatever you need
```

### Use Different Model

If using a different Ollama model:

1. Update `code-assistant-server.py`:
   ```python
   "model": "your-model-name",  # Change from llama3.2
   ```

2. Rebuild the Docker image

### Change Ports

To use different ports, update:
- `05-code-assistant.yaml`: Change `containerPort` and `port`
- Access URL will change accordingly

## Uninstall

To remove everything:

```bash
kubectl delete -f kubernetes/05-code-assistant.yaml
kubectl delete -f kubernetes/04-llama-service.yaml
kubectl delete -f kubernetes/03-llama-pod.yaml
kubectl delete pvc code-storage
```

## Security Notes

- This setup runs in an air-gapped environment with no external internet access
- Code files are stored in Kubernetes persistent volumes
- The web interface has no authentication (add nginx/auth proxy if needed)
- All communication is HTTP (add TLS termination at LoadBalancer if needed)

## Support

For issues or questions:
1. Check the Troubleshooting section above
2. Review pod logs: `kubectl logs -f <pod-name>`
3. Verify network connectivity between services

## License

This is a custom setup guide. Individual components (Ollama, Flask, etc.) have their own licenses.
