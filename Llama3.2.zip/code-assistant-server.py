from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import os
import requests

app = Flask(__name__)
CORS(app)

CODE_PATH = "/code/myapp"
OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434/api/generate")

@app.route('/api/files', methods=['GET'])
def list_files():
    """List all files in the code directory"""
    files = []
    for root, dirs, filenames in os.walk(CODE_PATH):
        for filename in filenames:
            filepath = os.path.join(root, filename)
            rel_path = os.path.relpath(filepath, CODE_PATH)
            files.append(rel_path)
    return jsonify({"files": sorted(files)})

@app.route('/api/file/<path:filepath>', methods=['GET'])
def get_file(filepath):
    """Get contents of a specific file"""
    full_path = os.path.join(CODE_PATH, filepath)
    if not os.path.exists(full_path):
        return jsonify({"error": "File not found"}), 404
    
    try:
        with open(full_path, 'r') as f:
            content = f.read()
        return jsonify({"content": content})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/chat', methods=['POST'])
def chat():
    """Chat with the model with optional file context"""
    data = request.json
    prompt = data.get('prompt', '')
    files = data.get('files', [])
    
    # Build context from files
    context = ""
    for filepath in files:
        full_path = os.path.join(CODE_PATH, filepath)
        if os.path.exists(full_path):
            try:
                with open(full_path, 'r') as f:
                    content = f.read()
                context += f"\n\n=== File: {filepath} ===\n{content}\n"
            except:
                pass
    
    # Combine context and prompt
    full_prompt = f"{context}\n\nQuestion: {prompt}"
    
    # Send to Ollama
    response = requests.post(OLLAMA_URL, json={
        "model": "llama3.2",
        "prompt": full_prompt,
        "stream": False
    })
    
    if response.status_code == 200:
        return jsonify(response.json())
    else:
        return jsonify({"error": "Ollama error"}), 500

@app.route('/')
def index():
    return send_from_directory('.', 'index.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
