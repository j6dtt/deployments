# Harbor Registry Instructions

This guide is specifically for VMware VKS environments using Harbor registry.

## Prerequisites

- Access to Harbor registry
- Harbor credentials (username/password or robot account)
- Harbor project created (e.g., `llama-assistant`)

## Step 1: Build and Push to Harbor

### On Your Build Machine (with Internet and Docker):

```bash
# Set your Harbor registry details
HARBOR_URL="harbor.yourdomain.com"           # Replace with your Harbor URL
HARBOR_PROJECT="llama-assistant"              # Replace with your project name
IMAGE_NAME="code-assistant"
IMAGE_TAG="v1"

# Full image path
FULL_IMAGE="${HARBOR_URL}/${HARBOR_PROJECT}/${IMAGE_NAME}:${IMAGE_TAG}"

# Build the image
docker build -t ${IMAGE_NAME}:${IMAGE_TAG} .

# Tag for Harbor
docker tag ${IMAGE_NAME}:${IMAGE_TAG} ${FULL_IMAGE}

# Login to Harbor
docker login ${HARBOR_URL}
# Enter your Harbor username and password

# Push to Harbor
docker push ${FULL_IMAGE}
```

### Verify in Harbor UI:

1. Login to Harbor web interface
2. Navigate to your project (e.g., `llama-assistant`)
3. Verify `code-assistant:v1` appears in the repository list

## Step 2: Update Kubernetes YAML Files

You need to update the image paths in two files:

### File 1: kubernetes/03-llama-deployment.yaml

**Before:**
```yaml
spec:
  template:
    spec:
      containers:
      - name: llama
        image: ollama32:latest
```

**After:**
```yaml
spec:
  template:
    spec:
      containers:
      - name: llama
        image: harbor.yourdomain.com/your-project/ollama32:latest
```

### File 2: kubernetes/06-code-assistant.yaml

**Before:**
```yaml
spec:
  template:
    spec:
      containers:
      - name: code-assistant
        image: code-assistant:v1
```

**After:**
```yaml
spec:
  template:
    spec:
      containers:
      - name: code-assistant
        image: harbor.yourdomain.com/llama-assistant/code-assistant:v1
```

## Step 3: Create Image Pull Secret (If Harbor Requires Authentication)

If your Harbor requires authentication to pull images:

```bash
# Create secret for Harbor credentials
kubectl create secret docker-registry harbor-secret \
  --docker-server=harbor.yourdomain.com \
  --docker-username=YOUR_USERNAME \
  --docker-password=YOUR_PASSWORD \
  --docker-email=YOUR_EMAIL
```

Then add to **both** pod specs:

**In 03-llama-deployment.yaml:**
```yaml
spec:
  template:
    spec:
      imagePullSecrets:
      - name: harbor-secret
      containers:
      - name: llama
        image: harbor.yourdomain.com/your-project/ollama32:latest
```

**In 06-code-assistant.yaml:**
```yaml
spec:
  template:
    spec:
      imagePullSecrets:
      - name: harbor-secret
      containers:
      - name: code-assistant
        image: harbor.yourdomain.com/llama-assistant/code-assistant:v1
```

## Step 4: Deploy to VKS

Now deploy normally:

```bash
cd kubernetes

# Deploy in order
kubectl apply -f 01-code-storage.yaml
kubectl apply -f 02-upload-pod.yaml
# Wait and upload code
kubectl apply -f 03-llama-deployment.yaml
kubectl apply -f 04-llama-service.yaml
kubectl apply -f 05-code-assistant-config.yaml
kubectl apply -f 06-code-assistant.yaml
```

## Complete Example with Your Values

Let's say your Harbor setup is:
- Harbor URL: `harbor.mycompany.local`
- Project: `ai-tools`
- Username: `admin`

### Build and Push:

```bash
# Build
docker build -t code-assistant:v1 .

# Tag
docker tag code-assistant:v1 harbor.mycompany.local/ai-tools/code-assistant:v1

# Login and Push
docker login harbor.mycompany.local
docker push harbor.mycompany.local/ai-tools/code-assistant:v1
```

### Create Secret:

```bash
kubectl create secret docker-registry harbor-secret \
  --docker-server=harbor.mycompany.local \
  --docker-username=admin \
  --docker-password=YourPassword123
```

### Update 06-code-assistant.yaml:

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: code-assistant
spec:
  replicas: 1
  selector:
    matchLabels:
      app: code-assistant
  template:
    metadata:
      labels:
        app: code-assistant
    spec:
      imagePullSecrets:
      - name: harbor-secret
      containers:
      - name: code-assistant
        image: harbor.mycompany.local/ai-tools/code-assistant:v1
        ports:
        - containerPort: 5000
        env:
        - name: OLLAMA_URL
          value: "http://llama-service:11434/api/generate"
        volumeMounts:
        - name: code-volume
          mountPath: /code
      volumes:
      - name: code-volume
        persistentVolumeClaim:
          claimName: code-storage
---
apiVersion: v1
kind: Service
metadata:
  name: code-assistant-service
spec:
  selector:
    app: code-assistant
  ports:
    - port: 5000
      targetPort: 5000
  type: LoadBalancer
```

## Automated Build Script for Harbor

Create `build-and-push-harbor.sh`:

```bash
#!/bin/bash

# Configuration - UPDATE THESE VALUES
HARBOR_URL="harbor.yourdomain.com"
HARBOR_PROJECT="llama-assistant"
IMAGE_NAME="code-assistant"
IMAGE_TAG="v1"

# Build
echo "Building image..."
docker build -t ${IMAGE_NAME}:${IMAGE_TAG} .

# Tag
FULL_IMAGE="${HARBOR_URL}/${HARBOR_PROJECT}/${IMAGE_NAME}:${IMAGE_TAG}"
echo "Tagging as ${FULL_IMAGE}..."
docker tag ${IMAGE_NAME}:${IMAGE_TAG} ${FULL_IMAGE}

# Login
echo "Logging in to Harbor..."
docker login ${HARBOR_URL}

# Push
echo "Pushing to Harbor..."
docker push ${FULL_IMAGE}

echo ""
echo "✓ Image pushed successfully!"
echo ""
echo "Image: ${FULL_IMAGE}"
echo ""
echo "Next steps:"
echo "1. Update kubernetes/05-code-assistant.yaml with this image path"
echo "2. Create imagePullSecret if needed"
echo "3. Deploy with: kubectl apply -f kubernetes/"
```

Make it executable:
```bash
chmod +x build-and-push-harbor.sh
```

## Troubleshooting

### Image pull errors:

```bash
# Check if secret is created
kubectl get secrets harbor-secret

# Check if pod can pull image
kubectl describe pod <pod-name>
# Look for "ImagePullBackOff" or "ErrImagePull"
```

### Can't push to Harbor:

```bash
# Verify Harbor is accessible
curl -k https://harbor.yourdomain.com

# Verify credentials
docker login harbor.yourdomain.com

# Check project exists and you have push access
```

### Wrong image path:

```bash
# Check current image in deployment
kubectl get deployment code-assistant -o yaml | grep image:

# Update if wrong
kubectl set image deployment/code-assistant \
  code-assistant=harbor.yourdomain.com/project/code-assistant:v1
```

## Summary

**The key difference with Harbor:**

1. ❌ No need for: `docker save/load` or `ctr import`
2. ✅ Instead: `docker push` to Harbor
3. ✅ Update YAML files with full Harbor image paths
4. ✅ Create `imagePullSecrets` if Harbor requires auth

This is actually **cleaner** than tar file transfers!
