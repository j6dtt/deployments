# Installation Checklist

Use this checklist to track your installation progress.

## Phase 1: Build (On Internet-Connected Machine)

- [ ] Extract package files
- [ ] Review README.md
- [ ] Run `./build.sh` or manually build Docker image
- [ ] Verify `code-assistant-v1.tar` file created
- [ ] Transfer tar file to air-gapped environment

## Phase 2: Prepare VKS Environment

- [ ] Load Docker image into VKS
  ```bash
  docker load -i code-assistant-v1.tar
  # OR
  ctr -n k8s.io images import code-assistant-v1.tar
  ```
- [ ] Verify image loaded
  ```bash
  docker images | grep code-assistant
  # Should show: code-assistant   v1   ...
  ```
- [ ] Confirm ollama32:latest image with llama3.2 exists
  ```bash
  # Check if you can create a test pod with this image
  ```

## Phase 3: Deploy Storage and Upload Code

- [ ] Apply code storage PVC
  ```bash
  kubectl apply -f kubernetes/01-code-storage.yaml
  ```
- [ ] Verify PVC is Bound
  ```bash
  kubectl get pvc code-storage
  # STATUS should show "Bound"
  ```
- [ ] Create upload pod
  ```bash
  kubectl apply -f kubernetes/02-upload-pod.yaml
  kubectl wait --for=condition=ready pod/upload-pod --timeout=60s
  ```
- [ ] Upload your application code
  ```bash
  kubectl cp /apps/myapp upload-pod:/code/
  ```
- [ ] Verify code uploaded
  ```bash
  kubectl exec upload-pod -- ls -la /code
  # Should see your myapp folder
  ```
- [ ] Delete upload pod
  ```bash
  kubectl delete pod upload-pod
  ```

## Phase 4: Deploy Llama

- [ ] Apply llama deployment
  ```bash
  kubectl apply -f kubernetes/03-llama-deployment.yaml
  ```
- [ ] Wait for deployment to be ready
  ```bash
  kubectl wait --for=condition=available deployment/llama-deployment --timeout=120s
  ```
- [ ] Verify model is loaded
  ```bash
  kubectl exec deployment/llama-deployment -- ollama list
  # Should show llama3.2
  ```
- [ ] Apply llama service
  ```bash
  kubectl apply -f kubernetes/04-llama-service.yaml
  ```
- [ ] Get llama service IP
  ```bash
  kubectl get svc llama-service
  # Note the EXTERNAL-IP: ___________________
  ```

## Phase 5: Deploy Code Assistant

- [ ] Apply code-assistant ConfigMap
  ```bash
  kubectl apply -f kubernetes/05-code-assistant-config.yaml
  ```
- [ ] Apply code-assistant deployment
  ```bash
  kubectl apply -f kubernetes/06-code-assistant.yaml
  ```
- [ ] Wait for deployment ready
  ```bash
  kubectl wait --for=condition=available deployment/code-assistant --timeout=120s
  ```
- [ ] Get code-assistant service IP
  ```bash
  kubectl get svc code-assistant-service
  # Note the EXTERNAL-IP: ___________________
  ```

## Phase 6: Test and Verify

- [ ] Open web interface
  ```
  URL: http://<EXTERNAL-IP>:5000
  ```
- [ ] Verify file list loads in sidebar
  - [ ] Files from main directory visible
  - [ ] Files from subdirectories visible
  - [ ] Correct file paths shown
- [ ] Test file selection
  - [ ] Click a file - it becomes blue/selected
  - [ ] File appears in "Selected Context" section
  - [ ] Click X to remove - file deselects
- [ ] Test chat functionality
  - [ ] Select 1-2 relevant files
  - [ ] Ask a simple question about your code
  - [ ] Verify response is received
  - [ ] Response references your actual code
- [ ] Test multiple queries
  - [ ] Ask different questions
  - [ ] Change selected files between queries
  - [ ] Verify responses are contextually appropriate

## Phase 7: Troubleshooting (If Needed)

If something doesn't work, check:

- [ ] All pods are running
  ```bash
  kubectl get pods
  # llama-deployment-xxx: Running
  # code-assistant-xxx: Running
  ```
- [ ] All services have external IPs
  ```bash
  kubectl get svc
  # llama-service: Has EXTERNAL-IP
  # code-assistant-service: Has EXTERNAL-IP
  ```
- [ ] Check code-assistant logs
  ```bash
  kubectl logs -f deployment/code-assistant
  ```
- [ ] Check llama logs
  ```bash
  kubectl logs -f deployment/llama-deployment
  ```
- [ ] Test connectivity between pods
  ```bash
  kubectl exec deployment/code-assistant -- curl http://llama-service:11434/api/tags
  # Should return JSON with model info
  ```

## Success Criteria

Installation is complete when:

✓ Web interface opens and loads
✓ File list shows all your code files
✓ Can select files and they appear as tags
✓ Can ask questions and receive relevant answers
✓ Answers reference your actual code content
✓ System responds in reasonable time (<30 seconds per query)

## Common Issues and Fixes

### Files not showing
```bash
# Verify code was uploaded
kubectl exec deployment/code-assistant -- ls -la /code/myapp
```

### Can't connect to web interface
```bash
# Check service status
kubectl get svc code-assistant-service
# If EXTERNAL-IP is <pending>, wait or check LoadBalancer config
```

### Model not responding
```bash
# Check if Ollama is running
kubectl exec deployment/llama-deployment -- ollama list
# Should show llama3.2
```

### "Thinking..." never completes
```bash
# Check if code-assistant can reach Ollama
kubectl exec deployment/code-assistant -- curl http://llama-service:11434/api/tags
```

## Notes

- Installation typically takes 30-60 minutes
- Most time is spent on image building and code upload
- Keep this checklist for future reference
- Mark dates when you complete major phases:
  - Build completed: __________
  - Deployed to VKS: __________
  - First successful query: __________

---

**Pro Tips:**

1. Test with a small codebase first (a few files)
2. Start with simple questions to verify basic functionality
3. Keep pod logs open during first use to catch issues early
4. Bookmark the web interface URL for easy access

Good luck! 🚀
