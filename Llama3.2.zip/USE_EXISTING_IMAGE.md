# Using Your Existing Python Image

If you already have a Python image with Flask, requests, and gunicorn installed, you can use it directly without rebuilding!

## Option 1: Use Your Existing Image (Fastest)

### Step 1: Update the Deployment YAML

Edit `kubernetes/05-code-assistant.yaml` to use your existing image and copy files at runtime:

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: code-assistant
spec:
  replicas: 1
  selector:
    matchLabels:
      app: code-assistant
  template:
    metadata:
      labels:
        app: code-assistant
    spec:
      initContainers:
      - name: setup-files
        image: YOUR_EXISTING_IMAGE:TAG  # Your image with Flask, requests, gunicorn
        command: ["/bin/sh", "-c"]
        args:
          - |
            mkdir -p /app
            cat > /app/code-assistant-server.py << 'EOF'
            from flask import Flask, request, jsonify, send_from_directory
            import os
            import requests

            app = Flask(__name__)

            CODE_PATH = "/code/myapp"
            OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434/api/generate")

            @app.route('/api/files', methods=['GET'])
            def list_files():
                """List all files in the code directory"""
                files = []
                for root, dirs, filenames in os.walk(CODE_PATH):
                    for filename in filenames:
                        filepath = os.path.join(root, filename)
                        rel_path = os.path.relpath(filepath, CODE_PATH)
                        files.append(rel_path)
                return jsonify({"files": sorted(files)})

            @app.route('/api/file/<path:filepath>', methods=['GET'])
            def get_file(filepath):
                """Get contents of a specific file"""
                full_path = os.path.join(CODE_PATH, filepath)
                if not os.path.exists(full_path):
                    return jsonify({"error": "File not found"}), 404
                try:
                    with open(full_path, 'r') as f:
                        content = f.read()
                    return jsonify({"content": content})
                except Exception as e:
                    return jsonify({"error": str(e)}), 500

            @app.route('/api/chat', methods=['POST'])
            def chat():
                """Chat with the model with optional file context"""
                data = request.json
                prompt = data.get('prompt', '')
                files = data.get('files', [])
                
                context = ""
                for filepath in files:
                    full_path = os.path.join(CODE_PATH, filepath)
                    if os.path.exists(full_path):
                        try:
                            with open(full_path, 'r') as f:
                                content = f.read()
                            context += f"\n\n=== File: {filepath} ===\n{content}\n"
                        except:
                            pass
                
                full_prompt = f"{context}\n\nQuestion: {prompt}"
                
                response = requests.post(OLLAMA_URL, json={
                    "model": "llama3.2",
                    "prompt": full_prompt,
                    "stream": False
                })
                
                if response.status_code == 200:
                    return jsonify(response.json())
                else:
                    return jsonify({"error": "Ollama error"}), 500

            @app.route('/')
            def index():
                return send_from_directory('.', 'index.html')

            if __name__ == '__main__':
                app.run(host='0.0.0.0', port=5000, debug=True)
            EOF

            cat > /app/index.html << 'EOF'
            [COPY ENTIRE index.html CONTENT HERE]
            EOF
        volumeMounts:
        - name: app-files
          mountPath: /app
      containers:
      - name: code-assistant
        image: YOUR_EXISTING_IMAGE:TAG  # Same image
        workingDir: /app
        command: ["gunicorn"]
        args:
          - "--bind"
          - "0.0.0.0:5000"
          - "--workers"
          - "2"
          - "--timeout"
          - "120"
          - "code-assistant-server:app"
        ports:
        - containerPort: 5000
        env:
        - name: OLLAMA_URL
          value: "http://llama-service:11434/api/generate"
        volumeMounts:
        - name: code-volume
          mountPath: /code
        - name: app-files
          mountPath: /app
      volumes:
      - name: code-volume
        persistentVolumeClaim:
          claimName: code-storage
      - name: app-files
        emptyDir: {}
---
apiVersion: v1
kind: Service
metadata:
  name: code-assistant-service
spec:
  selector:
    app: code-assistant
  ports:
    - port: 5000
      targetPort: 5000
  type: LoadBalancer
```

**Note:** This approach uses an initContainer to create the files at startup. Replace `YOUR_EXISTING_IMAGE:TAG` with your actual image.

## Option 2: Use ConfigMap (Cleaner)

### Step 1: Create ConfigMap with Application Files

Create `kubernetes/06-code-assistant-config.yaml`:

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: code-assistant-files
data:
  code-assistant-server.py: |
    from flask import Flask, request, jsonify, send_from_directory
    import os
    import requests

    app = Flask(__name__)

    CODE_PATH = "/code/myapp"
    OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434/api/generate")

    @app.route('/api/files', methods=['GET'])
    def list_files():
        files = []
        for root, dirs, filenames in os.walk(CODE_PATH):
            for filename in filenames:
                filepath = os.path.join(root, filename)
                rel_path = os.path.relpath(filepath, CODE_PATH)
                files.append(rel_path)
        return jsonify({"files": sorted(files)})

    @app.route('/api/file/<path:filepath>', methods=['GET'])
    def get_file(filepath):
        full_path = os.path.join(CODE_PATH, filepath)
        if not os.path.exists(full_path):
            return jsonify({"error": "File not found"}), 404
        try:
            with open(full_path, 'r') as f:
                content = f.read()
            return jsonify({"content": content})
        except Exception as e:
            return jsonify({"error": str(e)}), 500

    @app.route('/api/chat', methods=['POST'])
    def chat():
        data = request.json
        prompt = data.get('prompt', '')
        files = data.get('files', [])
        
        context = ""
        for filepath in files:
            full_path = os.path.join(CODE_PATH, filepath)
            if os.path.exists(full_path):
                try:
                    with open(full_path, 'r') as f:
                        content = f.read()
                    context += f"\n\n=== File: {filepath} ===\n{content}\n"
                except:
                    pass
        
        full_prompt = f"{context}\n\nQuestion: {prompt}"
        
        response = requests.post(OLLAMA_URL, json={
            "model": "llama3.2",
            "prompt": full_prompt,
            "stream": False
        })
        
        if response.status_code == 200:
            return jsonify(response.json())
        else:
            return jsonify({"error": "Ollama error"}), 500

    @app.route('/')
    def index():
        return send_from_directory('.', 'index.html')

  index.html: |
    # [COPY ENTIRE index.html CONTENT HERE - see the actual index.html file]
```

### Step 2: Update Deployment to Use ConfigMap

Edit `kubernetes/05-code-assistant.yaml`:

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: code-assistant
spec:
  replicas: 1
  selector:
    matchLabels:
      app: code-assistant
  template:
    metadata:
      labels:
        app: code-assistant
    spec:
      containers:
      - name: code-assistant
        image: YOUR_EXISTING_IMAGE:TAG
        workingDir: /app
        command: ["gunicorn"]
        args:
          - "--bind"
          - "0.0.0.0:5000"
          - "--workers"
          - "2"
          - "--timeout"
          - "120"
          - "code-assistant-server:app"
        ports:
        - containerPort: 5000
        env:
        - name: OLLAMA_URL
          value: "http://llama-service:11434/api/generate"
        volumeMounts:
        - name: code-volume
          mountPath: /code
        - name: app-files
          mountPath: /app
      volumes:
      - name: code-volume
        persistentVolumeClaim:
          claimName: code-storage
      - name: app-files
        configMap:
          name: code-assistant-files
---
apiVersion: v1
kind: Service
metadata:
  name: code-assistant-service
spec:
  selector:
    app: code-assistant
  ports:
    - port: 5000
      targetPort: 5000
  type: LoadBalancer
```

### Step 3: Deploy

```bash
# Create ConfigMap
kubectl apply -f kubernetes/06-code-assistant-config.yaml

# Deploy code-assistant
kubectl apply -f kubernetes/05-code-assistant.yaml
```

## Option 3: Manual File Copy (Simplest for Testing)

```bash
# 1. Deploy with your existing image
kubectl apply -f kubernetes/05-code-assistant.yaml

# 2. Wait for pod to start
kubectl wait --for=condition=ready pod -l app=code-assistant

# 3. Copy files into the running pod
kubectl cp code-assistant-server.py deployment/code-assistant:/app/
kubectl cp index.html deployment/code-assistant:/app/

# 4. Restart to apply changes
kubectl rollout restart deployment/code-assistant
```

## Which Option to Use?

**Option 1 (InitContainer):** 
- ✅ Self-contained in one YAML
- ❌ Large YAML file

**Option 2 (ConfigMap):** 
- ✅ Clean separation
- ✅ Easy to update files without redeploying
- ✅ **RECOMMENDED**

**Option 3 (Manual Copy):**
- ✅ Quick testing
- ❌ Not persistent (lost on pod restart)

## Verify Your Image Has Required Packages

```bash
# Test your image
kubectl run test-python --image=YOUR_IMAGE:TAG --rm -it -- /bin/bash

# Inside the container, test:
python3 -c "import flask; import requests; print('Flask and requests OK')"
gunicorn --version

# If all pass, you're good to go!
```

## Summary

You don't need to build a new image! Just use ConfigMap to inject the Python and HTML files into your existing image.

**Quick start with your existing image:**
1. Create the ConfigMap (06-code-assistant-config.yaml)
2. Update deployment to use your image + ConfigMap
3. Deploy!

No image building required! 🎉
