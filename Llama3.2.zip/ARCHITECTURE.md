# System Architecture

## High-Level Overview

```
┌─────────────────────────────────────────────────────────────┐
│                     Your Local Machine                       │
│                                                              │
│  ┌────────────────┐         ┌─────────────────────┐        │
│  │  Web Browser   │────────►│  /apps/myapp        │        │
│  │                │         │  (Your Code)        │        │
│  └────────┬───────┘         └─────────────────────┘        │
│           │                                                  │
└───────────┼──────────────────────────────────────────────────┘
            │
            │ http://<EXTERNAL-IP>:5000
            │
            ▼
┌─────────────────────────────────────────────────────────────┐
│              VMware Kubernetes Service (VKS)                 │
│                    Air-Gapped Environment                    │
│                                                              │
│  ┌────────────────────────────────────────────────────┐    │
│  │         code-assistant-service (LoadBalancer)       │    │
│  │                  Port: 5000                         │    │
│  └──────────────────────┬─────────────────────────────┘    │
│                         │                                    │
│                         ▼                                    │
│  ┌────────────────────────────────────────────────────┐    │
│  │          code-assistant Deployment                  │    │
│  │  ┌──────────────────────────────────────────────┐  │    │
│  │  │  Pod: code-assistant                         │  │    │
│  │  │  ┌────────────────────────────────────────┐  │  │    │
│  │  │  │  Container: code-assistant:v1          │  │  │    │
│  │  │  │  - Flask API Server (Port 5000)        │  │  │    │
│  │  │  │  - index.html (Web UI)                 │  │  │    │
│  │  │  │  - File Reader (/code/myapp access)    │  │  │    │
│  │  │  │                                         │  │  │    │
│  │  │  │  Environment:                          │  │  │    │
│  │  │  │  OLLAMA_URL=http://llama-service:11434 │  │  │    │
│  │  │  └────────────────────────────────────────┘  │  │    │
│  │  │                   │                           │  │    │
│  │  │                   │ Mounts                    │  │    │
│  │  │                   ▼                           │  │    │
│  │  │         /code (from code-storage PVC)        │  │    │
│  │  └──────────────────────────────────────────────┘  │    │
│  └─────────────────────┬──────────────────────────────┘    │
│                        │                                    │
│                        │ HTTP Request to Ollama             │
│                        ▼                                    │
│  ┌────────────────────────────────────────────────────┐    │
│  │         llama-service (LoadBalancer)                │    │
│  │              Port: 11434                            │    │
│  └──────────────────────┬─────────────────────────────┘    │
│                         │                                   │
│                         ▼                                   │
│  ┌────────────────────────────────────────────────────┐    │
│  │  Pod: llama-deployment-xxxxxxxxx-xxxxx             │    │
│  │  ┌──────────────────────────────────────────────┐  │    │
│  │  │  Container: ollama32:latest                  │  │    │
│  │  │  - Ollama Server (Port 11434)                │  │    │
│  │  │  - Llama 3.2 Model                           │  │    │
│  │  │                                               │  │    │
│  │  │  Labels: app=llama                           │  │    │
│  │  └──────────────────────────────────────────────┘  │    │
│  │                   │                                 │    │
│  │                   │ Mounts                          │    │
│  │                   ▼                                 │    │
│  │         /code (from code-storage PVC)              │    │
│  └────────────────────────────────────────────────────┘    │
│                                                             │
│  ┌────────────────────────────────────────────────────┐    │
│  │     Persistent Volume Claim: code-storage           │    │
│  │              Size: 5Gi                              │    │
│  │  ┌──────────────────────────────────────────────┐  │    │
│  │  │  /code/                                      │  │    │
│  │  │    └── myapp/                                │  │    │
│  │  │        ├── app.py                            │  │    │
│  │  │        ├── config.py                         │  │    │
│  │  │        ├── models/                           │  │    │
│  │  │        │   ├── user.py                       │  │    │
│  │  │        │   └── database.py                   │  │    │
│  │  │        └── api/                              │  │    │
│  │  │            ├── routes.py                     │  │    │
│  │  │            └── auth.py                       │  │    │
│  │  └──────────────────────────────────────────────┘  │    │
│  └────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
```

## Request Flow

### 1. User Opens Web Interface
```
Browser → code-assistant-service → code-assistant pod → Returns index.html
```

### 2. Loading File List
```
Browser → GET /api/files
    ↓
code-assistant reads /code/myapp directory
    ↓
Returns JSON list of all files (including subdirectories)
    ↓
Browser displays files in sidebar
```

### 3. Asking a Question with Selected Files
```
User: Selects app.py and models/user.py
      Types: "How does authentication work?"
      Clicks Send
    ↓
Browser → POST /api/chat
    {
      "prompt": "How does authentication work?",
      "files": ["app.py", "models/user.py"]
    }
    ↓
code-assistant pod:
    1. Reads /code/myapp/app.py
    2. Reads /code/myapp/models/user.py
    3. Combines into context:
       
       === File: app.py ===
       [contents of app.py]
       
       === File: models/user.py ===
       [contents of user.py]
       
       Question: How does authentication work?
    ↓
POST http://llama-service:11434/api/generate
    {
      "model": "llama3.2",
      "prompt": "[combined context]",
      "stream": false
    }
    ↓
llama-service → llama-deployment pod (Ollama)
    ↓
Ollama processes with Llama 3.2
    ↓
Returns response
    ↓
code-assistant → Browser
    ↓
User sees AI answer based on their actual code
```

## Key Design Decisions

### Why Two Deployments?

**llama-deployment (Ollama)**
- Minimal dependencies
- Just runs the AI model
- No need to modify the ollama image
- Air-gapped friendly
- Auto-restart on failure

**code-assistant deployment**
- Handles complex operations (file reading, web server)
- Contains all Python dependencies (Flask, flask-cors, requests)
- Can be updated independently
- Custom built for this use case
- Horizontal scaling capable

### Why Shared Storage?

**code-storage PVC**
- Single source of truth for code
- Both pods can access the same files
- Easy to update code (just upload once)
- Persistent across pod restarts

### Why LoadBalancer?

**External Access**
- Makes services accessible from outside cluster
- No port-forwarding needed
- Production-ready setup
- VMware VKS provides LoadBalancer IP automatically

## Network Flow

```
Port 5000 (Web UI)
Browser ──► code-assistant-service ──► code-assistant deployment
                                           │
                                           │ Port 11434 (Ollama API)
                                           ▼
                               llama-service ──► llama-deployment
```

## Security Considerations

1. **No External Internet**: Fully air-gapped
2. **No Authentication**: Web UI is open (add reverse proxy if needed)
3. **HTTP Only**: No TLS (add nginx/Istio for HTTPS)
4. **Code Access**: Both pods can read your code (by design)
5. **Service-to-Service**: Uses Kubernetes DNS (llama-service)

## Scaling Considerations

- **code-assistant**: Can scale horizontally (increase replicas)
- **llama-deployment**: Single replica recommended (stateful model)
- **code-storage**: ReadWriteOnce (single mount point)

For better performance:
- Use GPU nodes for llama-deployment
- Increase PVC size for larger codebases
- Add resource limits to deployments
