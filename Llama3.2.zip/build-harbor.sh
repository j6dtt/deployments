#!/bin/bash

# Harbor Build and Push Script for Code Assistant
# This script builds the Docker image and pushes it to Harbor registry

set -e  # Exit on error

echo "================================================"
echo "  Code Assistant - Harbor Build & Push"
echo "================================================"
echo ""

# Configuration - UPDATE THESE VALUES FOR YOUR ENVIRONMENT
HARBOR_URL="${HARBOR_URL:-harbor.yourdomain.com}"
HARBOR_PROJECT="${HARBOR_PROJECT:-llama-assistant}"
IMAGE_NAME="code-assistant"
IMAGE_TAG="v1"

echo "Configuration:"
echo "  Harbor URL: ${HARBOR_URL}"
echo "  Project: ${HARBOR_PROJECT}"
echo "  Image: ${IMAGE_NAME}:${IMAGE_TAG}"
echo ""

# Check if Docker is available
if ! command -v docker &> /dev/null; then
    echo "ERROR: Docker is not installed or not in PATH"
    exit 1
fi

# Full image path
FULL_IMAGE="${HARBOR_URL}/${HARBOR_PROJECT}/${IMAGE_NAME}:${IMAGE_TAG}"

echo "Step 1: Building Docker image..."
docker build -t ${IMAGE_NAME}:${IMAGE_TAG} .

if [ $? -eq 0 ]; then
    echo "✓ Image built successfully"
else
    echo "✗ Build failed"
    exit 1
fi

echo ""
echo "Step 2: Tagging image for Harbor..."
docker tag ${IMAGE_NAME}:${IMAGE_TAG} ${FULL_IMAGE}
echo "✓ Tagged as: ${FULL_IMAGE}"

echo ""
echo "Step 3: Logging in to Harbor..."
echo "Please enter your Harbor credentials:"
docker login ${HARBOR_URL}

if [ $? -ne 0 ]; then
    echo "✗ Login failed"
    exit 1
fi

echo ""
echo "Step 4: Pushing image to Harbor..."
docker push ${FULL_IMAGE}

if [ $? -eq 0 ]; then
    echo "✓ Image pushed successfully"
else
    echo "✗ Push failed"
    exit 1
fi

echo ""
echo "================================================"
echo "  Success!"
echo "================================================"
echo ""
echo "Image available at: ${FULL_IMAGE}"
echo ""
echo "Next steps:"
echo ""
echo "1. Update kubernetes/06-code-assistant.yaml:"
echo "   Change image to: ${FULL_IMAGE}"
echo ""
echo "2. If Harbor requires authentication, create secret:"
echo "   kubectl create secret docker-registry harbor-secret \\"
echo "     --docker-server=${HARBOR_URL} \\"
echo "     --docker-username=YOUR_USERNAME \\"
echo "     --docker-password=YOUR_PASSWORD"
echo ""
echo "3. Add imagePullSecrets to YAML files (see HARBOR.md)"
echo ""
echo "4. Deploy to Kubernetes:"
echo "   kubectl apply -f kubernetes/"
echo ""
echo "See HARBOR.md for complete instructions"
echo ""
