# Quick Deployment with Existing Image

You have a Python image with Flask, requests, and gunicorn? Great! Here's how to deploy without building anything.

## Your Image Requirements

Your existing image must have:
- ✅ Flask
- ✅ requests  
- ✅ gunicorn

That's it! No flask-cors needed.

## Deployment Steps

### 1. Update the Deployment File

Edit `kubernetes/06-code-assistant.yaml` and change the image line:

**Find this:**
```yaml
        # IMPORTANT: Replace with your existing image that has Flask, requests, and gunicorn
        # Example: harbor.yourdomain.com/base-images/python-flask:latest
        image: code-assistant:v1
```

**Change to your image:**
```yaml
        image: harbor.yourdomain.com/your-project/your-python-image:tag
```

### 2. Deploy Everything

```bash
# Navigate to kubernetes directory
cd kubernetes

# Deploy in order
kubectl apply -f 01-code-storage.yaml
kubectl apply -f 02-upload-pod.yaml

# Wait for upload pod
kubectl wait --for=condition=ready pod/upload-pod --timeout=60s

# Upload your code
kubectl cp /apps/myapp upload-pod:/code/

# Verify code uploaded
kubectl exec upload-pod -- ls -la /code

# Delete upload pod
kubectl delete pod upload-pod

# Deploy Llama
kubectl apply -f 03-llama-deployment.yaml
kubectl apply -f 04-llama-service.yaml

# Deploy Code Assistant (ConfigMap + Deployment)
kubectl apply -f 05-code-assistant-config.yaml
kubectl apply -f 06-code-assistant.yaml

# Wait for deployment
kubectl wait --for=condition=available deployment/code-assistant --timeout=120s

# Get access URL
kubectl get svc code-assistant-service
```

### 3. Access the Web Interface

```
http://<EXTERNAL-IP>:5000
```

## What's Happening?

1. **ConfigMap (05-code-assistant-config.yaml)**: Contains your Python code and HTML
2. **Deployment (06-code-assistant.yaml)**: Uses your existing image + mounts the ConfigMap

```
Your Image (Flask, requests, gunicorn)
    +
ConfigMap (code-assistant-server.py + index.html)
    =
Working Code Assistant
```

## Verify It's Working

```bash
# Check pod is running
kubectl get pods -l app=code-assistant

# Check logs (should see Gunicorn startup)
kubectl logs -f deployment/code-assistant

# Should see:
# [INFO] Starting gunicorn 21.2.0
# [INFO] Listening at: http://0.0.0.0:5000
# [INFO] Booting worker with pid: X
```

## Update Code Without Rebuilding

Want to change the Python code or HTML? Just update the ConfigMap:

```bash
# Edit the ConfigMap
kubectl edit configmap code-assistant-files

# Restart deployment to pick up changes
kubectl rollout restart deployment/code-assistant
```

## Troubleshooting

### Pod won't start

```bash
# Check events
kubectl describe pod -l app=code-assistant

# Common issues:
# - Image doesn't have Flask, requests, or gunicorn
# - Image pull error (check imagePullSecrets if using Harbor)
```

### Verify your image has required packages

```bash
# Test your image
kubectl run test --image=YOUR_IMAGE:TAG --rm -it -- /bin/bash

# Inside the pod:
python3 -c "import flask; import requests; print('OK')"
gunicorn --version

# If both work, your image is good!
```

### Files not loading

```bash
# Check if ConfigMap exists
kubectl get configmap code-assistant-files

# Check if it's mounted
kubectl exec deployment/code-assistant -- ls -la /app

# Should see:
# code-assistant-server.py
# index.html
```

## That's It!

No Docker builds, no image pushes, just deploy with your existing image + ConfigMap. 🎉

**Total deployment time: ~10 minutes**
