# Documentation Index

Welcome to the Llama Code Assistant package! This file helps you navigate the documentation.

## 🚀 Getting Started

**New to this project? Start here:**

1. **[QUICK_DEPLOY.md](QUICK_DEPLOY.md)** - ⭐ Use your existing Python image (FASTEST)
   - No image building required
   - Uses ConfigMap for application code
   - ~10 minutes total deployment time
   - Perfect if you already have Flask + requests + gunicorn

2. **[QUICKSTART.md](QUICKSTART.md)** - Get running in 8 commands
   - TL;DR version for experienced users
   - Commands only, minimal explanation
   - Harbor-based workflow

3. **[CHECKLIST.md](CHECKLIST.md)** - Step-by-step installation tracker
   - Interactive checklist format
   - Track your progress
   - Troubleshooting tips at each step

## 📚 Complete Documentation

**For detailed information:**

3. **[README.md](README.md)** - Complete installation and usage guide
   - Full installation steps with explanations
   - Usage examples and tips
   - Comprehensive troubleshooting section
   - Customization options
   - Security notes

4. **[HARBOR.md](HARBOR.md)** - ⭐ Harbor registry deployment guide
   - Specific instructions for VMware VKS with Harbor
   - Build and push to Harbor registry
   - Update YAML files for Harbor
   - Create imagePullSecrets
   - Automated build-harbor.sh script

5. **[ARCHITECTURE.md](ARCHITECTURE.md)** - System architecture and design
   - Visual diagrams of the system
   - Request flow explanations
   - Design decisions and rationale
   - Network topology
   - Scaling considerations

6. **[PRODUCTION.md](PRODUCTION.md)** - Production server configuration
   - Gunicorn settings and tuning
   - Worker and timeout configuration
   - Performance optimization
   - Monitoring and troubleshooting
   - Best practices for different codebase sizes

7. **[MANIFEST.md](MANIFEST.md)** - Package contents and file listing
   - What's included in this package
   - File descriptions
   - Version information
   - Prerequisites

## 🛠️ Build Files

**For building the Docker image:**

- **[build-harbor.sh](build-harbor.sh)** - Build and push to Harbor registry
  - Run this to build and push the Docker image
  - Automated build and push process
  - Outputs directly to Harbor

- **[Dockerfile](Dockerfile)** - Docker image definition
- **[requirements.txt](requirements.txt)** - Python dependencies

## 💻 Code Files

**The actual application code:**

- **[code-assistant-server.py](code-assistant-server.py)** - Flask API server
  - Reads your code files
  - Communicates with Ollama
  - Serves the web interface

- **[index.html](index.html)** - Web user interface
  - File browser sidebar
  - Chat interface
  - Client-side JavaScript

## ☸️ Kubernetes Files

**Deployment manifests (in kubernetes/ directory):**

Note: All YAML files are in the `kubernetes/` subdirectory!

1. **[01-code-storage.yaml](kubernetes/01-code-storage.yaml)** - Storage for code
2. **[02-upload-pod.yaml](kubernetes/02-upload-pod.yaml)** - Temporary upload pod
3. **[03-llama-deployment.yaml](kubernetes/03-llama-deployment.yaml)** - Llama/Ollama deployment
4. **[04-llama-service.yaml](kubernetes/04-llama-service.yaml)** - Ollama API service (ClusterIP)
5. **[05-code-assistant-config.yaml](kubernetes/05-code-assistant-config.yaml)** - ConfigMap with application code
6. **[06-code-assistant.yaml](kubernetes/06-code-assistant.yaml)** - Code assistant deployment

## 📖 Reading Order Recommendations

### For Users with Existing Python Image (Fastest):
```
1. QUICK_DEPLOY.md (Follow the steps)
2. Done in ~10 minutes!
```

### For First-Time Users:
```
1. README.md (Overview section)
2. QUICKSTART.md (Skim the commands)
3. CHECKLIST.md (Use this during installation)
4. README.md (Troubleshooting as needed)
```

### For Experienced Kubernetes Users:
```
1. QUICKSTART.md (All you need)
2. ARCHITECTURE.md (If curious about design)
```

### For Understanding the System:
```
1. ARCHITECTURE.md (Understand the design)
2. README.md (Implementation details)
3. Review the code files
```

### For Customization:
```
1. README.md (Customization section)
2. PRODUCTION.md (Gunicorn tuning)
3. ARCHITECTURE.md (Understand constraints)
4. Modify code-assistant-server.py or index.html
5. Update ConfigMap and restart deployment
```

## 🎯 Quick Reference

### Installation Time
- Build image: 5-10 minutes
- Deploy to Kubernetes: 10-20 minutes
- Upload code: 5-15 minutes (depends on size)
- **Total: 30-60 minutes**

### System Requirements
- VMware Kubernetes Service with LoadBalancer support
- Persistent volume provisioning
- Existing ollama32:latest image with Llama 3.2
- 5Gi+ storage for code

### Key URLs After Deployment
- Web interface: `http://<code-assistant-ip>:5000`
- Ollama API: `http://<llama-service-ip>:11434`

### Key Commands
```bash
# Build (Harbor registry)
./build-harbor.sh

# Deploy
kubectl apply -f kubernetes/

# Check status
kubectl get pods
kubectl get svc

# View logs
kubectl logs -f deployment/code-assistant
kubectl logs -f deployment/llama-deployment
```

## 🆘 Getting Help

### If you're stuck:

1. **Check [CHECKLIST.md](CHECKLIST.md)** - Has troubleshooting for each step
2. **Review [README.md](README.md)** - Comprehensive troubleshooting section
3. **Check pod logs:**
   ```bash
   kubectl logs -f deployment/code-assistant
   kubectl logs -f llama32-pod
   ```
4. **Verify connectivity:**
   ```bash
   kubectl exec deployment/code-assistant -- curl http://llama-service:11434/api/tags
   ```

### Common Issues Quick Links

- **Files not showing**: [README.md - Troubleshooting](README.md#files-not-showing-in-sidebar)
- **Can't connect**: [README.md - Troubleshooting](README.md#cant-connect-to-web-interface)
- **Model not responding**: [README.md - Troubleshooting](README.md#model-not-responding)

## 📦 Package Contents at a Glance

```
llama-code-assistant/
├── Documentation (6 files)
│   ├── INDEX.md (this file)
│   ├── README.md
│   ├── QUICKSTART.md
│   ├── CHECKLIST.md
│   ├── ARCHITECTURE.md
│   └── MANIFEST.md
├── Build files (4 files)
│   ├── build.sh
│   ├── Dockerfile
│   ├── requirements.txt
│   ├── code-assistant-server.py
│   └── index.html
└── Kubernetes (5 files)
    └── kubernetes/
        ├── 01-code-storage.yaml
        ├── 02-upload-pod.yaml
        ├── 03-llama-pod.yaml
        ├── 04-llama-service.yaml
        └── 05-code-assistant.yaml
```

## 🎓 Learning Path

### Path 1: Just Get It Working (30 min)
```
QUICKSTART.md → build.sh → kubectl apply → Done!
```

### Path 2: Understand While Building (60 min)
```
README.md → CHECKLIST.md (follow along) → ARCHITECTURE.md
```

### Path 3: Deep Dive (2+ hours)
```
All documentation → Review code → Customize → Rebuild
```

---

**Ready to start?** 

→ Go to **[QUICKSTART.md](QUICKSTART.md)** for the fastest path  
→ Go to **[README.md](README.md)** for detailed guidance  
→ Go to **[CHECKLIST.md](CHECKLIST.md)** to track your progress  

Good luck! 🚀
