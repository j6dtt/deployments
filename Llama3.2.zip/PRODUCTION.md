# Production Server Configuration (Gunicorn)

The code-assistant uses Gunicorn as the production WSGI server instead of Flask's development server.

## Default Configuration

**In Dockerfile:**
```dockerfile
CMD ["gunicorn", "--bind", "0.0.0.0:5000", "--workers", "2", "--timeout", "120", "code-assistant-server:app"]
```

## Configuration Options

### Workers (`--workers`)
**Current:** 2 workers

**Recommended formula:** `(2 * CPU cores) + 1`

```dockerfile
# For 1 CPU core:
--workers 3

# For 2 CPU cores:
--workers 5

# For 4 CPU cores:
--workers 9
```

**Trade-offs:**
- More workers = Better concurrency
- More workers = More memory usage
- Too many workers can overwhelm the Ollama backend

**Recommendation for this use case:** 2-4 workers (AI requests are slow, not CPU-bound)

### Timeout (`--timeout`)
**Current:** 120 seconds (2 minutes)

This is how long Gunicorn waits for a response before killing the worker.

**Adjust based on:**
- Large codebases → Increase timeout
- Complex queries → Increase timeout
- Simple queries → Can decrease

```dockerfile
# For very large codebases or complex queries:
--timeout 300

# For fast responses:
--timeout 60
```

### Threads (`--threads`)
**Not currently used**

Can use threads instead of workers for lighter memory footprint:

```dockerfile
CMD ["gunicorn", "--bind", "0.0.0.0:5000", "--workers", "1", "--threads", "4", "--timeout", "120", "code-assistant-server:app"]
```

**When to use threads:**
- Limited memory
- I/O-bound workload (waiting for Ollama)
- Single worker with multiple threads uses less memory

### Keep-Alive (`--keep-alive`)
**Default:** 2 seconds

For persistent browser connections:

```dockerfile
--keep-alive 5
```

## Customizing Configuration

### Method 1: Edit Dockerfile (Rebuild Required)

```dockerfile
# Edit Dockerfile
CMD ["gunicorn", \
     "--bind", "0.0.0.0:5000", \
     "--workers", "4", \
     "--timeout", "180", \
     "--keep-alive", "5", \
     "code-assistant-server:app"]
```

Then rebuild:
```bash
./build-harbor.sh
```

### Method 2: Override in Kubernetes (No Rebuild)

Edit `kubernetes/05-code-assistant.yaml`:

```yaml
spec:
  template:
    spec:
      containers:
      - name: code-assistant
        image: harbor.yourdomain.com/llama-assistant/code-assistant:v1
        command: ["gunicorn"]
        args:
          - "--bind"
          - "0.0.0.0:5000"
          - "--workers"
          - "4"
          - "--timeout"
          - "180"
          - "code-assistant-server:app"
```

Then redeploy:
```bash
kubectl apply -f kubernetes/05-code-assistant.yaml
```

## Monitoring Gunicorn

### Check Gunicorn is Running

```bash
# Check logs for Gunicorn startup
kubectl logs -f deployment/code-assistant

# Should see:
# [INFO] Starting gunicorn 21.2.0
# [INFO] Listening at: http://0.0.0.0:5000
# [INFO] Using worker: sync
# [INFO] Booting worker with pid: X
```

### Check Worker Count

```bash
kubectl exec deployment/code-assistant -- ps aux | grep gunicorn
```

You should see:
- 1 master process
- 2 worker processes (or however many you configured)

### Monitor Performance

```bash
# Watch pod resource usage
kubectl top pod -l app=code-assistant

# If CPU is consistently high → Increase workers
# If memory is high → Decrease workers or use threads
```

## Troubleshooting

### "Worker timeout" errors

**Symptom:** Logs show "CRITICAL WORKER TIMEOUT"

**Solution:** Increase timeout:
```dockerfile
--timeout 300
```

### Slow responses

**Symptom:** Requests take a long time

**Solution:** Increase workers (if you have CPU/memory):
```dockerfile
--workers 4
```

### High memory usage

**Symptom:** Pod uses too much memory

**Solution:** Reduce workers or use threads:
```dockerfile
--workers 1 --threads 4
```

### Connection errors

**Symptom:** Can't connect to web interface

**Check:**
```bash
# Verify Gunicorn is listening
kubectl exec deployment/code-assistant -- netstat -tuln | grep 5000

# Should show:
# tcp  0  0  0.0.0.0:5000  0.0.0.0:*  LISTEN
```

## Best Practices for This Use Case

### Recommended Settings:

**For Small Codebases (<100 files):**
```dockerfile
--workers 2 --timeout 120
```

**For Medium Codebases (100-1000 files):**
```dockerfile
--workers 3 --timeout 180
```

**For Large Codebases (1000+ files):**
```dockerfile
--workers 2 --timeout 300
```

**For Memory-Constrained Environments:**
```dockerfile
--workers 1 --threads 4 --timeout 180
```

## Why These Defaults?

**workers=2:**
- Handles concurrent requests from multiple users
- Not too memory-heavy
- Good balance for typical usage

**timeout=120:**
- Enough time for AI to process moderate queries
- Prevents hanging on very long operations
- Can be increased if needed

**No threads:**
- Simpler configuration
- Workers handle blocking I/O fine
- Can add threads later if needed

## Additional Gunicorn Options

### Logging

```dockerfile
--access-logfile - \
--error-logfile - \
--log-level info
```

### Graceful Timeout

```dockerfile
--graceful-timeout 30
```

Gives workers 30 seconds to finish before force-killing during restart.

### Max Requests (Auto-restart workers)

```dockerfile
--max-requests 1000 \
--max-requests-jitter 100
```

Workers restart after handling ~1000 requests (prevents memory leaks).

## Further Reading

- Gunicorn Docs: https://docs.gunicorn.org/
- Worker Types: https://docs.gunicorn.org/en/stable/design.html
- Deployment: https://docs.gunicorn.org/en/stable/deploy.html

## Summary

✅ **Default config is production-ready** for most use cases  
✅ **Adjust workers** based on CPU cores and traffic  
✅ **Adjust timeout** based on codebase size and query complexity  
✅ **Monitor** with `kubectl logs` and `kubectl top pod`  

The Flask development server warning is now gone! 🎉
