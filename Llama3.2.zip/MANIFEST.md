# Llama Code Assistant - Package Contents

## Package Version: 1.0
## Created: 2026-02-03

This package contains everything needed to deploy a Llama 3.2 code assistant in an air-gapped VMware Kubernetes Service environment.

## File Listing

### Documentation
```
README.md              - Complete installation and usage guide (10+ pages)
QUICKSTART.md          - Quick start guide (get running in 10 commands)
ARCHITECTURE.md        - Detailed system architecture diagrams and explanations
MANIFEST.md            - This file
```

### Docker Build Files
```
Dockerfile             - Multi-stage build for code-assistant image
requirements.txt       - Python dependencies (Flask, flask-cors, requests)
code-assistant-server.py  - Flask API server (77 lines)
index.html            - Web interface with file browser (230+ lines)
build-harbor.sh       - Automated Harbor build and push script
```

### Kubernetes Manifests (kubernetes/)
```
01-code-storage.yaml       - PersistentVolumeClaim (5Gi storage)
02-upload-pod.yaml         - Temporary pod for code upload
03-llama-deployment.yaml   - Llama/Ollama deployment with code mount
04-llama-service.yaml      - ClusterIP service for Ollama API (internal only)
05-code-assistant.yaml     - Deployment and LoadBalancer service for web interface
```

## File Sizes (Approximate)

- Total package: ~15 KB (text files only)
- Built Docker image: ~150-200 MB
- Code storage required: Depends on your codebase size

## Prerequisites

### On Build Machine:
- Docker or Podman
- Access to transfer files to air-gapped environment

### In VKS Environment:
- Kubernetes cluster with kubectl access
- LoadBalancer support
- Persistent volume provisioning
- Existing ollama32:latest image with Llama 3.2 model

## Installation Overview

1. Build Docker image and push to Harbor registry
2. Update Kubernetes YAML files with Harbor image paths
3. Apply Kubernetes manifests in numbered order
4. Upload your code to storage
5. Access web interface

**Estimated Setup Time:** 30-60 minutes

## What You Get

### Web Interface Features:
- File browser showing all code files (including subdirectories)
- Click-to-select files for context
- Chat interface for asking questions
- Real-time AI responses based on your actual code

### System Capabilities:
- Access entire codebase as model context
- Ask questions like:
  - "How does authentication work?"
  - "Explain the database connection setup"
  - "What does this function in user.py do?"
  - "Find potential bugs in auth.py"
- Select relevant files to focus the AI's attention
- Get answers based on your actual implementation

### Technical Features:
- Air-gapped compatible (no internet required)
- Persistent storage for code
- Horizontal scaling for web interface
- Production-ready LoadBalancer services
- Health checks and readiness probes

## Directory Structure After Installation

```
llama-code-assistant/
├── README.md                     # Main documentation
├── QUICKSTART.md                 # Quick start guide (Harbor-based)
├── HARBOR.md                     # Harbor registry instructions
├── ARCHITECTURE.md               # Architecture details
├── MANIFEST.md                   # This file
├── Dockerfile                    # Image build definition
├── requirements.txt              # Python dependencies
├── code-assistant-server.py      # API server code
├── index.html                    # Web UI
├── build-harbor.sh               # Harbor build script
└── kubernetes/                   # K8s manifests
    ├── 01-code-storage.yaml
    ├── 02-upload-pod.yaml
    ├── 03-llama-deployment.yaml
    ├── 04-llama-service.yaml
    └── 05-code-assistant.yaml
```

## Version History

### v1.0 (2026-02-03)
- Initial release
- Support for air-gapped VMware VKS
- Web-based file browser
- Multi-file context support
- Complete documentation

## Support and Customization

See README.md for:
- Detailed troubleshooting
- Customization options
- Security notes
- Scaling considerations

## License

Individual components retain their respective licenses:
- Flask: BSD License
- Python: PSF License
- Ollama: MIT License

## Notes

- This is a deployment package, not a development framework
- Requires existing Ollama setup with Llama 3.2
- Designed specifically for air-gapped Kubernetes environments
- No telemetry or external communication
- All processing happens locally in your cluster

## Checksum Information

For file integrity verification, you can generate checksums:

```bash
# On Linux/Mac:
find . -type f -exec sha256sum {} \; > checksums.txt

# Verify later:
sha256sum -c checksums.txt
```

## Contact

For issues or improvements:
1. Review README.md troubleshooting section
2. Check pod logs: `kubectl logs -f <pod-name>`
3. Verify all prerequisites are met

---

**End of Manifest**

Total Files: 13
Documentation Files: 5
Code Files: 5
Kubernetes Manifests: 5
