# Changes and Updates

This document tracks improvements made to the Llama Code Assistant package based on user feedback.

## Version 1.1 Updates

### Major Changes

#### 1. Converted llama-pod to Deployment
**File:** `kubernetes/03-llama-deployment.yaml` (renamed from 03-llama-pod.yaml)

**Why:** 
- Auto-restart on failure (resilience)
- Consistent with code-assistant architecture
- Easier scaling if needed
- Production best practice

**Before:**
```yaml
apiVersion: v1
kind: Pod
metadata:
  name: llama32-pod
```

**After:**
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: llama-deployment
spec:
  replicas: 1
  selector:
    matchLabels:
      app: llama
  template:
    metadata:
      labels:
        app: llama
```

#### 2. Changed llama-service to ClusterIP
**File:** `kubernetes/04-llama-service.yaml`

**Why:**
- llama-service only needs internal cluster access
- Saves external IP address
- Better security (not exposed externally)
- Only code-assistant needs external access

**Before:**
```yaml
spec:
  type: LoadBalancer  # Wastes external IP
```

**After:**
```yaml
spec:
  type: ClusterIP  # Internal only
```

#### 3. Removed build.sh (Tar File Method)
**Deleted:** `build.sh`

**Why:**
- VKS uses containerd, not Docker engine
- Harbor registry is the proper method for VKS
- Eliminates confusion about image loading
- Cleaner workflow with Harbor

**Replacement:** `build-harbor.sh` (Harbor-specific)

#### 4. Added Harbor-First Documentation
**New File:** `HARBOR.md`

**Contents:**
- Complete Harbor workflow
- Build and push instructions
- YAML file updates for Harbor image paths
- imagePullSecrets configuration
- Troubleshooting for Harbor-specific issues

### Updated Documentation

All documentation files updated to reflect the changes:

#### Updated Files:
- **START_HERE.txt** - Harbor-first approach
- **INDEX.md** - Updated file listings and references
- **QUICKSTART.md** - Rewritten for Harbor workflow
- **CHECKLIST.md** - Updated all pod references to deployment
- **ARCHITECTURE.md** - Updated diagrams and explanations
- **MANIFEST.md** - Updated file counts and descriptions
- **HARBOR.md** - Complete Harbor guide (new)

#### Key Documentation Updates:
- All references to `llama32-pod` → `llama-deployment`
- All references to `03-llama-pod.yaml` → `03-llama-deployment.yaml`
- All references to `build.sh` removed
- Added Harbor build and push instructions
- Updated log commands: `kubectl logs -f deployment/llama-deployment`
- Updated exec commands: `kubectl exec deployment/llama-deployment`

### Architecture Improvements

**Before:**
```
llama-service (LoadBalancer) → llama32-pod
code-assistant-service (LoadBalancer) → code-assistant pod
```

**After:**
```
llama-service (ClusterIP) → llama-deployment
code-assistant-service (LoadBalancer) → code-assistant deployment
```

**Benefits:**
- Only one external IP needed (code-assistant-service)
- Internal services stay internal
- Both use Deployments (consistent)
- Better security posture

### File Structure Changes

**Before:**
```
kubernetes/
├── 01-code-storage.yaml
├── 02-upload-pod.yaml
├── 03-llama-pod.yaml          ← Pod
├── 04-llama-service.yaml      ← LoadBalancer
└── 05-code-assistant.yaml
```

**After:**
```
kubernetes/
├── 01-code-storage.yaml
├── 02-upload-pod.yaml
├── 03-llama-deployment.yaml   ← Deployment
├── 04-llama-service.yaml      ← ClusterIP
└── 05-code-assistant.yaml
```

**Build scripts:**
- ~~build.sh~~ (removed)
- build-harbor.sh ✓ (Harbor-specific)

### Command Changes

#### Old Commands:
```bash
# Build
./build.sh

# Check llama
kubectl logs -f llama32-pod
kubectl exec llama32-pod -- ollama list

# Deploy
kubectl apply -f kubernetes/03-llama-pod.yaml
```

#### New Commands:
```bash
# Build
./build-harbor.sh

# Check llama
kubectl logs -f deployment/llama-deployment
kubectl exec deployment/llama-deployment -- ollama list

# Deploy
kubectl apply -f kubernetes/03-llama-deployment.yaml
```

### Migration Guide

If you already deployed v1.0, here's how to upgrade:

#### Step 1: Update llama to Deployment
```bash
# Delete old pod
kubectl delete pod llama32-pod

# Apply new deployment
kubectl apply -f kubernetes/03-llama-deployment.yaml

# Wait for ready
kubectl wait --for=condition=available deployment/llama-deployment
```

#### Step 2: Update llama-service to ClusterIP
```bash
# Delete old service
kubectl delete service llama-service

# Apply updated service
kubectl apply -f kubernetes/04-llama-service.yaml
```

#### Step 3: Verify Everything Works
```bash
# Check pods
kubectl get pods
# Should see: llama-deployment-xxx and code-assistant-xxx

# Check services
kubectl get svc
# llama-service should show TYPE: ClusterIP
# code-assistant-service should show TYPE: LoadBalancer

# Test connectivity
kubectl exec deployment/code-assistant -- curl http://llama-service:11434/api/tags
```

No changes needed to code-assistant or code-storage - they continue working as-is.

### Benefits Summary

1. **More Resilient:** Deployments auto-restart failed pods
2. **Better Architecture:** Pods → Deployments throughout
3. **Resource Efficient:** One LoadBalancer instead of two
4. **More Secure:** Internal services not exposed externally
5. **Clearer Workflow:** Harbor-first approach for VKS
6. **Easier Troubleshooting:** Consistent deployment pattern

### Breaking Changes

⚠️ **Important:** These changes require redeployment if upgrading from v1.0

- Pod name changed: `llama32-pod` → `llama-deployment-xxxxx-xxxxx`
- Service type changed: `llama-service` is now ClusterIP (no external IP)
- Build process: Use `build-harbor.sh` instead of `build.sh`

### Compatibility

- ✅ Same functionality - everything works the same way
- ✅ No changes to web interface
- ✅ No changes to API
- ✅ Code storage unchanged
- ⚠️ Requires rebuild and redeploy (not in-place upgrade)

---

**Version:** 1.1  
**Date:** 2026-02-04  
**Changes:** Architecture improvements, Harbor-first workflow  
